"""byoe web — browser UI for the BYOE Agent (Helm frontend).

Single-file HTTP server using only the Python standard library.
No new runtime dependencies beyond what byoe already requires.

Architecture
------------
- ThreadingHTTPServer handles concurrent requests (one thread per connection)
- Server-Sent Events (SSE) stream tokens + tool-call progress to the browser
- All state lives in a single WebSession object shared across HTTP handlers
- A one-time token printed to the terminal gates every /api/* request (CSRF-safe)
- Helm React frontend is served from byoe/static/ (pre-built dist)
- Falls back to inline HTML if byoe/static/ is absent

Endpoints
---------
    GET  /              → Helm UI (or fallback inline HTML)
  GET  /assets/*      → Static assets (JS/CSS)
  GET  /api/status    → JSON: model, base_url, token usage, changed files
  GET  /api/sessions  → JSON list of saved sessions
    POST /api/chat      → SSE stream: { "q": "..." }
  POST /api/reset     → Reset conversation history
  POST /api/abort     → Abort current agent loop (non-destructive)
  POST /api/save      → Save session, returns { "id": "..." }
  GET  /api/diff      → JSON list of changed files
  GET  /api/tokens    → JSON token usage
  GET  /api/crew      → JSON Crew workspace status
"""
from __future__ import annotations

import collections
import hashlib
import html
import io
import json
import os
import queue
import secrets
import sys
import threading
import time
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import TYPE_CHECKING
from urllib.parse import parse_qs, urlparse

from byoe.engine.scheduler import AgentScheduler

if TYPE_CHECKING:
    from .engine.agent import Agent
    from .engine.config import Config


# ─────────────────────────────────────────────────────────────────────────────

# Minimal fallback HTML — shown only when byoe/static/ (Helm dist) is absent.
# Rebuild: run `npm run build` in C:/vibe/helm and copy dist/ to byoe/byoe/static/
_HTML_FALLBACK = (
    "<!DOCTYPE html><html lang='en'><head>"
    "<meta charset='UTF-8'>"
    "<meta name='viewport' content='width=device-width,initial-scale=1'>"
    "<title>BYOE</title>"
    "<style>body{font-family:system-ui,sans-serif;background:#0d1117;color:#e6edf3;"
    "display:flex;align-items:center;justify-content:center;height:100vh;margin:0;"
    "flex-direction:column;gap:16px}a{color:#58a6ff}code{background:#161b22;"
    "padding:2px 6px;border-radius:4px}</style></head><body>"
    "<h2>\u535c\u4e00\u667a\u822a · BYOE __VERSION__</h2>"
    "<p>Helm frontend not found. Install or upgrade:</p>"
    "<code>pip install --upgrade byoe</code>"
    "<p>Or rebuild frontend: see <a href='https://byoe.net'>byoe.net</a></p>"
    "</body></html>"
)



# ─────────────────────────────────────────────────────────────────────────────
# Shared web session state
# ─────────────────────────────────────────────────────────────────────────────

class WebSession:
    """Holds the single Agent instance shared across all HTTP requests."""

    def __init__(self, agent: "Agent", config: "Config", token: str, cwd: str):
        self.agent = agent
        self.config = config
        self.token = token
        self.cwd = cwd
        self._lock = threading.Lock()   # serialise chat calls
        self.scheduler = AgentScheduler(self._run_scheduled_prompt)
        self.scheduler.start()

    def verify(self, req_token: str) -> bool:
        return secrets.compare_digest(self.token, req_token)

    def _run_scheduled_prompt(self, prompt: str, source: str) -> None:
        """Execute scheduler/heartbeat prompts without disrupting active chat."""
        if not self._lock.acquire(blocking=False):
            return
        try:
            tagged = f"[{source}] {prompt}" if source else prompt
            self.agent.chat(tagged)
        finally:
            self._lock.release()

    def close(self) -> None:
        try:
            self.scheduler.stop()
        except Exception:
            pass


# ─────────────────────────────────────────────────────────────────────────────
# HTTP handler
# ─────────────────────────────────────────────────────────────────────────────

# ─────────────────────────────────────────────────────────────────────────────
# Sliding-window rate limiter (chat endpoint only)
# ─────────────────────────────────────────────────────────────────────────────

_RATE_LOCK = threading.Lock()
_RATE_CHAT: dict[str, collections.deque] = collections.defaultdict(collections.deque)
# Override with env var BYOE_CHAT_RATE_LIMIT=N to enable (0 = disabled, default)
_CHAT_MAX_PER_MIN = int(os.environ.get("BYOE_CHAT_RATE_LIMIT", "0"))


def _chat_rate_ok(client_ip: str) -> bool:
    """Sliding-window check: True if within limit, False if rate exceeded."""
    if _CHAT_MAX_PER_MIN <= 0:
        return True
    now = time.time()
    window_start = now - 60.0
    with _RATE_LOCK:
        q = _RATE_CHAT[client_ip]
        while q and q[0] < window_start:
            q.popleft()
        if len(q) >= _CHAT_MAX_PER_MIN:
            return False
        q.append(now)
        return True


class _BodyTooLargeError(Exception):
    """Raised by _read_body when the request body exceeds _MAX_BODY."""

class ByoeHandler(BaseHTTPRequestHandler):

    # injected by start_web() below
    session: WebSession

    def log_message(self, fmt, *args):  # noqa: A002
        pass  # suppress default access log; errors still go to stderr

    # ── auth ──────────────────────────────────────────────────────────────────

    def _token_from_request(self) -> str:
        # Prefer X-BYOE-Token header (not visible in server logs)
        header_tok = self.headers.get("X-BYOE-Token", "")
        if header_tok:
            return header_tok
        # Fall back to query param (needed for browser GET requests / initial page load)
        qs = parse_qs(urlparse(self.path).query)
        return qs.get("token", [""])[0]

    def _authorized(self) -> bool:
        return self.session.verify(self._token_from_request())

    # ── response helpers ──────────────────────────────────────────────────────

    def _cors_origin(self) -> str:
        """Return the CORS origin to allow for this request.

        Behaviour is controlled by ByoeHandler._allowed_origins (set by start_web):
          - None / empty list  → only reflect localhost/127.0.0.1 origins (default)
          - ["*"]              → always return "*" (fully open — useful for LAN)
          - ["http://foo:3000", ...]  → reflect if origin matches exactly (scheme+host+port)
        """
        origin = self.headers.get("Origin", "")
        allowed: list[str] = getattr(ByoeHandler, "_allowed_origins", [])

        # Fully open mode
        if "*" in allowed:
            return "*"

        if not origin:
            return "http://localhost"

        try:
            parsed = urlparse(origin)
            hostname = parsed.hostname or ""
        except Exception:
            return "http://localhost"

        # Always allow loopback (exact hostname check, prevents localhost.evil.com bypass)
        if hostname in ("localhost", "127.0.0.1", "::1"):
            return origin

        # Check explicit allow-list — exact scheme + netloc (host:port) match
        for pattern in allowed:
            try:
                p = urlparse(pattern)
                if parsed.scheme == p.scheme and parsed.netloc == p.netloc:
                    return origin
            except Exception:
                continue

        # Fallback — return a non-matching origin so the browser blocks the request
        return "http://localhost"

    def _json(self, code: int, data: object) -> None:
        body = json.dumps(data, ensure_ascii=False).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Access-Control-Allow-Origin", self._cors_origin())
        self.send_header("Vary", "Origin")
        self.end_headers()
        self.wfile.write(body)

    def _html_response(self, code: int, body: str) -> None:
        b = body.encode()
        self.send_response(code)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(b)))
        self.end_headers()
        self.wfile.write(b)

    _MAX_BODY = 4 * 1024 * 1024  # 4 MB hard limit on request bodies

    def _read_body(self) -> dict:
        length = int(self.headers.get("Content-Length", 0))
        if length <= 0:
            return {}
        if length > self._MAX_BODY:
            self._json(413, {"error": f"Request body too large ({length} bytes, limit 4 MB)"})
            raise _BodyTooLargeError()
        raw = self.rfile.read(length)
        try:
            return json.loads(raw)
        except Exception:
            return {}

    # ── routing ───────────────────────────────────────────────────────────────

    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", self._cors_origin())
        self.send_header("Access-Control-Allow-Methods", "GET,POST,DELETE,OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type,X-BYOE-Token")
        self.send_header("Vary", "Origin")
        self.end_headers()

    def _serve_static(self, path: str) -> bool:
        """Try to serve a file from byoe/static/. Returns True if handled."""
        import mimetypes
        # Explicit MIME types — Windows registry often lacks these
        _MIME_OVERRIDES = {
            ".js":   "application/javascript",
            ".mjs":  "application/javascript",
            ".css":  "text/css",
            ".svg":  "image/svg+xml",
            ".ico":  "image/x-icon",
            ".png":  "image/png",
            ".json": "application/json",
            ".woff2": "font/woff2",
            ".woff":  "font/woff",
        }
        static_dir = Path(__file__).parent / "static"
        if not static_dir.is_dir():
            return False
        # Map "/" to "index.html"
        rel = "index.html" if path in ("", "/") else path.lstrip("/")
        file_path = static_dir / rel
        # Security: ensure path stays within static_dir
        try:
            resolved = file_path.resolve()
            static_dir.resolve().resolve()
            resolved.relative_to(static_dir.resolve())
        except (ValueError, OSError):
            return False
        if not resolved.is_file():
            # SPA fallback ONLY for extension-less paths (HTML routes)
            # Never serve index.html for asset requests (.js/.css/etc.)
            suffix = Path(rel).suffix.lower()
            if suffix:
                # It's an asset request but file is missing — return 404
                self._json(404, {"error": "Not found"})
                return True  # handled (with 404)
            # No extension → SPA route, serve index.html
            resolved = static_dir / "index.html"
            if not resolved.is_file():
                return False
        data = resolved.read_bytes()
        suffix = resolved.suffix.lower()
        mime = _MIME_OVERRIDES.get(suffix) or mimetypes.guess_type(str(resolved))[0] or "application/octet-stream"
        is_immutable = "/assets/" in str(resolved)
        # ETag based on file mtime — enables 304 Not Modified for non-hashed files
        mtime = int(resolved.stat().st_mtime)
        etag = f'"{mtime}-{len(data)}"'
        client_etag = self.headers.get("If-None-Match", "")
        if client_etag == etag:
            self.send_response(304)
            self.send_header("ETag", etag)
            self.send_header("Cache-Control", "public, max-age=31536000, immutable" if is_immutable else "no-cache")
            self.end_headers()
            return True
        self.send_response(200)
        self.send_header("Content-Type", mime)
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Frame-Options", "SAMEORIGIN")
        if resolved.name == "index.html":
            self.send_header(
                "Content-Security-Policy",
                "default-src 'self'; "
                "script-src 'self' 'unsafe-inline'; "
                "style-src 'self' 'unsafe-inline'; "
                "img-src 'self' data: blob:; "
                "connect-src 'self' http://localhost:* http://127.0.0.1:* ws://localhost:* ws://127.0.0.1:*; "
                "font-src 'self' data:;"
            )
        # Gzip compression — only for compressible text-based assets
        _COMPRESSIBLE = ("javascript", "css", "json", "html", "text", "svg", "xml")
        accept_enc = self.headers.get("Accept-Encoding", "")
        can_gzip = "gzip" in accept_enc and any(c in mime for c in _COMPRESSIBLE)
        if can_gzip:
            import gzip as _gzip
            data = _gzip.compress(data, compresslevel=6)
            self.send_header("Content-Encoding", "gzip")
            self.send_header("Vary", "Accept-Encoding")
        self.send_header("Content-Length", str(len(data)))
        self.send_header("ETag", etag)
        self.send_header("Cache-Control", "public, max-age=31536000, immutable" if is_immutable else "no-cache")
        self.end_headers()
        self.wfile.write(data)
        return True

    def do_GET(self):
        path = urlparse(self.path).path

        if not path.startswith("/api/"):
            # Serve Helm static frontend (with token in URL for auto-auth)
            if self._serve_static(path):
                return
            # Fallback to inline HTML if no static dir
            self._html_response(200, _HTML_FALLBACK.replace("__VERSION__", _byoe_version()))
            return

        # Public endpoints — no token required
        if path == "/api/health":
            self._handle_health()
            return

        if not self._authorized():
            self._json(401, {"error": "Unauthorized"})
            return

        if path == "/api/status":
            self._handle_status()
        elif path == "/api/health":
            self._handle_health()
        elif path == "/api/sessions":
            self._handle_list_sessions()
        elif path == "/api/diff":
            self._handle_diff()
        elif path == "/api/tokens":
            self._handle_tokens()
        elif path == "/api/crew":
            self._handle_crew()
        elif path == "/api/crew/proposal":
            self._handle_crew_proposal()
        elif path == "/api/skills":
            self._handle_list_skills()
        elif path == "/api/usage":
            self._handle_usage()
        elif path == "/api/agents":
            self._handle_list_agents()
        elif path == "/api/cwd":
            self._handle_get_cwd()
        elif path == "/api/schedule":
            self._handle_schedule_list()
        elif path == "/api/schedule/audit":
            self._handle_schedule_audit()
        elif path == "/api/schedule/retry":
            self._handle_schedule_retry_get()
        elif path == "/api/auto":
            self._handle_auto_status()
        else:
            self._json(404, {"error": "Not found"})

    def do_POST(self):
        path = urlparse(self.path).path

        if not self._authorized():
            self._json(401, {"error": "Unauthorized"})
            return

        # Rate-limit chat requests per client IP (default 20/min, set BYOE_CHAT_RATE_LIMIT)
        if path == "/api/chat" and not _chat_rate_ok(self.client_address[0]):
            self._json(429, {"error": "Too many requests — please wait a moment"})
            return

        try:
            if path == "/api/chat":
                self._handle_chat()
            elif path == "/api/reset":
                self._handle_reset()
            elif path == "/api/abort":
                self._handle_abort()
            elif path == "/api/save":
                self._handle_save()
            elif path == "/api/load":
                self._handle_load()
            elif path == "/api/crew/init":
                self._handle_crew_init()
            elif path == "/api/crew/plan":
                self._handle_crew_plan()
            elif path == "/api/crew/confirm":
                self._handle_crew_confirm()
            elif path == "/api/crew/archive":
                self._handle_crew_archive()
            elif path == "/api/crew/delete":
                self._handle_crew_delete()
            elif path == "/api/crew/run":
                self._handle_crew_run()
            elif path == "/api/crew/verify":
                self._handle_crew_verify()
            elif path == "/api/skills":
                self._handle_save_skill()
            elif path == "/api/agent/activate":
                self._handle_agent_activate()
            elif path == "/api/upload":
                self._handle_upload()
            elif path == "/api/cwd":
                self._handle_set_cwd()
            elif path == "/api/schedule/add":
                self._handle_schedule_add()
            elif path == "/api/schedule/remove":
                self._handle_schedule_remove()
            elif path == "/api/schedule/pause":
                self._handle_schedule_pause()
            elif path == "/api/schedule/resume":
                self._handle_schedule_resume()
            elif path == "/api/schedule/retry":
                self._handle_schedule_retry_set()
            elif path == "/api/auto":
                self._handle_auto_set()
            else:
                self._json(404, {"error": "Not found"})
        except _BodyTooLargeError:
            pass  # 413 already sent by _read_body

    def do_DELETE(self):
        path = urlparse(self.path).path

        if not self._authorized():
            self._json(401, {"error": "Unauthorized"})
            return

        # DELETE /api/sessions/<id>
        if path.startswith("/api/sessions/"):
            sid = path[len("/api/sessions/"):]
            if not sid:
                self._json(400, {"error": "Missing session id"})
                return
            from byoe.engine.session import delete_session
            ok = delete_session(sid)
            if ok:
                self._json(200, {"ok": True, "id": sid})
            else:
                self._json(404, {"ok": False, "error": f"Session not found: {sid}"})
        # DELETE /api/skills/<name>
        elif path.startswith("/api/skills/"):
            skill_name = path[len("/api/skills/"):]
            if not skill_name:
                self._json(400, {"error": "Missing skill name"})
                return
            from byoe.engine.skills import delete_skill
            ok = delete_skill(skill_name)
            if ok:
                self._json(200, {"ok": True, "name": skill_name})
            else:
                self._json(404, {"ok": False, "error": f"Skill not found: {skill_name}"})
        else:
            self._json(404, {"error": "Not found"})

    # ── GET handlers ─────────────────────────────────────────────────────────

    def _handle_health(self):
        """GET /api/health — public liveness probe, no auth required."""
        self._json(200, {"status": "ok", "version": _byoe_version()})

    def _handle_status(self):
        agent = self.session.agent
        llm = agent.llm
        cost = llm.estimated_cost
        # Mask api_key: show only last 4 chars for display
        raw_key = getattr(llm, '_api_key', '') or ''
        masked_key = ('*' * (len(raw_key) - 4) + raw_key[-4:]) if len(raw_key) > 4 else ('*' * len(raw_key))
        self._json(200, {
            "model": llm.model,
            "base_url": getattr(llm, '_base_url', None),
            "api_key_masked": masked_key,
            "cwd": self.session.cwd,
            "prompt_tokens": llm.total_prompt_tokens,
            "completion_tokens": llm.total_completion_tokens,
            "estimated_cost": round(cost, 6) if cost is not None else None,
            "changed_files": len(agent.changed_files),
            "message_count": len(agent.messages),
            "scheduler": {
                "tasks": len(self.session.scheduler.list_tasks()),
                "heartbeat": self.session.scheduler.heartbeat_status(),
                "retry_policy": self.session.scheduler.retry_policy(),
            },
        })

    def _handle_schedule_list(self):
        self._json(200, {
            "tasks": self.session.scheduler.list_tasks(),
            "heartbeat": self.session.scheduler.heartbeat_status(),
            "retry_policy": self.session.scheduler.retry_policy(),
        })

    def _handle_schedule_audit(self):
        qs = parse_qs(urlparse(self.path).query)
        try:
            limit = int((qs.get("limit") or ["100"])[0])
        except Exception:
            limit = 100
        limit = max(1, min(1000, limit))
        task_id = (qs.get("task_id") or [""])[0].strip() or None
        rows = self.session.scheduler.read_audit(limit=limit, task_id=task_id)
        self._json(200, {"events": rows, "count": len(rows)})

    def _handle_schedule_retry_get(self):
        self._json(200, self.session.scheduler.retry_policy())

    def _handle_schedule_retry_set(self):
        body = self._read_body()
        def _to_int(value, default=None):
            try:
                return int(value)
            except Exception:
                return default
        def _to_float(value, default=None):
            try:
                return float(value)
            except Exception:
                return default
        policy = self.session.scheduler.set_retry_policy(
            base_ms=_to_int(body.get("base_ms")),
            multiplier=_to_float(body.get("multiplier")),
            max_ms=_to_int(body.get("max_ms")),
            max_errors=_to_int(body.get("max_errors")),
        )
        self._json(200, {"ok": True, **policy})

    def _handle_schedule_add(self):
        body = self._read_body()
        name = (body.get("name") or "task").strip()
        prompt = (body.get("prompt") or "").strip()
        trigger = (body.get("trigger") or "interval:60m").strip()
        max_runs_raw = body.get("max_runs")
        max_runs = None
        if isinstance(max_runs_raw, int):
            max_runs = max_runs_raw
        elif isinstance(max_runs_raw, str) and max_runs_raw.isdigit():
            max_runs = int(max_runs_raw)
        if not prompt:
            self._json(400, {"error": "prompt is required"})
            return
        try:
            task_id = self.session.scheduler.add_task(name=name, prompt=prompt, trigger=trigger, max_runs=max_runs)
            self._json(200, {"ok": True, "id": task_id})
        except Exception as e:
            self._json(400, {"ok": False, "error": str(e)})

    def _handle_schedule_remove(self):
        body = self._read_body()
        task_id = (body.get("id") or "").strip()
        if not task_id:
            self._json(400, {"error": "id is required"})
            return
        self._json(200, {"ok": self.session.scheduler.remove_task(task_id)})

    def _handle_schedule_pause(self):
        body = self._read_body()
        task_id = (body.get("id") or "").strip()
        if not task_id:
            self._json(400, {"error": "id is required"})
            return
        self._json(200, {"ok": self.session.scheduler.pause_task(task_id)})

    def _handle_schedule_resume(self):
        body = self._read_body()
        task_id = (body.get("id") or "").strip()
        if not task_id:
            self._json(400, {"error": "id is required"})
            return
        self._json(200, {"ok": self.session.scheduler.resume_task(task_id)})

    def _handle_auto_status(self):
        self._json(200, self.session.scheduler.heartbeat_status())

    def _handle_auto_set(self):
        body = self._read_body()
        enabled = bool(body.get("enabled", False))
        interval_ms_raw = body.get("interval_ms", 300000)
        try:
            interval_ms = int(interval_ms_raw)
        except Exception:
            interval_ms = 300000
        prompt = (body.get("prompt") or "").strip() or None
        self.session.scheduler.set_heartbeat(enabled=enabled, interval_ms=interval_ms, prompt=prompt)
        self._json(200, {"ok": True, **self.session.scheduler.heartbeat_status()})

    def _handle_list_sessions(self):
        from byoe.engine.session import list_sessions
        sessions = list_sessions()
        # Sort newest first by saved_at string (ISO-like, lexicographic sort works)
        sessions.sort(key=lambda s: s.get("saved_at", ""), reverse=True)
        # Support optional ?limit= param for pagination
        qs = parse_qs(urlparse(self.path).query)
        try:
            limit = int(qs.get("limit", ["0"])[0])
        except ValueError:
            limit = 0
        if limit > 0:
            sessions = sessions[:limit]
        self._json(200, sessions)

    def _handle_diff(self):
        files = sorted(self.session.agent.changed_files)
        # Also attempt to get actual git diff for each changed file
        diffs: dict = {}
        cwd = self.session.cwd
        for f in files:
            try:
                import subprocess
                result = subprocess.run(
                    ["git", "diff", "HEAD", "--", f],
                    capture_output=True, text=True, cwd=cwd, timeout=5,
                    encoding="utf-8", errors="replace",
                )
                if result.stdout:
                    diffs[f] = result.stdout
                else:
                    # File might be new (untracked) — show full content
                    from pathlib import Path
                    fp = Path(cwd) / f
                    if fp.is_file():
                        content = fp.read_text(encoding="utf-8", errors="replace")
                        lines = content.splitlines()
                        diffs[f] = "".join(f"+{l}\n" for l in lines[:200])
            except Exception:
                pass
        self._json(200, {"files": files, "diffs": diffs})

    def _handle_tokens(self):
        llm = self.session.agent.llm
        cost = llm.estimated_cost
        self._json(200, {
            "prompt_tokens": llm.total_prompt_tokens,
            "completion_tokens": llm.total_completion_tokens,
            "total": llm.total_prompt_tokens + llm.total_completion_tokens,
            "estimated_cost": round(cost, 6) if cost is not None else None,
        })

    def _handle_list_skills(self):
        """GET /api/skills — list all custom skills stored server-side."""
        from byoe.engine.skills import list_skills
        self._json(200, {"skills": list_skills()})

    def _handle_list_agents(self):
        """GET /api/agents — list available specialist agents (agents/*.md)."""
        from .orchestrator.utils import pkg_agents_dir
        agents_dir = pkg_agents_dir()
        specialists = []
        if agents_dir.is_dir():
            for md in sorted(agents_dir.glob("*.md")):
                if md.name == "README.md":
                    continue
                try:
                    content = md.read_text(encoding="utf-8")
                    lines = content.splitlines()
                    name = md.stem.replace("-", " ").title()
                    description = ""
                    for line in lines:
                        stripped = line.strip()
                        if stripped.startswith("# "):
                            name = stripped[2:].strip()
                        elif stripped and not stripped.startswith("#") and not description:
                            description = stripped[:200]
                    specialists.append({
                        "name": md.stem,
                        "label": name,
                        "description": description,
                    })
                except Exception:
                    pass
        self._json(200, {"agents": specialists})

    def _handle_get_cwd(self):
        """GET /api/cwd — return the agent's current working directory."""
        self._json(200, {"cwd": self.session.cwd})

    def _handle_set_cwd(self):
        """POST /api/cwd — change the agent's working directory at runtime.

        Body: {"cwd": "/path/to/project"}
        Resets the agent conversation and rewires the bash sandbox root.
        """
        body = self._read_body()
        new_cwd = (body.get("cwd") or "").strip()
        if not new_cwd:
            self._json(400, {"error": "cwd is required"})
            return
        p = Path(new_cwd).expanduser().resolve()
        if not p.is_dir():
            self._json(400, {"error": f"Directory not found: {new_cwd}"})
            return

        session = self.session
        session.cwd = str(p)
        agent = session.agent
        agent._cwd = str(p)

        # Re-wire sandbox + cwd for BashTool
        from .engine.tools.bash import BashTool
        for t in agent.tools:
            if isinstance(t, BashTool):
                t.set_sandbox_root(str(p))
                t.set_cwd(str(p))
                break

        # Refresh system prompt with new cwd context
        from .engine.prompt import system_prompt as _sp
        agent._system = _sp(agent.tools, cwd=str(p))
        agent.messages = []
        session._auto_save_id = None  # type: ignore[attr-defined]

        self._json(200, {"ok": True, "cwd": str(p)})

    def _handle_upload(self):
        """POST /api/upload — write one or more files into the agent's cwd.

        Body: {"files": [{"name": "foo.py", "content": "...", "encoding"?: "text"|"base64"}]}
        Files are created in `session.cwd`.  Path components are stripped so that
        `../../etc/passwd` cannot escape the working directory.
        Returns: {"ok": true, "saved": ["foo.py", ...]}
        """
        import base64 as _base64
        body = self._read_body()
        files = body.get("files") if isinstance(body, dict) else None
        if not isinstance(files, list) or not files:
            self._json(400, {"error": "Expected {files: [{name, content}]}"})
            return

        cwd = Path(self.session.cwd)
        saved: list[str] = []
        errors: list[str] = []

        for entry in files:
            if not isinstance(entry, dict):
                continue
            raw_name = str(entry.get("name", "")).strip()
            content  = entry.get("content", "")
            encoding = entry.get("encoding", "text")

            # Strip any path components — write only into cwd
            safe_name = Path(raw_name).name
            if not safe_name or safe_name in (".", ".."):
                errors.append(f"Invalid filename: {raw_name!r}")
                continue

            dest = cwd / safe_name
            try:
                if encoding == "base64":
                    dest.write_bytes(_base64.b64decode(content))
                else:
                    dest.write_text(str(content), encoding="utf-8")
                saved.append(safe_name)
            except Exception as exc:
                errors.append(f"{safe_name}: {exc}")

        result: dict = {"ok": bool(saved), "saved": saved}
        if errors:
            result["errors"] = errors
        self._json(200 if saved else 400, result)

    def _handle_agent_activate(self):
        """POST /api/agent/activate — switch active specialist agent.

        Body: {"name": "<agent-stem>"}  (empty name → reset to default)
        Resets conversation and injects the specialist instructions into the system prompt.
        """
        from .engine.prompt import system_prompt as _default_system_prompt
        data = self._read_body()
        name = (data.get("name") or "").strip() if isinstance(data, dict) else ""
        session = self.session
        agent = session.agent

        if not name:
            # Reset to default system prompt
            agent._system = _default_system_prompt(agent.tools, cwd=agent._cwd)
            agent.messages = []
            session._auto_save_id = None
            self._json(200, {"ok": True, "agent": None})
            return

        from .orchestrator.utils import pkg_agents_dir
        agents_dir = pkg_agents_dir()
        md_path = agents_dir / f"{name}.md"
        if not md_path.is_file():
            self._json(404, {"error": f"Agent '{name}' not found"})
            return

        specialist_content = md_path.read_text(encoding="utf-8")
        base = _default_system_prompt(agent.tools, cwd=agent._cwd)
        agent._system = base + "\n\n---\n\n## Specialist Instructions\n\n" + specialist_content
        agent.messages = []
        session._auto_save_id = None
        self._json(200, {"ok": True, "agent": name})

    def _handle_usage(self):
        """GET /api/usage — return recent usage records from ~/.byoe/usage.jsonl."""
        import json as _json
        usage_file = Path.home() / ".byoe" / "usage.jsonl"
        all_records = []
        if usage_file.exists():
            try:
                lines = usage_file.read_text(encoding="utf-8").splitlines()
                for line in lines:
                    try:
                        all_records.append(_json.loads(line))
                    except Exception:
                        pass
            except Exception:
                pass
        # Aggregate totals from ALL records
        total_prompt = sum(r.get("prompt_tokens", 0) for r in all_records)
        total_completion = sum(r.get("completion_tokens", 0) for r in all_records)
        total_cost = sum(r.get("cost") or 0 for r in all_records)
        self._json(200, {
            "records": all_records[-50:],  # last 50 for UI
            "totals": {
                "prompt_tokens": total_prompt,
                "completion_tokens": total_completion,
                "total_tokens": total_prompt + total_completion,
                "cost": round(total_cost, 6),
                "sessions": len(all_records),
            }
        })

    def _handle_save_skill(self):
        """POST /api/skills — create or update a custom skill."""
        from byoe.engine.skills import save_skill
        body = self._read_body()
        name = (body.get("name") or "").strip()
        instructions = (body.get("instructions") or "").strip()
        if not name:
            self._json(400, {"error": "name is required"})
            return
        if not instructions:
            self._json(400, {"error": "instructions are required"})
            return
        try:
            skill = save_skill(
                name=name,
                description=(body.get("description") or "").strip(),
                instructions=instructions,
                trigger=(body.get("trigger") or "").strip(),
            )
            self._json(200, {"ok": True, "skill": skill})
        except ValueError as e:
            self._json(400, {"error": str(e)})
        except Exception as e:
            self._json(500, {"error": str(e)})

    def _handle_crew(self):
        """Return Crew workspace status as JSON (equiv. to `byoe status`)."""
        cwd = Path(self.session.cwd)
        crew_dir = cwd / "crew"

        if not crew_dir.exists():
            self._json(200, {"active": False, "reason": "no crew/ directory"})
            return

        changes_dir = crew_dir / "changes"
        archive_dir = crew_dir / "archive"

        active_changes = []
        if changes_dir.exists():
            for d in sorted(changes_dir.iterdir()):
                if d.is_dir():
                    info: dict = {"name": d.name}
                    proposal = d / "proposal.md"
                    if proposal.exists():
                        txt = proposal.read_text(encoding="utf-8")
                        # extract title from first heading
                        for line in txt.splitlines():
                            if line.startswith("# "):
                                info["title"] = line[2:].strip()
                                break
                        # extract frontmatter fields: mode, plan_confirmed, created
                        import re as _re
                        fm_match = _re.match(r"^---\n(.*?)\n---", txt, _re.DOTALL)
                        if fm_match:
                            fm_text = fm_match.group(1)
                            mode_m = _re.search(r"^mode:\s*(\S+)", fm_text, _re.MULTILINE)
                            info["mode"] = mode_m.group(1) if mode_m else "standard"
                            pc_m = _re.search(r"^plan_confirmed:\s*(\S+)", fm_text, _re.MULTILINE)
                            info["plan_confirmed"] = (pc_m.group(1).lower() == "true") if pc_m else False
                            vc_m = _re.search(r"^verify_confirmed:\s*(\S+)", fm_text, _re.MULTILINE)
                            info["verify_confirmed"] = (vc_m.group(1).lower() == "true") if vc_m else False
                            cr_m = _re.search(r"^created:\s*(\S+)", fm_text, _re.MULTILINE)
                            info["created"] = cr_m.group(1) if cr_m else ""
                        else:
                            info["mode"] = "standard"
                            info["plan_confirmed"] = False
                            info["verify_confirmed"] = False
                            info["created"] = ""
                    # infer phase from directory contents
                    has_design = (d / "design.md").exists()
                    plan_confirmed = info.get("plan_confirmed", False)
                    verify_confirmed = info.get("verify_confirmed", False)
                    mode = info.get("mode", "standard")
                    if verify_confirmed:
                        info["phase"] = "verify"
                    elif has_design and plan_confirmed:
                        info["phase"] = "execute"
                    elif has_design:
                        info["phase"] = "design"
                    elif plan_confirmed:
                        info["phase"] = "execute" if mode == "express" else "design"
                    else:
                        info["phase"] = "plan"
                    tasks_total = tasks_done = 0
                    # check tasks in design.md checklist or proposal.md
                    for tasks_src in [d / "design.md", d / "proposal.md"]:
                        if tasks_src.exists():
                            for line in tasks_src.read_text(encoding="utf-8").splitlines():
                                if line.strip().startswith("- ["):
                                    tasks_total += 1
                                    if line.strip().lower().startswith("- [x]"):
                                        tasks_done += 1
                            break
                    info["tasks_total"] = tasks_total
                    info["tasks_done"] = tasks_done
                    active_changes.append(info)

        archived_count = (
            len([x for x in archive_dir.iterdir() if x.is_dir()])
            if archive_dir.exists() and archive_dir.is_dir() else 0
        )

        # blockers — parse ## [STATUS] sections (INSTRUCTIONS.md canonical format)
        # Also supports legacy inline [ID] [STATUS] format as fallback
        open_blockers: list[dict] = []
        blockers_file = crew_dir / "blockers.md"
        if blockers_file.exists():
            import re
            txt_b = blockers_file.read_text(encoding="utf-8")
            # Primary format: ## [OPEN] #1 Title
            for m in re.finditer(r"^##\s+\[OPEN\]\s+#?(\d+)\s+(.*)", txt_b, re.MULTILINE):
                open_blockers.append({"id": m.group(1), "title": m.group(2).strip()})
            # Fallback format: [BLK-1] [OPEN] Title
            if not open_blockers:
                for line in txt_b.splitlines():
                    m2 = re.match(r"\[([A-Z0-9-]+)\]\s+\[?(OPEN)\]?\s+(.*)", line.strip())
                    if m2:
                        open_blockers.append({"id": m2.group(1), "title": m2.group(3).strip()})

        # next steps: try resume.md YAML frontmatter first (source of truth),
        # then fall back to parsing the ## 下一步 / ## Next Steps section
        next_steps: list[str] = []
        resume = crew_dir / "resume.md"
        if resume.exists():
            import re
            resume_txt = resume.read_text(encoding="utf-8")
            # Try frontmatter first
            fm_m = re.match(r"^---\n(.*?)\n---", resume_txt, re.DOTALL)
            if fm_m:
                # Pull phase/progress from YAML for each active_change
                fm_txt = fm_m.group(1)
                # Update phase from resume frontmatter if available
                ac_blocks = re.findall(
                    r"- name:\s*(\S+).*?phase:\s*(\S+).*?progress:\s*['\"]?(\d+)/(\d+)",
                    fm_txt, re.DOTALL
                )
                resume_phases = {b[0]: {"phase": b[1], "done": int(b[2]), "total": int(b[3])}
                                 for b in ac_blocks}
                for ch in active_changes:
                    if ch["name"] in resume_phases:
                        rp = resume_phases[ch["name"]]
                        ch["phase"] = rp["phase"]
                        if rp["total"] > 0:
                            ch["tasks_total"] = rp["total"]
                            ch["tasks_done"]  = rp["done"]
            # Parse next steps from body
            in_section = False
            for line in resume_txt.splitlines():
                if re.match(r"#+\s*(next|下一步)", line, re.I):
                    in_section = True
                    continue
                if in_section:
                    if line.startswith("#"):
                        break
                    stripped = line.strip()
                    if stripped.startswith("-") or stripped.startswith("*"):
                        next_steps.append(stripped.lstrip("-* ").strip())

        # read project name from crew.yaml
        project_name = ""
        crew_yaml = cwd / "crew.yaml"
        if crew_yaml.exists():
            import re as _re2
            txt = crew_yaml.read_text(encoding="utf-8")
            m = _re2.search(r'name:\s*["\']?(.+?)["\']?\s*$', txt, _re2.MULTILINE)
            if m:
                project_name = m.group(1).strip()

        self._json(200, {
            "active": True,
            "project_name": project_name,
            "has_instructions": (cwd / "INSTRUCTIONS.md").exists(),
            "active_changes": active_changes,
            "archived_count": archived_count,
            "open_blockers": open_blockers,
            "next_steps": next_steps[:5],
        })

    def _handle_crew_proposal(self):
        """GET /api/crew/proposal?name=<name> — return proposal.md + design.md content."""
        qs = parse_qs(urlparse(self.path).query)
        name = (qs.get("name", [""])[0]).strip()
        if not name:
            self._json(400, {"error": "name is required"})
            return
        cwd = Path(self.session.cwd)
        change_dir = cwd / "crew" / "changes" / name
        if not change_dir.exists():
            self._json(404, {"error": f"Change not found: {name}"})
            return
        proposal_path = change_dir / "proposal.md"
        design_path = change_dir / "design.md"
        self._json(200, {
            "name": name,
            "proposal": proposal_path.read_text(encoding="utf-8") if proposal_path.exists() else None,
            "design": design_path.read_text(encoding="utf-8") if design_path.exists() else None,
        })

    def _handle_crew_init(self):
        import subprocess
        cwd = Path(self.session.cwd)
        if not cwd.exists() or not cwd.is_dir():
            self._json(400, {"ok": False, "error": f"Invalid working directory: {cwd}"})
            return
        child_env = os.environ.copy()
        # Force UTF-8 in child CLI process to avoid Windows GBK UnicodeEncodeError
        child_env.setdefault("PYTHONUTF8", "1")
        child_env.setdefault("PYTHONIOENCODING", "utf-8")
        try:
            result = subprocess.run(
                [sys.executable, "-m", "byoe", "init"],
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="replace",
                cwd=str(cwd),
                env=child_env,
                timeout=120,
            )
            output = result.stdout + (result.stderr or "")
            if result.returncode != 0:
                self._json(500, {"ok": False, "error": _sanitize_error(output or "init failed")})
            else:
                self._json(200, {"ok": True, "output": output})
        except Exception as e:
            self._json(500, {"ok": False, "error": _sanitize_error(str(e))})

    def _handle_crew_plan(self):
        """POST /api/crew/plan — create a new change plan in cwd."""
        import subprocess
        body = self._read_body()
        name = body.get("name", "").strip()
        mode = body.get("mode", "standard")
        if not name:
            self._json(400, {"error": "name is required"})
            return
        cmd = [sys.executable, "-m", "byoe", "plan", name]
        if mode == "express":
            cmd.append("--express")
        elif mode == "prototype":
            cmd.append("--prototype")
        child_env = os.environ.copy()
        child_env.setdefault("PYTHONUTF8", "1")
        child_env.setdefault("PYTHONIOENCODING", "utf-8")
        try:
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="replace",
                cwd=self.session.cwd,
                env=child_env,
                timeout=120,
            )
            output = result.stdout + (result.stderr or "")
            if result.returncode != 0:
                self._json(500, {"ok": False, "error": _sanitize_error(output or "plan failed")})
            else:
                self._json(200, {"ok": True, "output": output})
        except Exception as e:
            self._json(500, {"ok": False, "error": _sanitize_error(str(e))})

    def _handle_crew_confirm(self):
        """POST /api/crew/confirm — set plan_confirmed: true in proposal.md."""
        import re
        body = self._read_body()
        name = body.get("name", "").strip()
        if not name:
            self._json(400, {"error": "name is required"})
            return
        proposal = Path(self.session.cwd) / "crew" / "changes" / name / "proposal.md"
        if not proposal.exists():
            self._json(404, {"error": f"proposal.md not found for change: {name}"})
            return
        try:
            txt = proposal.read_text(encoding="utf-8")
            if re.search(r"^plan_confirmed:\s*true", txt, re.MULTILINE):
                self._json(200, {"ok": True, "already_confirmed": True})
                return
            # Replace existing false or add to frontmatter
            if re.search(r"^plan_confirmed:", txt, re.MULTILINE):
                txt = re.sub(r"^plan_confirmed:\s*\S+", "plan_confirmed: true", txt, flags=re.MULTILINE)
            else:
                # Insert into frontmatter after first ---
                txt = re.sub(r"^---\n", "---\nplan_confirmed: true\n", txt, count=1)
            proposal.write_text(txt, encoding="utf-8")
            self._json(200, {"ok": True})
        except Exception as e:
            self._json(500, {"ok": False, "error": str(e)})

    def _handle_crew_archive(self):
        """POST /api/crew/archive — move a change to crew/archive/."""
        import shutil
        body = self._read_body()
        name = body.get("name", "").strip()
        if not name:
            self._json(400, {"error": "name is required"})
            return
        cwd = Path(self.session.cwd)
        src = cwd / "crew" / "changes" / name
        if not src.exists():
            self._json(404, {"error": f"Change not found: {name}"})
            return
        archive_dir = cwd / "crew" / "archive"
        archive_dir.mkdir(parents=True, exist_ok=True)
        dest = archive_dir / name
        try:
            shutil.move(str(src), str(dest))
            self._json(200, {"ok": True, "archived": name})
        except Exception as e:
            self._json(500, {"ok": False, "error": str(e)})

    def _handle_crew_delete(self):
        """POST /api/crew/delete — permanently delete a change directory."""
        import shutil
        body = self._read_body()
        name = body.get("name", "").strip()
        if not name:
            self._json(400, {"error": "name is required"})
            return
        cwd = Path(self.session.cwd)
        target = cwd / "crew" / "changes" / name
        if not target.exists():
            self._json(404, {"error": f"Change not found: {name}"})
            return
        try:
            shutil.rmtree(str(target))
            self._json(200, {"ok": True, "deleted": name})
        except Exception as e:
            self._json(500, {"ok": False, "error": str(e)})

    def _handle_crew_run(self):
        """POST /api/crew/run — return a ready-to-send agent prompt for a change.

        Reads proposal.md (and design.md if present) to build a phase-aware,
        context-rich prompt that the user can send directly to the agent.
        """
        body = self._read_body()
        name = body.get("name", "").strip()
        if not name:
            self._json(400, {"error": "name is required"})
            return

        cwd = Path(self.session.cwd)
        change_dir = cwd / "crew" / "changes" / name
        if not change_dir.exists():
            self._json(404, {"error": f"Change not found: {name}"})
            return

        proposal_path = change_dir / "proposal.md"
        design_path = change_dir / "design.md"

        # Read files
        proposal_txt = proposal_path.read_text(encoding="utf-8") if proposal_path.exists() else ""
        design_txt = design_path.read_text(encoding="utf-8") if design_path.exists() else ""

        # Determine current phase
        import re
        phase = "plan"
        plan_confirmed = False
        mode = "standard"
        if proposal_txt:
            fm_m = re.match(r"^---\n(.*?)\n---", proposal_txt, re.DOTALL)
            if fm_m:
                fm = fm_m.group(1)
                pc_m = re.search(r"^plan_confirmed:\s*(\S+)", fm, re.MULTILINE)
                plan_confirmed = pc_m and pc_m.group(1).lower() == "true"
                mode_m = re.search(r"^mode:\s*(\S+)", fm, re.MULTILINE)
                mode = mode_m.group(1) if mode_m else "standard"

        if design_txt and plan_confirmed:
            phase = "execute"
        elif design_txt:
            phase = "design"
        elif plan_confirmed:
            phase = "execute" if mode == "express" else "design"
        else:
            phase = "plan"

        # Build phase-specific prompt
        lines: list[str] = []

        if phase == "plan":
            lines.append(f"# Crew: Review & Refine Plan — `{name}`\n")
            lines.append(
                "Please review the following change proposal. "
                "Identify any gaps, ambiguities, or missing acceptance criteria, "
                "then help refine the proposal so it's ready to confirm.\n"
            )
        elif phase == "design":
            lines.append(f"# Crew: Design — `{name}`\n")
            lines.append(
                "The plan has been confirmed. Please create or update `crew/changes/"
                f"{name}/design.md` with a technical design covering: "
                "architecture decisions, affected files/modules, implementation steps, "
                "and any risks or dependencies.\n"
            )
        elif phase == "execute":
            lines.append(f"# Crew: Execute — `{name}`\n")
            lines.append(
                "The design is ready. Please implement this change now. "
                "Work through all the tasks in the design/proposal checklist, "
                "edit the relevant files, and mark tasks complete as you go.\n"
            )

        if proposal_txt:
            lines.append(f"## Proposal (`crew/changes/{name}/proposal.md`)\n")
            lines.append(proposal_txt.strip())
            lines.append("")

        if design_txt:
            lines.append(f"## Design (`crew/changes/{name}/design.md`)\n")
            lines.append(design_txt.strip())
            lines.append("")

        prompt = "\n".join(lines).strip()
        self._json(200, {"ok": True, "prompt": prompt, "phase": phase, "name": name})

    def _handle_crew_verify(self):
        """POST /api/crew/verify — set verify_confirmed: true in proposal.md."""
        import re
        body = self._read_body()
        name = body.get("name", "").strip()
        if not name:
            self._json(400, {"error": "name is required"})
            return
        proposal = Path(self.session.cwd) / "crew" / "changes" / name / "proposal.md"
        if not proposal.exists():
            self._json(404, {"error": f"proposal.md not found for change: {name}"})
            return
        try:
            txt = proposal.read_text(encoding="utf-8")
            if re.search(r"^verify_confirmed:\s*true", txt, re.MULTILINE):
                self._json(200, {"ok": True, "already_verified": True})
                return
            if re.search(r"^verify_confirmed:", txt, re.MULTILINE):
                txt = re.sub(r"^verify_confirmed:\s*\S+", "verify_confirmed: true", txt, flags=re.MULTILINE)
            else:
                # Insert into frontmatter
                txt = re.sub(r"^---\n", "---\nverify_confirmed: true\n", txt, count=1)
            proposal.write_text(txt, encoding="utf-8")
            self._json(200, {"ok": True})
        except Exception as e:
            self._json(500, {"ok": False, "error": str(e)})

    # ── POST handlers ─────────────────────────────────────────────────────────

    def _handle_abort(self):
        self.session.agent.abort()
        self._json(200, {"ok": True})

    def _handle_reset(self):
        self.session.agent.reset()
        # Clear auto-save id so the next session gets a fresh file
        self.session._auto_save_id = None
        self._json(200, {"ok": True})

    def _handle_save(self):
        from byoe.engine.session import save_session
        agent = self.session.agent
        sid = save_session(
            agent.messages,
            agent.llm.model,
            changed_files=agent.changed_files,
            prompt_tokens=agent.llm.total_prompt_tokens,
            completion_tokens=agent.llm.total_completion_tokens,
            estimated_cost=agent.llm.estimated_cost,
        )
        self._json(200, {"id": sid})

    def _handle_load(self):
        from byoe.engine.session import load_session
        body = self._read_body()
        sid = body.get("id", "")
        loaded = load_session(sid)
        if not loaded:
            self._json(404, {"ok": False, "error": f"Session not found: {sid}"})
            return
        msgs, model, changed = loaded
        agent = self.session.agent
        # Reset first so token counters, changed_files, and messages are clean
        agent.reset()
        agent.messages = msgs
        agent.changed_files.update(changed)
        agent.llm.model = model
        self._json(200, {"ok": True, "model": model, "messages": msgs})

    def _handle_chat(self):
        """SSE stream: each event is a JSON line prefixed with 'data: '."""
        body = self._read_body()
        q = body.get("q", "").strip()
        if not q:
            self._json(400, {"error": "Empty message"})
            return

        # Optional skill injection — client sends active skill instructions
        skill_instructions = (body.get("skill_instructions", "") or "").strip()
        agent = self.session.agent
        _orig_system = agent._system

        # Build per-request system prompt augmentation
        _extra_system = ""
        if skill_instructions:
            _extra_system += f"\n\n---\n# Active Skill\n{skill_instructions}"

        # PDEVI stage gate: inspect current active changes and inject phase
        # constraints so the AI cannot skip Plan confirmation or jump phases.
        _pdevi_gate = _build_pdevi_gate(Path(self.session.cwd))
        if _pdevi_gate:
            _extra_system += _pdevi_gate

        if _extra_system:
            agent._system = _orig_system + _extra_system

        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream; charset=utf-8")
        self.send_header("Cache-Control", "no-cache")
        self.send_header("X-Accel-Buffering", "no")
        self.send_header("Access-Control-Allow-Origin", self._cors_origin())
        self.send_header("Vary", "Origin")
        self.end_headers()

        def emit(data: dict) -> bool:
            """Write one SSE event. Returns False if the client disconnected."""
            try:
                line = "data: " + json.dumps(data, ensure_ascii=False) + "\n\n"
                self.wfile.write(line.encode())
                self.wfile.flush()
                return True
            except (BrokenPipeError, ConnectionResetError, OSError):
                # Client disconnected — request agent to stop
                self.session.agent.abort()
                return False

        def on_token(tok: str):
            emit({"type": "token", "text": tok})

        def on_tool(name: str, kwargs: dict):
            detail = (
                kwargs.get("command") or kwargs.get("path") or
                kwargs.get("file_path") or kwargs.get("pattern") or ""
            )
            if len(detail) > 120:
                detail = detail[:117] + "..."
            emit({"type": "tool", "name": name, "arg": detail})

        def on_tool_result(name: str, kwargs: dict, result: str):
            if not result or result == "(no output)":
                return
            has_error = (
                result.startswith("Error") or
                result.startswith("⚠") or
                "[exit code:" in result
            )
            # Always surface errors from any tool; surface bash output if short
            if has_error or (name == "bash" and len(result) <= 200):
                detail = (
                    kwargs.get("command") or kwargs.get("file_path") or
                    kwargs.get("old_string", "")[:60] or ""
                )
                emit({"type": "tool_err", "name": name,
                      "arg": detail,
                      "snippet": result[:300]})

        def on_compress(layer: str, before: int, after: int):
            labels = {
                "snip":      "工具输出已裁剪",
                "summarize": "上下文已摘要压缩",
                "collapse":  "上下文已硬重置",
            }
            emit({"type": "compress", "label": labels.get(layer, layer),
                  "before": before, "after": after})

        # Snapshot token counts before this turn (safe defaults)
        _pt_before = agent.llm.total_prompt_tokens
        _ct_before = agent.llm.total_completion_tokens
        response = ""
        _error: str | None = None

        # Keep-alive: send SSE comment every 15 s while LLM is running.
        # Prevents proxies / browsers from closing the connection during long
        # (>30 s) inferences (common with o3, Claude Opus, slow local models).
        _keepalive_stop = threading.Event()

        def _keepalive_worker():
            while not _keepalive_stop.wait(15):
                try:
                    self.wfile.write(b": keep-alive\n\n")
                    self.wfile.flush()
                except OSError:
                    break  # client gone

        _ka_thread = threading.Thread(target=_keepalive_worker, daemon=True)
        _ka_thread.start()

        # Non-blocking lock acquire — reject concurrent chats immediately
        if not self.session._lock.acquire(blocking=True, timeout=0.3):
            _keepalive_stop.set()
            emit({"type": "error", "text": "服务器正在处理另一个请求，请稍候再试"})
            emit({"type": "done", "text": ""})
            return
        try:
            _pt_before = agent.llm.total_prompt_tokens
            _ct_before = agent.llm.total_completion_tokens
            response = self.session.agent.chat(
                q,
                on_token=on_token,
                on_tool=on_tool,
                on_tool_result=on_tool_result,
                on_compress=on_compress,
            )
        except Exception as e:
            _error = _sanitize_error(str(e))
        finally:
            _keepalive_stop.set()
            # Always restore the base system prompt after this turn
            agent._system = _orig_system
            self.session._lock.release()

        if _error:
            emit({"type": "error", "text": _error})

        emit({"type": "done", "text": response})
        # Persist usage record to ~/.byoe/usage.jsonl (delta for this turn only)
        try:
            _append_usage_record(
                model=agent.llm.model,
                prompt_tokens=agent.llm.total_prompt_tokens - _pt_before,
                completion_tokens=agent.llm.total_completion_tokens - _ct_before,
                cost=agent.llm.estimated_cost,
            )
        except Exception:
            pass
        # Auto-save: silently save session every 10 messages, and at message 5
        try:
            msg_count = len(agent.messages)
            if msg_count >= 5 and (msg_count == 5 or msg_count % 10 == 0):
                from byoe.engine.session import save_session
                _auto_id = getattr(self.session, '_auto_save_id', None)
                saved_id = save_session(
                    messages=agent.messages,
                    model=agent.llm.model,
                    session_id=_auto_id,
                    changed_files=agent.changed_files,
                    prompt_tokens=agent.llm.total_prompt_tokens,
                    completion_tokens=agent.llm.total_completion_tokens,
                    estimated_cost=agent.llm.estimated_cost,
                )
                self.session._auto_save_id = saved_id
        except Exception:
            pass
        try:
            self.wfile.write(b"data: [DONE]\n\n")
            self.wfile.flush()
        except OSError:
            pass


# ─────────────────────────────────────────────────────────────────────────────
# PDEVI stage gate helpers
# ─────────────────────────────────────────────────────────────────────────────

def _sanitize_error(msg: str) -> str:
    """Strip home-directory paths and internal stack details from error messages
    before they are sent to the browser client.

    Prevents leaking paths like /home/user/.byoe/sessions/... or
    C:\\Users\\user\\ to the frontend.
    """
    import re as _re
    home = str(Path.home())
    # Replace home path with ~
    msg = msg.replace(home, "~")
    # Also normalize Windows-style backslash paths that may remain
    msg = _re.sub(r'[A-Za-z]:\\\\Users\\\\[^\\\\]+', '~', msg)
    # Trim to first 300 chars so huge tracebacks don't flood the client
    if len(msg) > 300:
        msg = msg[:297] + "…"
    return msg


def _append_usage_record(
    model: str,
    prompt_tokens: int,
    completion_tokens: int,
    cost: float | None,
) -> None:
    """Append one line to ~/.byoe/usage.jsonl for persistent usage tracking.

    prompt_tokens / completion_tokens should be the *delta* for this turn,
    not cumulative session totals.
    """
    import json as _json
    from datetime import datetime, timezone
    usage_dir = Path.home() / ".byoe"
    usage_dir.mkdir(parents=True, exist_ok=True)
    # Estimate per-turn cost from delta tokens using pricing table
    from byoe.engine.llm import _PRICING
    rates = None
    for prefix, r in _PRICING.items():
        if model.startswith(prefix):
            rates = r
            break
    if rates is None:
        rates = _PRICING.get(model)
    if rates and prompt_tokens + completion_tokens > 0:
        turn_cost = (prompt_tokens * rates[0] + completion_tokens * rates[1]) / 1_000_000
    else:
        turn_cost = None
    record = {
        "date": datetime.now(timezone.utc).isoformat(),
        "model": model,
        "prompt_tokens": prompt_tokens,
        "completion_tokens": completion_tokens,
        "total_tokens": prompt_tokens + completion_tokens,
        "cost": round(turn_cost, 8) if turn_cost is not None else None,
    }
    usage_path = usage_dir / "usage.jsonl"
    # Rotate at 5 MB to prevent unbounded disk growth
    _USAGE_MAX_BYTES = 5 * 1024 * 1024
    if usage_path.exists() and usage_path.stat().st_size > _USAGE_MAX_BYTES:
        from datetime import datetime as _dt_rot
        rotated = usage_path.with_suffix(f".{_dt_rot.now().strftime('%Y-%m-%d')}.jsonl")
        try:
            usage_path.rename(rotated)
        except OSError:
            pass  # rename failed (dest already exists) — keep appending
    with open(usage_path, "a", encoding="utf-8") as f:
        f.write(_json.dumps(record, ensure_ascii=False) + "\n")


def _build_pdevi_gate(cwd: Path) -> str:
    """Inspect the active Crew changes and build a per-turn phase constraint.

    Returns a string to append to the system prompt, or "" if no constraints
    are applicable (no crew workspace, no active changes, etc.).
    """
    import re
    changes_dir = cwd / "crew" / "changes"
    if not changes_dir.exists():
        return ""

    gates: list[str] = []
    for d in changes_dir.iterdir():
        if not d.is_dir():
            continue
        proposal = d / "proposal.md"
        if not proposal.exists():
            continue
        try:
            txt = proposal.read_text(encoding="utf-8")
        except OSError:
            continue
        fm_match = re.match(r"^---\n(.*?)\n---", txt, re.DOTALL)
        if not fm_match:
            continue
        fm = fm_match.group(1)
        pc_m = re.search(r"^plan_confirmed:\s*(\S+)", fm, re.MULTILINE)
        plan_confirmed = (pc_m.group(1).lower() == "true") if pc_m else False
        mode_m = re.search(r"^mode:\s*(\S+)", fm, re.MULTILINE)
        mode = mode_m.group(1) if mode_m else "standard"

        if not plan_confirmed:
            gates.append(
                f"⚠️  PDEVI STAGE GATE — change `{d.name}` is in **Plan** phase.\n"
                f"   Do NOT proceed to Design or Execute until the user explicitly "
                f"confirms the proposal (sets plan_confirmed: true in proposal.md).\n"
                f"   Your job right now: help the user review and refine proposal.md."
            )
        elif not (d / "design.md").exists() and mode == "standard":
            gates.append(
                f"ℹ️  PDEVI STAGE GATE — change `{d.name}` plan is confirmed.\n"
                f"   Next step: create crew/changes/{d.name}/design.md with "
                f"## Technical Decisions and ## Task Breakdown sections."
            )

    if not gates:
        return ""
    return (
        "\n\n---\n# PDEVI Stage Gates (auto-enforced)\n"
        + "\n\n".join(gates)
        + "\n"
    )


# ─────────────────────────────────────────────────────────────────────────────
# Public entry point
# ─────────────────────────────────────────────────────────────────────────────

def start_web(
    host: str = "127.0.0.1",
    port: int = 7860,
    open_browser: bool = True,
    model: str | None = None,
    resume: str | None = None,
    allow_origins: list[str] | None = None,
) -> None:
    """Build agent, start ThreadingHTTPServer, optionally open browser.

    allow_origins:
      None / []          → only localhost/127.0.0.1 (default, most secure)
      ["*"]              → allow any origin (open LAN access)
      ["http://foo:3000"]→ allow specific origins
    """
    from byoe.engine.config import Config
    from byoe.engine.llm import LLM
    from byoe.engine.agent import Agent
    from byoe import __version__

    config = Config.from_env()
    if model:
        config.model = model
    if not config.api_key:
        print(
            "Error: API Key not found.\n"
            "Set BYOE_API_KEY / OPENAI_API_KEY / DEEPSEEK_API_KEY / ANTHROPIC_API_KEY"
        )
        sys.exit(1)

    llm = LLM(
        model=config.model,
        api_key=config.api_key,
        base_url=config.base_url,
        temperature=config.temperature,
        max_tokens=config.max_tokens,
    )
    agent = Agent(llm=llm, max_context_tokens=config.max_context_tokens, cwd=os.getcwd())

    # Sandbox: restrict bash commands to the working directory tree
    _cwd = os.getcwd()
    from byoe.engine.tools.bash import BashTool
    for _t in agent.tools:
        if isinstance(_t, BashTool):
            _t.set_sandbox_root(_cwd)
            break

    # Resume an existing session if requested
    if resume:
        from byoe.engine.session import load_session
        loaded = load_session(resume)
        if loaded:
            msgs, sess_model, changed = loaded
            agent.messages = msgs
            agent.changed_files.update(changed)
            if not model:          # don't override explicit --model flag
                agent.llm.model = sess_model
                config.model = sess_model
            print(f"  Resumed: {resume}  ({len(msgs)} messages)")
        else:
            print(f"  Warning: session '{resume}' not found, starting fresh.")

    token = secrets.token_urlsafe(16)
    cwd = os.getcwd()

    # Inject handler's session reference via class attribute
    # (avoids global state while keeping BaseHTTPRequestHandler compatible)
    session = WebSession(agent=agent, config=config, token=token, cwd=cwd)
    ByoeHandler.session = session  # type: ignore[attr-defined]
    # Inject CORS policy (class-level so all request threads share it)
    ByoeHandler._allowed_origins = allow_origins or []  # type: ignore[attr-defined]

    # Set bash sandbox root so the agent cannot cd outside the project directory
    try:
        bash_tool = next((t for t in agent.tools if t.name == "bash"), None)
        if bash_tool and hasattr(bash_tool, 'set_sandbox_root'):
            bash_tool.set_sandbox_root(cwd)
            bash_tool.set_cwd(cwd)
    except Exception:
        pass

    # Ensure agent._cwd matches session cwd (may differ from os.getcwd() if
    # user passed a different --cwd in future)
    agent._cwd = cwd

    try:
        server = ThreadingHTTPServer((host, port), ByoeHandler)
    except OSError as e:
        if "Address already in use" in str(e) or e.errno in (98, 48, 10048):
            print(
                f"\n❌  Port {port} is already in use.\n"
                f"    Try a different port:  byoe web --port {port + 1}\n"
                f"    Or kill the process:   lsof -ti:{port} | xargs kill\n"
            )
        else:
            print(f"\n❌  Failed to start server: {e}\n")
        sys.exit(1)

    # Put auth token in URL fragment so it is never sent to the server as part
    # of HTTP requests (history and screenshots aside, this avoids log/referrer leaks).
    url = f"http://{host}:{port}/#token={token}"

    print("=" * 60)
    print(f"  BYOE Web UI  —  v{_byoe_version()}")
    print(f"  Model : {config.model}")
    print(f"  CWD   : {cwd}")
    print("=" * 60)
    print(f"\n  URL:  {url}\n")
    print("  Ctrl+C to stop\n")

    if open_browser:
        # Delay slightly so the server is ready before the browser connects
        threading.Timer(0.8, webbrowser.open, args=(url,)).start()

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nStopped.")
        session.close()
        server.server_close()


def _byoe_version() -> str:
    try:
        from byoe import __version__
        return __version__
    except Exception:
        return "?"
