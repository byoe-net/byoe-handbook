from __future__ import annotations

import argparse
from pathlib import Path
from byoe.engine.tools.sober import scan_sober
from byoe.orchestrator.utils import cyan, green, red, yellow

def run_sober(args: argparse.Namespace) -> int:
    """Run sober code analysis as a standalone CLI command."""     
    target = args.path

    try:
        res = scan_sober(target)
    except Exception as e:
        print(red(f"❌ 扫描过程中发生错误: {e}"))
        return 1

    if args.format == "md":
        # === Generate Markdown Output ===
        lines = [f"# Sober Scan Report - {res.path}"]
        lines.append(f"**Score**: {res.score}/100 ({res.level})")  
        lines.append(f"**Files scanned**: {res.files}  **Lines**: {res.lines}")
        lines.append("\n## Issues Detected\n")
        
        if not res.issues:
            lines.append("No technical debt found. Excellent!")
        else:
            # Sort by criticality
            severity_order = {"critical": 0, "high": 1, "medium": 2, "low": 3}
            issues = sorted(res.issues, key=lambda i: severity_order.get(i.severity, 4))
            for issue in issues:
                loc = f"{issue.file}:{issue.line}" if issue.line else issue.file
                lines.append(f"- **[{issue.severity.upper()}]** {issue.id}: {issue.title}")
                lines.append(f"  - Location: `{loc}`")
                lines.append(f"  - Detail: {issue.detail}\n")
                
        out_content = "\n".join(lines)
        if args.out:
            Path(args.out).write_text(out_content, encoding="utf-8")
            print(green(f"✅ Markdown 报告已成功导出至: {args.out}"))
        else:
            print(out_content)
        return 0 if res.score >= 80 else 1

    # === Default Console Output ===
    print(cyan(f"🔎 启动 Sober Coding 深度分析 (目标: {target})"))
    print(cyan("该工具将使用启发式规则扫描项目技术债和 AI 坏味道...\n"))
    
    color = green if res.score >= 80 else (yellow if res.score >= 40 else red)
    print(f"📊 综合评分: {color(str(res.score))}/100 ({res.level})")
    print(f"📂 扫描范围: 共检测了 {res.files} 个文件, {res.lines} 行代码")
    
    if not res.issues:
        print(green("\n🎉 太棒了！你的代码极其干净，没有任何被检测出的技术债！"))
        return 0

    print(yellow(f"\n⚠️ 发现 {len(res.issues)} 处问题 (按严重程度排列):"))
    
    # Sort by criticality (CRITICAL -> HIGH -> MEDIUM -> LOW)      
    severity_order = {"critical": 0, "high": 1, "medium": 2, "low": 3}
    issues = sorted(res.issues, key=lambda i: severity_order.get(i.severity, 4))
    
    for issue in issues:
        sev_color = red if issue.severity == "critical" else (yellow if issue.severity == "high" else cyan)
        loc = f"{issue.file}:{issue.line}" if issue.line else issue.file
        print(f"\n[{sev_color(issue.severity.upper())}] {issue.id} - {issue.title}")
        print(f"  📍 坐标: {loc}")
        print(f"  💡 详情: {issue.detail}")

    print("\n" + cyan("-" * 50))
    print("🤖 提示: 你可以在终端输入 `byoe chat` 并告诉 AI: '帮我修复 sober 刚刚扫描出的问题' 来进行自动清理。")

    if args.out:
        import re as _re
        def _strip_ansi(text: str) -> str:
            return _re.sub(r'\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])', '', text)

        # Rebuild a clean plain-text version (no ANSI) for file output
        plain_lines = [
            f"Sober Scan Report - {res.path}",
            f"Score: {res.score}/100 ({res.level})",
            f"Files scanned: {res.files}  Lines: {res.lines}",
            "",
            f"Issues Detected ({len(res.issues)} total):",
            "",
        ]
        severity_order = {"critical": 0, "high": 1, "medium": 2, "low": 3}
        for issue in sorted(res.issues, key=lambda i: severity_order.get(i.severity, 4)):
            loc = f"{issue.file}:{issue.line}" if issue.line else issue.file
            plain_lines.append(f"[{issue.severity.upper()}] {issue.id} - {issue.title}")
            plain_lines.append(f"  Location: {loc}")
            plain_lines.append(f"  Detail: {issue.detail}")
            plain_lines.append("")
        plain_lines.append("Tip: run `byoe chat` and ask AI to fix sober issues.")
        Path(args.out).write_text("\n".join(plain_lines), encoding="utf-8")
        print(green(f"\n✅ 报告已保存至: {args.out}"))

    return 0 if res.score >= 80 else 1
