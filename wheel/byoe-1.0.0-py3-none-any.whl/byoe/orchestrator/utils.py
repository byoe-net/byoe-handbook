"""公共工具函数"""
from __future__ import annotations

import os
import re
import json
from pathlib import Path


def pkg_root() -> Path:
    """返回 byoe 包根目录（templates/ 和 agents/ 所在处）"""
    return Path(__file__).parent.parent


def pkg_agents_dir() -> Path:
    """返回专家 agents 目录。

    优先使用包内 `byoe/agents/`（安装态与规范开发态），
    兼容历史仓库布局 `./agents/`。
    """
    in_package = pkg_root() / "agents"
    if in_package.exists():
        return in_package

    legacy_root = pkg_root().parent / "agents"
    if legacy_root.exists():
        return legacy_root

    # 默认返回规范路径，便于调用方给出稳定错误提示
    return in_package


def infer_project_name(cwd: Path) -> str:
    """从 package.json / pyproject.toml / 目录名推断项目名称"""
    pkg_json = cwd / "package.json"
    if pkg_json.exists():
        try:
            data = json.loads(pkg_json.read_text(encoding="utf-8"))
            if data.get("name"):
                return data["name"]
        except Exception:
            pass

    pyproject = cwd / "pyproject.toml"
    if pyproject.exists():
        try:
            text = pyproject.read_text(encoding="utf-8")
            m = re.search(r'^name\s*=\s*["\'](.+?)["\']', text, re.MULTILINE)
            if m:
                return m.group(1)
        except Exception:
            pass

    return cwd.name


def to_kebab_case(text: str) -> str:
    text = text.strip()
    text = re.sub(r"[\s_/\\]+", "-", text)
    text = re.sub(r"[^a-zA-Z0-9\u4e00-\u9fff\-]", "", text)
    text = re.sub(r"-+", "-", text).strip("-")
    return text.lower()


def color(text: str, code: str) -> str:
    if not _supports_color():
        return text
    return f"\033[{code}m{text}\033[0m"


def _supports_color() -> bool:
    if os.environ.get("NO_COLOR"):
        return False
    if os.environ.get("FORCE_COLOR"):
        return True
    return hasattr(os.sys.stdout, "isatty") and os.sys.stdout.isatty()


def green(text: str) -> str:  return color(text, "32")
def yellow(text: str) -> str: return color(text, "33")
def cyan(text: str) -> str:   return color(text, "36")
def bold(text: str) -> str:   return color(text, "1")
def red(text: str) -> str:    return color(text, "31")
