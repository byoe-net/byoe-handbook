"""BYOE CLI — 统一入口

卜一智航（BYOE）· byoe.net
携智而来，决策随行 — Bring Your Own Executive AI

子命令:
  byoe init                  初始化 Crew 工作区
  byoe plan <name>           创建新变更计划
  byoe status                查看工作区状态
  byoe release               归档已完成变更
  byoe agents                列出领域专家
  byoe run [tool]            启动 AI 工具（默认内置 Agent）
  byoe chat                  交互式内置 Agent（同 byoe run）
  byoe web                   启动 Web 管控界面（浏览器 UI）
  byoe loop                  时间驱动的自动执行循环（Loop Engineering）
  byoe metrics               查看 Token 用量与费用统计
  byoe memory search <q>     搜索记忆
  byoe memory list           列出所有记忆
  byoe memory show <path>    查看指定记忆
  byoe memory forget <path>  删除指定记忆
  byoe memory stats          统计记忆数量与分布
  byoe version               显示版本信息
"""
from __future__ import annotations

import argparse
import sys

from byoe import __version__

# Optional shell autocompletion (pip install argcomplete)
try:
    import argcomplete as _argcomplete
except ImportError:
    _argcomplete = None  # type: ignore[assignment]


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="byoe",
        description="卜一智航 (BYOE) — 携智而来，决策随行\nAI 开发团队编排 + 内置多模型编程 Agent | byoe.net",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  byoe init                         初始化 Crew 工作区
  byoe plan login-feature           创建新变更计划
  byoe status                       查看所有活跃变更状态
  byoe chat                         启动内置 AI Agent（自动注入项目上下文）
  byoe chat -m deepseek-chat        使用 DeepSeek 模型
  byoe chat -r session_xxx          恢复上次对话
  byoe run                          同 byoe chat
  byoe run claude                   启动 Claude Code 并注入上下文
  byoe run opencode                 启动 OpenCode 并注入上下文
  byoe run aider                    启动 Aider 并注入上下文
  byoe run cursor                   打开 Cursor 并写入 .cursorrules
  byoe agents                       列出所有可用的领域专家
  byoe release                      归档已完成变更
  byoe sessions                     列出已保存的对话会话
  byoe sessions show <id>           查看会话详情
  byoe sessions delete <id>         删除会话
  byoe web                          启动 Web 管控界面（浏览器自动打开）
  byoe web --port 8080 --no-browser 在 8080 端口启动，不打开浏览器
  byoe web --host 0.0.0.0 --allow-origins '*'  局域网多设备访问
  byoe mcp-server                   以 MCP 服务端模式运行（供 VS Code / Claude Desktop 接入）
  byoe mcp-server --http --port 3000  HTTP 模式
    byoe loop -p "扫描并修复当前仓库 High 风险问题" --every 30m
    byoe loop -p "生成日报" --at 09:00 --max-runs 1
        """,
    )
    parser.add_argument("--version", "-v", action="version", version=f"byoe {__version__}")

    subparsers = parser.add_subparsers(dest="command", metavar="<command>")

    # ── doctor ───────────────────────────────────────────────────────────────
    subparsers.add_parser("doctor", help="检查配置与 LLM 连通性")

    # ── init ──────────────────────────────────────────────────────────────────
    init_parser = subparsers.add_parser("init", help="初始化 Crew 工作区")
    init_parser.add_argument("--name", "-n", metavar="NAME", help="项目名称")
    init_parser.add_argument(
        "--no-gitignore", dest="gitignore", action="store_false", default=True,
        help="不自动添加 .gitignore 规则",
    )
    init_parser.add_argument("--prd", metavar="FILE", help="导入已有需求文档（PRD）")
    init_parser.add_argument("--scan", action="store_true", default=False, help="扫描代码库建立基线")

    # ── plan ──────────────────────────────────────────────────────────────────
    plan_parser = subparsers.add_parser("plan", help="创建新变更计划")
    plan_parser.add_argument("name", nargs="?", metavar="NAME", help="变更名称（kebab-case）")
    plan_parser.add_argument("--express", action="store_true", help="快速模式（Bug 修复）")
    plan_parser.add_argument("--prototype", action="store_true", help="原型模式（快速验证）")

    # ── status ────────────────────────────────────────────────────────────────
    subparsers.add_parser("status", help="查看所有活跃变更状态")

    # ── release ───────────────────────────────────────────────────────────────
    subparsers.add_parser("release", help="归档已完成变更")

    # ── agents ────────────────────────────────────────────────────────────────
    agents_parser = subparsers.add_parser("agents", help="列出所有可用的领域专家")
    agents_parser.add_argument(
        "--category", "-c", metavar="CAT",
        help="按分类过滤（如 engineering、game、design）",
    )
    agents_parser.add_argument(
        "--show", "-s", metavar="ID",
        help="查看指定专家的完整详情（支持部分匹配）",
    )

    # ── sessions ──────────────────────────────────────────────────────────────
    sessions_parser = subparsers.add_parser("sessions", help="管理已保存的对话会话")
    sessions_sub = sessions_parser.add_subparsers(dest="sessions_action", metavar="<action>")

    sessions_sub.add_parser("list", help="列出最近保存的会话（默认）")

    show_s = sessions_sub.add_parser("show", help="查看会话详情（消息历史 + 修改文件）")
    show_s.add_argument("id", metavar="SESSION_ID")

    del_s = sessions_sub.add_parser("delete", help="删除一个已保存的会话")
    del_s.add_argument("id", metavar="SESSION_ID")

    # ── run ───────────────────────────────────────────────────────────────────
    run_parser = subparsers.add_parser(
        "run",
        help="启动 AI 编程工具（默认: 内置 Agent）",
    )
    run_parser.add_argument(
        "tool",
        nargs="?",
        default=None,
        choices=["claude", "opencode", "aider", "cursor"],
        metavar="TOOL",
        help="外部工具: claude | opencode | aider | cursor（省略则启动内置 Agent）",
    )
    run_parser.add_argument(
        "--no-inject", dest="inject", action="store_false", default=True,
        help="不注入 INSTRUCTIONS.md 上下文（仅外部工具有效）",
    )
    run_parser.add_argument("-m", "--model", help="模型名称（仅内置 Agent，覆盖 BYOE_MODEL）")
    run_parser.add_argument("-p", "--prompt", help="单次提示模式，执行后退出（仅内置 Agent）")
    run_parser.add_argument("-r", "--resume", metavar="ID", help="恢复已保存的会话（仅内置 Agent）")

    # ── chat ──────────────────────────────────────────────────────────────────
    chat_parser = subparsers.add_parser("chat", help="启动内置 AI Agent（同 byoe run）")
    chat_parser.add_argument("-m", "--model", help="模型名称（覆盖 BYOE_MODEL 环境变量）")
    chat_parser.add_argument(
        "-p", "--prompt", help="单次提示模式（非交互式，执行后退出）"
    )
    chat_parser.add_argument("-r", "--resume", metavar="ID", help="恢复已保存的会话")

    # ── web ───────────────────────────────────────────────────────────────────
    web_parser = subparsers.add_parser("web", help="启动 Web 管控界面（浏览器 UI）")
    web_parser.add_argument(
        "--port", "-p", type=int, default=7860,
        help="监听端口（默认 7860）",
    )
    web_parser.add_argument(
        "--host", default="127.0.0.1",
        help="绑定地址（默认 127.0.0.1，局域网访问可设为 0.0.0.0）",
    )
    web_parser.add_argument(
        "--no-browser", action="store_true", default=False,
        help="不自动打开浏览器",
    )
    web_parser.add_argument(
        "--allow-origins", default="",
        help="允许的 CORS 来源（多个用逗号分隔）",
    )
    web_parser.add_argument(
        "-m", "--model", default=None,
        help="覆盖默认模型（可选）",
    )
    web_parser.add_argument(
        "-r", "--resume", default=None,
        help="恢复已保存会话 ID（可选）",
    )
    web_parser.add_argument(
        "--cwd", default="",
        help="启动前切换到指定工作目录",
    )

    # ── loop ──────────────────────────────────────────────────────────────────
    loop_parser = subparsers.add_parser("loop", help="启动时间驱动的 Loop Engineering 自动执行模式")
    loop_parser.add_argument(
        "-p", "--prompt", required=True,
        help="每次循环执行的任务提示词",
    )
    loop_parser.add_argument(
        "--every", default="60m",
        help="循环间隔（如 30s / 5m / 1h，默认 60m）",
    )
    loop_parser.add_argument(
        "--at", default="",
        help="每天固定时间执行（HH:MM，优先于 --every）",
    )
    loop_parser.add_argument(
        "--max-runs", type=int, default=0,
        help="最大执行次数（0 表示无限循环）",
    )
    loop_parser.add_argument(
        "--cwd", default="",
        help="执行目录（默认当前目录）",
    )
    loop_parser.add_argument(
        "-m", "--model", help="模型名称（覆盖 BYOE_MODEL）",
    )

    # ── mcp-server ────────────────────────────────────────────────────────────
    mcp_parser = subparsers.add_parser(
        "mcp-server",
        help="以 MCP 服务端模式运行，将 BYOE 工具暴露给 VS Code / Claude Desktop / Cursor",
    )
    mcp_parser.add_argument(
        "--http", action="store_true", default=False,
        help="使用 HTTP 传输（默认 stdio）",
    )
    mcp_parser.add_argument(
        "--host", default="127.0.0.1",
        help="HTTP 绑定地址（默认 127.0.0.1）",
    )
    mcp_parser.add_argument(
        "--port", type=int, default=3000,
        help="HTTP 端口（默认 3000）",
    )
    mcp_parser.add_argument(
        "--cwd", default="",
        help="工作目录（默认当前目录）",
    )

    # ── sober ─────────────────────────────────────────────────────────────────
    sober_parser = subparsers.add_parser("sober", help="执行 Sober Coding 代码质量与技术债务体检")
    sober_parser.add_argument("path", nargs="?", default=".", help="需要扫描的目录 (默认: 当前目录)")
    sober_parser.add_argument("--format", choices=["console", "md"], default="console", help="输出格式: console (默认) 或 md (Markdown 格式)")
    sober_parser.add_argument("--out", metavar="FILE", help="将输出保存到文件（例如 report.md）")

    # ── version ───────────────────────────────────────────────────────────────
    subparsers.add_parser("version", help="显示版本信息")

    # ── memory ────────────────────────────────────────────────────────────────
    memory_parser = subparsers.add_parser("memory", help="管理 Agent 记忆（搜索 / 列出 / 查看 / 删除）")
    mem_sub = memory_parser.add_subparsers(dest="memory_action")

    mem_search_p = mem_sub.add_parser("search", help="全文 + 语义搜索记忆")
    mem_search_p.add_argument("query", help="搜索关键词")
    mem_search_p.add_argument("--limit", "-n", type=int, default=5, metavar="N", help="返回条数")

    mem_list_p = mem_sub.add_parser("list", help="列出所有记忆")
    mem_list_p.add_argument("--layer", default=None,
                            help="按 layer 过滤 (knowledge / session / short_term)")
    mem_list_p.add_argument("--limit", "-n", type=int, default=20, metavar="N")

    mem_show_p = mem_sub.add_parser("show", help="显示指定路径的完整记忆内容")
    mem_show_p.add_argument("path", help="记忆路径，例如 /project/notes")

    mem_forget_p = mem_sub.add_parser("forget", help="删除指定路径的记忆")
    mem_forget_p.add_argument("path", help="记忆路径")

    mem_sub.add_parser("stats", help="统计记忆总数与各 layer 分布")

    # ── metrics ───────────────────────────────────────────────────────────────
    metrics_parser = subparsers.add_parser("metrics", help="查看 Token 用量与费用统计")
    metrics_parser.add_argument(
        "--days", type=int, default=30, metavar="N",
        help="统计最近 N 天（默认 30 天，0 = 全部）",
    )
    metrics_parser.add_argument(
        "--model", default=None, metavar="MODEL",
        help="只显示指定模型的记录",
    )
    metrics_parser.add_argument(
        "--json", action="store_true",
        help="以 JSON 格式输出原始汇总数据",
    )
    metrics_parser.add_argument(
        "--reindex-memory", action="store_true",
        help="为所有缺少向量的记忆生成 embedding（需设置 BYOE_EMBEDDING_MODEL）",
    )

    # Enable shell autocompletion if argcomplete is installed
    if _argcomplete is not None:
        _argcomplete.autocomplete(parser)

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        sys.exit(0)

    # ── dispatch ──────────────────────────────────────────────────────────────

    if args.command == "doctor":
        _run_doctor()

    elif args.command == "init":
        from byoe.orchestrator.commands.init import init_command
        init_command(
            name=args.name,
            gitignore=args.gitignore,
            prd=getattr(args, "prd", None),
            scan=getattr(args, "scan", False),
        )

    elif args.command == "plan":
        from byoe.orchestrator.commands.plan import plan_command
        plan_command(
            name=getattr(args, "name", None),
            express=getattr(args, "express", False),
            prototype=getattr(args, "prototype", False),
        )

    elif args.command == "status":
        from byoe.orchestrator.commands.status import status_command
        status_command()

    elif args.command == "release":
        from byoe.orchestrator.commands.release import release_command
        release_command()

    elif args.command == "agents":
        from byoe.orchestrator.commands.agents import run_agents
        sys.exit(run_agents(args))

    elif args.command == "sober":
        from byoe.orchestrator.commands.sober import run_sober
        sys.exit(run_sober(args))

    elif args.command == "sessions":
        from byoe.chat import _list_sessions, _show_session, _delete_session
        if args.sessions_action == "list" or not args.sessions_action:
            _list_sessions(args)
        elif args.sessions_action == "show":
            _show_session(args)
        elif args.sessions_action == "delete":
            _delete_session(args)
        else:
            parser.print_help()
            sys.exit(1)

    elif args.command == "run":
        tool = getattr(args, "tool", None)
        if tool is None:
            # 内置 Agent（可带 -m / -r 参数）
            _run_chat(args)
        else:
            from byoe.orchestrator.commands.run import run_command
            run_command(tool=tool, inject=getattr(args, "inject", True))

    elif args.command == "chat":
        _run_chat(args)

    elif args.command == "web":
        from byoe.web import start_web
        import os as _os
        _web_cwd = getattr(args, "cwd", None)
        if _web_cwd:
            _web_cwd = _os.path.abspath(_web_cwd)
            if not _os.path.isdir(_web_cwd):
                print(f"Error: --cwd directory not found: {_web_cwd}")
                sys.exit(1)
            _os.chdir(_web_cwd)
        start_web(
            host=args.host,
            port=args.port,
            open_browser=(not args.no_browser),
            model=getattr(args, "model", None),
            resume=getattr(args, "resume", None),
            allow_origins=[o.strip() for o in args.allow_origins.split(",")]
                          if getattr(args, "allow_origins", None) else None,
        )

    elif args.command == "mcp-server":
        import os as _os
        from byoe.engine.mcp_server import run_stdio, run_http
        _mcp_cwd = getattr(args, "cwd", "") or None
        if _mcp_cwd:
            _mcp_cwd = _os.path.abspath(_mcp_cwd)
        if getattr(args, "http", False):
            run_http(host=args.host, port=args.port, cwd=_mcp_cwd)
        else:
            run_stdio(cwd=_mcp_cwd)

    elif args.command == "loop":
        _run_loop(args)

    elif args.command == "metrics":
        _run_metrics(args)

    elif args.command == "memory":
        _run_memory(args)

    elif args.command == "version":
        _run_version()

    else:
        parser.print_help()
        sys.exit(1)


def _run_sessions(args) -> None:
    """Handle `byoe sessions [list|show|delete]`."""
    from byoe.engine.session import list_sessions, load_session, delete_session
    from rich.console import Console
    from rich.table import Table

    console = Console()
    action = getattr(args, "sessions_action", None) or "list"

    if action == "list" or action is None:
        sessions = list_sessions()
        if not sessions:
            console.print("[dim]No saved sessions found.[/dim]")
            console.print("Start a chat and type [bold]/save[/bold] to create one.")
            return
        table = Table(title="Saved Sessions", show_lines=True)
        table.add_column("ID", style="cyan", no_wrap=True)
        table.add_column("Model", style="green")
        table.add_column("Saved At")
        table.add_column("Tokens", style="yellow")
        table.add_column("Cost", style="magenta")
        table.add_column("Files", style="yellow")
        table.add_column("Preview", max_width=50)
        for s in sessions:
            cost = s.get("estimated_cost")
            cost_str = f"${cost:.4f}" if cost is not None else "-"
            tokens = s.get("total_tokens")
            tokens_str = f"{tokens:,}" if tokens else "-"
            table.add_row(
                s["id"],
                s["model"],
                s["saved_at"],
                tokens_str,
                cost_str,
                str(len(s.get("changed_files", []))),
                s["preview"],
            )
        console.print(table)
        console.print(f"\nResume: [bold]byoe chat -r <SESSION_ID>[/bold]")

    elif action == "show":
        sid = args.id
        loaded = load_session(sid)
        if not loaded:
            console.print(f"[red]Session '{sid}' not found.[/red]")
            return
        messages, model, changed_files = loaded
        console.print(f"\n[bold]Session:[/bold] {sid}  ([cyan]{model}[/cyan])")
        console.print(f"[bold]Messages:[/bold] {len(messages)}")
        if changed_files:
            console.print(f"\n[bold]Files modified ({len(changed_files)}):[/bold]")
            for f in sorted(changed_files):
                console.print(f"  [cyan]{f}[/cyan]")
        console.print(f"\n[bold]History:[/bold]")
        for m in messages:
            role = m.get("role", "?")
            content = (m.get("content") or "")[:200]
            if content:
                color = {"user": "blue", "assistant": "green"}.get(role, "dim")
                console.print(f"  [{color}]{role}[/{color}]: {content}")

    elif action == "delete":
        sid = args.id
        if delete_session(sid):
            console.print(f"[green]Deleted session: {sid}[/green]")
        else:
            console.print(f"[red]Session '{sid}' not found.[/red]")


def _run_chat(args) -> None:
    """启动内置 Agent，处理 -m / -p / -r 参数。"""
    from byoe.engine.config import Config
    from byoe.engine.llm import LLM
    from byoe.engine.agent import Agent
    from byoe.engine.session import load_session
    from byoe.chat import run_repl

    config = Config.from_env()

    model = getattr(args, "model", None)
    resume_id = getattr(args, "resume", None)
    one_shot = getattr(args, "prompt", None)

    if model:
        config.model = model

    if not config.api_key:
        from byoe.orchestrator.utils import red
        print(red("❌ 未找到 API Key"))
        print(
            "请设置: BYOE_API_KEY / OPENAI_API_KEY / DEEPSEEK_API_KEY\n\n"
            "示例 (Windows PowerShell):\n"
            "  $env:OPENAI_API_KEY='sk-...'\n"
            "  $env:BYOE_MODEL='deepseek-chat'\n"
            "  $env:OPENAI_BASE_URL='https://api.deepseek.com'\n"
        )
        import sys; sys.exit(1)

    llm = LLM(
        model=config.model,
        api_key=config.api_key,
        base_url=config.base_url,
        temperature=config.temperature,
        max_tokens=config.max_tokens,
    )
    agent = Agent(llm=llm, max_context_tokens=config.max_context_tokens)

    if resume_id:
        loaded = load_session(resume_id)
        if loaded:
            agent.messages, loaded_model, loaded_files = loaded
            agent.changed_files.update(loaded_files)
            if not model:
                agent.llm.model = loaded_model
                config.model = loaded_model
            from rich.console import Console
            Console().print(f"[green]Resumed session: {resume_id} (model: {agent.llm.model})[/green]")
        else:
            from rich.console import Console
            Console().print(f"[red]Session '{resume_id}' not found.[/red]")
            import sys; sys.exit(1)

    if one_shot:
        _run_once(agent, one_shot)
    else:
        run_repl(agent, config)


def _run_loop(args) -> None:
    """Time-driven autonomous execution loop (openclaw-like loop engineering)."""
    import os
    import time
    from datetime import datetime, timedelta

    from byoe.engine.config import Config
    from byoe.engine.llm import LLM
    from byoe.engine.agent import Agent
    from rich.console import Console

    def _parse_every(spec: str) -> float:
        s = (spec or "").strip().lower()
        if not s:
            return 3600.0
        if s.endswith("s"):
            return float(s[:-1])
        if s.endswith("m"):
            return float(s[:-1]) * 60.0
        if s.endswith("h"):
            return float(s[:-1]) * 3600.0
        return float(s)

    def _next_daily(at_hhmm: str) -> datetime:
        hh, mm = at_hhmm.split(":", 1)
        now = datetime.now()
        target = now.replace(hour=int(hh), minute=int(mm), second=0, microsecond=0)
        if target <= now:
            target = target + timedelta(days=1)
        return target

    console = Console()
    cfg = Config.from_env()
    if args.model:
        cfg.model = args.model

    if args.cwd:
        os.chdir(os.path.abspath(args.cwd))

    if not cfg.api_key:
        console.print("[red]❌ 未找到 API Key（BYOE_API_KEY / OPENAI_API_KEY / DEEPSEEK_API_KEY）[/red]")
        sys.exit(1)

    llm = LLM(
        model=cfg.model,
        api_key=cfg.api_key,
        base_url=cfg.base_url,
        temperature=cfg.temperature,
        max_tokens=cfg.max_tokens,
    )
    agent = Agent(llm=llm, max_context_tokens=cfg.max_context_tokens, cwd=os.getcwd())

    max_runs = max(0, int(args.max_runs or 0))
    run_count = 0

    console.print("[bold cyan]BYOE Loop Engineering[/bold cyan] 已启动")
    console.print(f"模型: [cyan]{cfg.model}[/cyan]  目录: [cyan]{os.getcwd()}[/cyan]")
    if args.at:
        console.print(f"模式: 每天 [cyan]{args.at}[/cyan] 定时执行")
    else:
        interval = _parse_every(args.every)
        console.print(f"模式: 每 [cyan]{args.every}[/cyan] 执行一次")
    if max_runs:
        console.print(f"最大执行次数: [cyan]{max_runs}[/cyan]")

    while True:
        if max_runs and run_count >= max_runs:
            console.print("[green]Loop 完成：达到最大执行次数，退出。[/green]")
            break

        # Sleep until next run
        if run_count > 0:
            if args.at:
                nxt = _next_daily(args.at)
                wait_s = max(0.0, (nxt - datetime.now()).total_seconds())
            else:
                wait_s = _parse_every(args.every)
            console.print(f"[dim]等待下一次执行：{int(wait_s)} 秒...[/dim]")
            time.sleep(wait_s)

        run_count += 1
        console.print(f"\n[bold]=== Loop Run #{run_count} ===[/bold]")

        streamed = []

        def on_token(tok: str):
            streamed.append(tok)
            print(tok, end="", flush=True)

        def on_tool(name, kwargs):
            brief = ", ".join(f"{k}={repr(v)[:40]}" for k, v in kwargs.items())
            console.print(f"\n[dim]⚙ {name}({brief[:120]})[/dim]")

        try:
            agent.chat(args.prompt, on_token=on_token, on_tool=on_tool)
            if streamed:
                print()
        except KeyboardInterrupt:
            console.print("\n[yellow]收到中断，退出 Loop。[/yellow]")
            break
        except Exception as e:
            console.print(f"[red]Loop 执行异常: {e}[/red]")


def _run_once(agent, prompt: str) -> None:
    def on_token(tok):
        print(tok, end="", flush=True)

    from rich.console import Console
    console = Console()

    def on_tool(name, kwargs):
        s = ", ".join(f"{k}={repr(v)[:40]}" for k, v in kwargs.items())
        console.print(f"\n[dim]> {name}({s[:80]})[/dim]")

    agent.chat(prompt, on_token=on_token, on_tool=on_tool)
    print()


def _run_metrics(args) -> None:
    """byoe metrics — show token usage and cost aggregated from ~/.byoe/usage.jsonl."""

    if getattr(args, "reindex_memory", False):
        _run_memory_reindex()
        return
    import json as _json
    import glob
    from pathlib import Path
    from datetime import datetime, timezone, timedelta
    from collections import defaultdict

    usage_dir = Path.home() / ".byoe"
    # Collect all usage files: current + rotated archives
    files = sorted(usage_dir.glob("usage*.jsonl"))
    if not files:
        print("No usage data found. Usage is recorded when byoe web is running.")
        return

    cutoff = None
    if args.days > 0:
        cutoff = datetime.now(timezone.utc) - timedelta(days=args.days)

    model_filter = getattr(args, "model", None)

    # Parse records
    records: list[dict] = []
    for f in files:
        try:
            for line in f.read_text(encoding="utf-8").splitlines():
                line = line.strip()
                if not line:
                    continue
                try:
                    rec = _json.loads(line)
                except Exception:
                    continue
                if model_filter and rec.get("model") != model_filter:
                    continue
                if cutoff:
                    try:
                        rec_dt = datetime.fromisoformat(rec["date"])
                        if rec_dt < cutoff:
                            continue
                    except Exception:
                        pass
                records.append(rec)
        except Exception:
            continue

    if not records:
        print(f"No records found{f' for model {model_filter}' if model_filter else ''}"
              f"{f' in the last {args.days} days' if args.days else ''}.")
        return

    # Aggregate
    by_model: dict[str, dict] = defaultdict(lambda: {
        "calls": 0, "prompt_tokens": 0, "completion_tokens": 0, "cost": 0.0,
    })
    for r in records:
        m = r.get("model", "unknown")
        by_model[m]["calls"] += 1
        by_model[m]["prompt_tokens"] += r.get("prompt_tokens", 0)
        by_model[m]["completion_tokens"] += r.get("completion_tokens", 0)
        by_model[m]["cost"] += r.get("cost") or 0.0

    totals = {
        "calls": sum(v["calls"] for v in by_model.values()),
        "prompt_tokens": sum(v["prompt_tokens"] for v in by_model.values()),
        "completion_tokens": sum(v["completion_tokens"] for v in by_model.values()),
        "cost": sum(v["cost"] for v in by_model.values()),
        "by_model": dict(by_model),
    }

    if getattr(args, "json", False):
        print(_json.dumps(totals, indent=2, ensure_ascii=False))
        return

    # Rich table output
    from rich.console import Console
    from rich.table import Table
    from rich import box

    console = Console()
    period = f"最近 {args.days} 天" if args.days else "全部时间"
    title = f"BYOE 用量统计 — {period}  ({len(records)} 条记录)"
    table = Table(title=title, box=box.ROUNDED, show_lines=False)
    table.add_column("模型", style="cyan")
    table.add_column("调用次数", justify="right", style="green")
    table.add_column("输入 Token", justify="right", style="yellow")
    table.add_column("输出 Token", justify="right", style="yellow")
    table.add_column("总 Token", justify="right", style="white")
    table.add_column("预估费用 (USD)", justify="right", style="magenta")

    for model_name, v in sorted(by_model.items(), key=lambda x: -x[1]["cost"]):
        cost_str = f"${v['cost']:.4f}" if v["cost"] else "-"
        table.add_row(
            model_name,
            f"{v['calls']:,}",
            f"{v['prompt_tokens']:,}",
            f"{v['completion_tokens']:,}",
            f"{v['prompt_tokens'] + v['completion_tokens']:,}",
            cost_str,
        )

    # Totals row
    total_cost_str = f"${totals['cost']:.4f}" if totals["cost"] else "-"
    table.add_section()
    table.add_row(
        "[bold]合计[/bold]",
        f"[bold]{totals['calls']:,}[/bold]",
        f"[bold]{totals['prompt_tokens']:,}[/bold]",
        f"[bold]{totals['completion_tokens']:,}[/bold]",
        f"[bold]{totals['prompt_tokens'] + totals['completion_tokens']:,}[/bold]",
        f"[bold]{total_cost_str}[/bold]",
    )
    console.print(table)


def _run_version() -> None:
    """byoe version — print version and runtime info."""
    import platform
    import sys
    from rich.console import Console
    from rich.table import Table
    from rich import box

    console = Console()
    table = Table(box=box.SIMPLE, show_header=False, padding=(0, 2))
    table.add_column(style="dim")
    table.add_column(style="cyan bold")
    table.add_row("byoe", __version__)
    table.add_row("python", sys.version.split()[0])
    table.add_row("platform", platform.system() + " " + platform.machine())
    try:
        import openai
        table.add_row("openai", openai.__version__)
    except ImportError:
        pass
    console.print(table)


def _run_memory(args) -> None:
    """byoe memory — inspect and manage the Agent's long-term memory store."""
    from rich.console import Console
    from rich.table import Table
    from rich import box

    console = Console()
    from byoe.engine.light_memory import get_memory
    mem = get_memory()
    action = getattr(args, "memory_action", None) or "stats"

    if action == "search":
        results = mem.search(args.query, limit=args.limit)
        if not results:
            console.print(f"[dim]No memories found for: {args.query!r}[/dim]")
            return
        console.print(f"[bold]{len(results)} result(s)[/bold] for [cyan]{args.query!r}[/cyan]\n")
        for r in results:
            console.rule(f"[cyan]{r['path']}[/cyan]  [dim]score={r['score']:.2f}  layer={r['layer']}[/dim]")
            if r.get("summary"):
                console.print(f"[yellow]Summary:[/yellow] {r['summary']}")
            console.print(r["content"][:800] + ("…" if len(r["content"]) > 800 else ""))

    elif action == "list":
        c = mem.conn.cursor()
        if args.layer:
            c.execute(
                "SELECT id, path, layer, updated_at, LENGTH(content) AS len FROM memories "
                "WHERE layer=? ORDER BY updated_at DESC LIMIT ?",
                (args.layer, args.limit),
            )
        else:
            c.execute(
                "SELECT id, path, layer, updated_at, LENGTH(content) AS len FROM memories "
                "ORDER BY updated_at DESC LIMIT ?",
                (args.limit,),
            )
        rows = c.fetchall()
        if not rows:
            console.print("[dim]No memories found.[/dim]")
            return
        table = Table(box=box.ROUNDED, show_lines=False)
        table.add_column("Path", style="cyan")
        table.add_column("Layer", style="green")
        table.add_column("Updated", style="dim")
        table.add_column("Chars", justify="right", style="yellow")
        for row in rows:
            table.add_row(row["path"], row["layer"],
                          row["updated_at"][:19].replace("T", " "), str(row["len"]))
        console.print(table)

    elif action == "show":
        r = mem.read(args.path)
        if r is None:
            console.print(f"[red]Memory not found:[/red] {args.path}")
            return
        console.print(f"[bold cyan]{r['path']}[/bold cyan]  [dim]layer={r['layer']}[/dim]")
        if r.get("summary"):
            console.print(f"[yellow]Summary:[/yellow] {r['summary']}")
        if r.get("tags"):
            console.print(f"[dim]Tags:[/dim] {', '.join(r['tags'])}")
        console.print(f"\n{r['content']}")

    elif action == "forget":
        ok = mem.forget(args.path)
        if ok:
            console.print(f"[green]Deleted:[/green] {args.path}")
        else:
            console.print(f"[yellow]Not found:[/yellow] {args.path}")

    else:  # stats
        c = mem.conn.cursor()
        c.execute("SELECT layer, COUNT(*) AS n FROM memories GROUP BY layer ORDER BY n DESC")
        rows = c.fetchall()
        c.execute("SELECT COUNT(*) AS n FROM memories")
        total = c.fetchone()["n"]
        c.execute("SELECT COUNT(*) AS n FROM memories WHERE embedding IS NOT NULL")
        embedded = c.fetchone()["n"]
        table = Table(title="Memory Stats", box=box.ROUNDED)
        table.add_column("Layer", style="cyan")
        table.add_column("Count", justify="right", style="green")
        for row in rows:
            table.add_row(row["layer"], str(row["n"]))
        table.add_section()
        table.add_row("[bold]Total[/bold]", f"[bold]{total}[/bold]")
        console.print(table)
        emb_model = mem._embedding_model
        if emb_model:
            console.print(f"[dim]Embedding model: {emb_model}  |  {embedded}/{total} embedded[/dim]")
        else:
            console.print("[dim]Semantic search disabled (BYOE_EMBEDDING_MODEL not set)[/dim]")


def _run_memory_reindex() -> None:
    """byoe metrics --reindex-memory — embed all memories that have no vector yet."""
    import os
    import sys
    model = os.environ.get("BYOE_EMBEDDING_MODEL", "").strip()
    if not model:
        print("BYOE_EMBEDDING_MODEL is not set. Example:")
        print("  set BYOE_EMBEDDING_MODEL=text-embedding-3-small")
        return
    print(f"Reindexing memories with model: {model}")
    from byoe.engine.light_memory import get_memory
    mem = get_memory()

    def _progress(done: int, total: int) -> None:
        pct = int(done / total * 40)
        bar = "#" * pct + "-" * (40 - pct)
        print(f"\r  [{bar}] {done}/{total}", end="", flush=True)

    count = mem.reindex(on_progress=_progress)
    if count:
        print()  # newline after progress bar
    print(f"Done — {count} memories embedded.")


def _run_doctor() -> None:
    """byoe doctor — verify configuration and LLM connectivity."""
    from rich.console import Console
    from rich.table import Table
    import os

    console = Console()
    console.print("\n[bold cyan]BYOE Doctor[/bold cyan] — 配置与连通性检查\n")

    checks: list[tuple[str, bool, str]] = []

    # 1. API key
    from byoe.engine.config import Config
    cfg = Config.from_env()
    has_key = bool(cfg.api_key)
    checks.append(("API Key", has_key, cfg.api_key[:8] + "…" if has_key else "未设置"))

    # 2. Model
    checks.append(("Model", bool(cfg.model), cfg.model or "未设置"))

    # 3. Base URL
    checks.append(("Base URL", True, cfg.base_url or "(OpenAI default)"))

    # 4. LLM reachability
    if has_key:
        try:
            from byoe.engine.llm import LLM
            llm = LLM(model=cfg.model, api_key=cfg.api_key, base_url=cfg.base_url)
            resp = llm.chat([{"role": "user", "content": "Reply with the single word: OK"}])
            reachable = bool(resp.content)
            checks.append(("LLM 连通性", reachable,
                           f"✓ {resp.content[:30]}" if reachable else "连接失败"))
        except Exception as e:
            checks.append(("LLM 连通性", False, str(e)[:80]))
    else:
        checks.append(("LLM 连通性", False, "跳过（无 API Key）"))

    # 5. Memory DB
    try:
        from byoe.engine.light_memory import get_memory
        get_memory()
        checks.append(("Memory DB", True, "SQLite OK"))
    except Exception as e:
        checks.append(("Memory DB", False, str(e)[:60]))

    # 6. Skills dir
    skills_dir = os.path.expanduser("~/.byoe/skills")
    checks.append(("Skills Dir", True, skills_dir))

    # Print table
    table = Table(show_header=True, header_style="bold")
    table.add_column("检查项", style="cyan")
    table.add_column("状态", justify="center")
    table.add_column("详情")
    for name, ok, detail in checks:
        status = "[green]✓[/green]" if ok else "[red]✗[/red]"
        table.add_row(name, status, detail)
    console.print(table)

    all_ok = all(ok for _, ok, _ in checks)
    if all_ok:
        console.print("\n[green bold]所有检查通过！[/green bold]")
    else:
        console.print("\n[yellow]部分检查未通过，请根据上表修复配置。[/yellow]")
        console.print("提示: 在 .env 文件中设置 BYOE_API_KEY / BYOE_MODEL / OPENAI_BASE_URL")
    sys.exit(0 if all_ok else 1)


if __name__ == "__main__":
    main()
