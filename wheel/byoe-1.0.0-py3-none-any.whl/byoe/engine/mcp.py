"""MCP (Model Context Protocol) client — stdio and HTTP transports.

Connects to an MCP server, discovers its tools, and wraps them as BYOE
:class:`~byoe.engine.tools.base.Tool` objects ready for ``add_runtime_tool()``.

Stdio example::

    import byoe
    agent = byoe.create_agent(
        mcp_servers=[
            {"name": "fs", "command": ["npx", "-y", "@modelcontextprotocol/server-filesystem", "."]}
        ]
    )

HTTP example::

    import byoe
    agent = byoe.create_agent(
        mcp_servers=[{"name": "myserver", "url": "http://localhost:3000"}]
    )

Config via env var (JSON array)::

    export BYOE_MCP_SERVERS='[{"name":"fs","command":["npx","-y","@modelcontextprotocol/server-filesystem","."]}]'
"""
from __future__ import annotations

import json
import shlex
import subprocess
import threading
import time
import urllib.request
from typing import Any

from .tools.base import Tool

MCP_PROTOCOL_VERSION = "2024-11-05"
_TIMEOUT = 30  # seconds per JSON-RPC call


class MCPError(Exception):
    """Raised when an MCP server returns an error or is unreachable."""


# ─────────────────────────── transports ─────────────────────────────────────

class _StdioTransport:
    """JSON-RPC 2.0 over subprocess stdin/stdout (newline-delimited messages)."""

    def __init__(self, command: list[str]) -> None:
        self._proc = subprocess.Popen(
            command,
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            encoding="utf-8",
            errors="replace",
        )
        self._lock = threading.Lock()
        self._counter = 0

    def request(self, method: str, params: dict | None = None) -> Any:
        """Send a JSON-RPC request and return the ``result`` field."""
        with self._lock:
            self._counter += 1
            msg_id = self._counter
            payload: dict = {"jsonrpc": "2.0", "id": msg_id, "method": method}
            if params is not None:
                payload["params"] = params
            assert self._proc.stdin
            self._proc.stdin.write(json.dumps(payload) + "\n")
            self._proc.stdin.flush()

            deadline = time.monotonic() + _TIMEOUT
            while time.monotonic() < deadline:
                assert self._proc.stdout
                line = self._proc.stdout.readline()
                if not line:
                    raise MCPError("MCP server closed connection unexpectedly")
                line = line.strip()
                if not line:
                    continue
                try:
                    resp = json.loads(line)
                except json.JSONDecodeError:
                    continue  # skip non-JSON startup logs
                if resp.get("id") != msg_id:
                    continue  # skip notifications / mismatched ids
                if "error" in resp:
                    raise MCPError(f"MCP error: {resp['error']}")
                return resp.get("result")

        raise MCPError(f"MCP request '{method}' timed out after {_TIMEOUT}s")

    def notify(self, method: str, params: dict | None = None) -> None:
        """Send a JSON-RPC notification (no id; no response expected)."""
        payload: dict = {"jsonrpc": "2.0", "method": method}
        if params is not None:
            payload["params"] = params
        assert self._proc.stdin
        self._proc.stdin.write(json.dumps(payload) + "\n")
        self._proc.stdin.flush()

    def close(self) -> None:
        try:
            if self._proc.stdin:
                self._proc.stdin.close()
        except Exception:
            pass
        try:
            self._proc.terminate()
            self._proc.wait(timeout=5)
        except Exception:
            pass


class _HttpTransport:
    """JSON-RPC 2.0 over HTTP POST to ``<base_url>/messages``."""

    def __init__(self, url: str) -> None:
        self._url = url.rstrip("/") + "/messages"
        self._counter = 0
        self._lock = threading.Lock()

    def request(self, method: str, params: dict | None = None) -> Any:
        with self._lock:
            self._counter += 1
            msg_id = self._counter
        payload: dict = {"jsonrpc": "2.0", "id": msg_id, "method": method}
        if params is not None:
            payload["params"] = params
        data = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(
            self._url, data=data,
            headers={"Content-Type": "application/json"}, method="POST",
        )
        try:
            with urllib.request.urlopen(req, timeout=_TIMEOUT) as resp:
                body = resp.read().decode("utf-8")
        except Exception as e:
            raise MCPError(f"HTTP request to {self._url} failed: {e}") from e
        try:
            resp_data = json.loads(body)
        except json.JSONDecodeError as e:
            raise MCPError(f"Invalid JSON from MCP server: {e}") from e
        if "error" in resp_data:
            raise MCPError(f"MCP error: {resp_data['error']}")
        return resp_data.get("result")

    def notify(self, method: str, params: dict | None = None) -> None:
        payload: dict = {"jsonrpc": "2.0", "method": method}
        if params is not None:
            payload["params"] = params
        data = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(
            self._url, data=data,
            headers={"Content-Type": "application/json"}, method="POST",
        )
        try:
            urllib.request.urlopen(req, timeout=5)
        except Exception:
            pass  # notifications require no response

    def close(self) -> None:
        pass  # stateless HTTP; nothing to clean up


# ─────────────────────────── session ─────────────────────────────────────────

class MCPSession:
    """An active connection to one MCP server.

    Usage::

        session = MCPSession.from_stdio(["npx", "-y", "@modelcontextprotocol/server-filesystem", "."])
        tools = session.get_tools()   # list of BYOE Tool objects
        session.close()               # terminate subprocess / release resources
    """

    def __init__(self, transport: _StdioTransport | _HttpTransport, name: str) -> None:
        self._transport = transport
        self.name = name

    # ── factories ────────────────────────────────────────────────────────────

    @classmethod
    def from_stdio(cls, command: list[str], name: str = "mcp") -> "MCPSession":
        """Connect to an MCP server by spawning *command* as a subprocess."""
        transport = _StdioTransport(command)
        session = cls(transport, name)
        session._initialize()
        return session

    @classmethod
    def from_http(cls, url: str, name: str = "mcp") -> "MCPSession":
        """Connect to an MCP server over HTTP."""
        transport = _HttpTransport(url)
        session = cls(transport, name)
        session._initialize()
        return session

    # ── protocol handshake ────────────────────────────────────────────────────

    def _initialize(self) -> None:
        from byoe import __version__
        self._transport.request("initialize", {
            "protocolVersion": MCP_PROTOCOL_VERSION,
            "capabilities": {},
            "clientInfo": {"name": "byoe", "version": __version__},
        })
        self._transport.notify("notifications/initialized")

    # ── tool discovery ────────────────────────────────────────────────────────

    def list_tools(self) -> list[dict]:
        """Return raw MCP tool descriptors from the server."""
        result = self._transport.request("tools/list", {})
        return (result or {}).get("tools", [])

    def get_tools(self) -> list[Tool]:
        """Return BYOE :class:`Tool` wrappers for every tool on this server."""
        return [_MCPTool(self, t) for t in self.list_tools()]

    # ── invocation ────────────────────────────────────────────────────────────

    def call_tool(self, tool_name: str, arguments: dict) -> str:
        """Call a remote tool and return its text output."""
        result = self._transport.request("tools/call", {
            "name": tool_name,
            "arguments": arguments,
        })
        if result is None:
            return "(no result)"
        parts: list[str] = []
        for item in result.get("content", []):
            if not isinstance(item, dict):
                parts.append(str(item))
            elif item.get("type") == "text":
                parts.append(item.get("text", ""))
            elif item.get("type") == "image":
                parts.append(f"[image/{item.get('mimeType', 'unknown')}]")
            else:
                parts.append(json.dumps(item))
        return "\n".join(parts) or "(empty result)"

    def close(self) -> None:
        """Terminate the server subprocess or release HTTP resources."""
        self._transport.close()


# ─────────────────────────── tool wrapper ─────────────────────────────────────

class _MCPTool(Tool):
    """A BYOE :class:`Tool` backed by a remote MCP server tool."""

    def __init__(self, session: MCPSession, descriptor: dict) -> None:
        self._session = session
        self._raw_name: str = descriptor["name"]
        # Tool names are namespaced: mcp__<server_name>__<tool_name>
        self.name = f"mcp__{session.name}__{self._raw_name}"
        self.description = f"[MCP:{session.name}] {descriptor.get('description', '')}"
        self.parameters = descriptor.get("inputSchema") or {
            "type": "object", "properties": {}, "required": [],
        }

    def execute(self, **kwargs: Any) -> str:
        try:
            return self._session.call_tool(self._raw_name, kwargs)
        except MCPError as e:
            return f"MCP error: {e}"
        except Exception as e:
            return f"Error calling MCP tool '{self._raw_name}': {e}"


# ─────────────────────────── convenience helper ───────────────────────────────

def connect_servers(server_configs: list[dict]) -> list[Tool]:
    """Connect to all MCP servers in *server_configs* and return a merged tool list.

    Each config entry is a ``dict`` with:

    ``name``
        Logical name used in auto-generated tool names (``mcp__<name>__<tool>``).
    ``command``
        ``list[str]`` **or** ``str`` — stdio server launch command.
        Example: ``["npx", "-y", "@modelcontextprotocol/server-filesystem", "."]``
    ``url``
        HTTP server base URL. Example: ``"http://localhost:3000"``

    On connection failure a warning is printed to stderr and that server is
    skipped; other servers continue to be connected normally.
    """
    import sys
    tools: list[Tool] = []
    for i, cfg in enumerate(server_configs):
        name = str(cfg.get("name", f"mcp{i}"))
        try:
            if "url" in cfg:
                session = MCPSession.from_http(cfg["url"], name=name)
            elif "command" in cfg:
                cmd = cfg["command"]
                if isinstance(cmd, str):
                    cmd = shlex.split(cmd)
                session = MCPSession.from_stdio(cmd, name=name)
            else:
                print(
                    f"[byoe] MCP server '{name}': config must have 'command' or 'url'",
                    file=sys.stderr,
                )
                continue
            server_tools = session.get_tools()
            tools.extend(server_tools)
            print(
                f"[byoe] MCP '{name}': connected ({len(server_tools)} tools)",
                file=sys.stderr,
            )
        except Exception as e:
            print(
                f"[byoe] Warning: failed to connect to MCP server '{name}': {e}",
                file=sys.stderr,
            )
    return tools
