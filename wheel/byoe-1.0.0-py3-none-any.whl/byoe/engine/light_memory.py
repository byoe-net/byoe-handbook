import json
import math
import os
import sqlite3
import struct
from datetime import datetime, timedelta, timezone
from pathlib import Path


class LightMemory:
    """Lightweight SQLite FTS5-based memory layer for the Agent."""

    def __init__(self, db_path: str | Path | None = None):
        if not db_path:
            db_path = Path.home() / ".byoe" / "memory.db"
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self.conn = sqlite3.connect(
            str(self.db_path),
            detect_types=sqlite3.PARSE_DECLTYPES | sqlite3.PARSE_COLNAMES,
            check_same_thread=False
        )
        self.conn.row_factory = sqlite3.Row
        self.max_rows = self._env_int("BYOE_MEMORY_MAX_ROWS", 5000, minimum=100)
        self.session_ttl_days = self._env_int("BYOE_MEMORY_SESSION_TTL_DAYS", 30, minimum=1)
        self.short_term_ttl_days = self._env_int("BYOE_MEMORY_SHORT_TTL_DAYS", 14, minimum=1)
        self.gc_every_writes = self._env_int("BYOE_MEMORY_GC_EVERY_WRITES", 50, minimum=1)
        self._writes_since_gc = 0
        # Embedding state — lazy-initialised when BYOE_EMBEDDING_MODEL is set
        self._emb_client = None
        self._emb_model_cache: tuple | None = None
        self._init_db()

    @staticmethod
    def _env_int(name: str, default: int, minimum: int | None = None) -> int:
        raw = os.environ.get(name, "").strip()
        if not raw:
            return default
        try:
            value = int(raw)
        except ValueError:
            return default
        if minimum is not None:
            return max(minimum, value)
        return value

    def _init_db(self):
        c = self.conn.cursor()
        
        # Core memory table
        c.execute('''
            CREATE TABLE IF NOT EXISTS memories (
                id          TEXT PRIMARY KEY,
                path        TEXT UNIQUE NOT NULL,
                content     TEXT NOT NULL,
                layer       TEXT NOT NULL,
                summary     TEXT DEFAULT '',
                tags        TEXT DEFAULT '[]',
                created_at  TEXT NOT NULL,
                updated_at  TEXT NOT NULL,
                source      TEXT DEFAULT 'agent',
                meta        TEXT DEFAULT '{}'
            )
        ''')

        # FTS5 Virtual Table for fast search
        c.execute('''
            CREATE VIRTUAL TABLE IF NOT EXISTS memories_fts USING fts5(
                path,
                content,
                summary,
                tags,
                content='memories',
                content_rowid='rowid',
                tokenize='porter unicode61'
            )
        ''')

        # Triggers to keep FTS index synced
        c.execute('''
            CREATE TRIGGER IF NOT EXISTS memories_ai AFTER INSERT ON memories BEGIN
                INSERT INTO memories_fts(rowid, path, content, summary, tags)
                VALUES (new.rowid, new.path, new.content, new.summary, new.tags);
            END;
        ''')
        c.execute('''
            CREATE TRIGGER IF NOT EXISTS memories_ad AFTER DELETE ON memories BEGIN
                INSERT INTO memories_fts(memories_fts, rowid, path, content, summary, tags)
                VALUES ('delete', old.rowid, old.path, old.content, old.summary, old.tags);
            END;
        ''')
        c.execute('''
            CREATE TRIGGER IF NOT EXISTS memories_au AFTER UPDATE ON memories BEGIN
                INSERT INTO memories_fts(memories_fts, rowid, path, content, summary, tags)
                VALUES ('delete', old.rowid, old.path, old.content, old.summary, old.tags);
                INSERT INTO memories_fts(rowid, path, content, summary, tags)
                VALUES (new.rowid, new.path, new.content, new.summary, new.tags);
            END;
        ''')

        # Relations table
        c.execute('''
            CREATE TABLE IF NOT EXISTS relations (
                id          TEXT PRIMARY KEY,
                source_id   TEXT NOT NULL REFERENCES memories(id) ON DELETE CASCADE,
                target_id   TEXT NOT NULL REFERENCES memories(id) ON DELETE CASCADE,
                type        TEXT NOT NULL,
                strength    REAL DEFAULT 0.8,
                created_at  TEXT NOT NULL
            )
        ''')

        # Indices
        c.execute('CREATE INDEX IF NOT EXISTS idx_memories_layer ON memories(layer)')
        c.execute('CREATE INDEX IF NOT EXISTS idx_memories_path  ON memories(path)')
        c.execute('CREATE INDEX IF NOT EXISTS idx_memories_time  ON memories(created_at)')

        # Migration: add embedding column for semantic search (zero-dep, opt-in)
        try:
            c.execute('ALTER TABLE memories ADD COLUMN embedding BLOB')
        except sqlite3.OperationalError:
            pass  # column already exists

        self.conn.commit()

    # ── embedding helpers ──────────────────────────────────────────────────

    @property
    def _embedding_model(self) -> str | None:
        """Return the embedding model name from env, or None if disabled."""
        return os.environ.get("BYOE_EMBEDDING_MODEL", "").strip() or None

    def _embed(self, text: str) -> list[float] | None:
        """Generate an embedding vector via the OpenAI-compatible embeddings API.

        Returns None when ``BYOE_EMBEDDING_MODEL`` is not set, or on any error
        (network failure, quota exceeded, etc.) so callers degrade gracefully.

        Configure via env vars:
          BYOE_EMBEDDING_MODEL    e.g. "text-embedding-3-small"  (required to enable)
          BYOE_EMBEDDING_API_KEY  falls back to BYOE_API_KEY / OPENAI_API_KEY
          BYOE_EMBEDDING_BASE_URL falls back to OPENAI_BASE_URL
        """
        model = self._embedding_model
        if not model:
            return None
        try:
            from openai import OpenAI
            api_key = (
                os.environ.get("BYOE_EMBEDDING_API_KEY")
                or os.environ.get("BYOE_API_KEY")
                or os.environ.get("OPENAI_API_KEY")
                or ""
            )
            base_url = (
                os.environ.get("BYOE_EMBEDDING_BASE_URL")
                or os.environ.get("OPENAI_BASE_URL")
                or None
            )
            # Rebuild client only when config changes
            if self._emb_client is None or self._emb_model_cache != (model, api_key, base_url):
                self._emb_client = OpenAI(api_key=api_key, base_url=base_url)
                self._emb_model_cache = (model, api_key, base_url)
            resp = self._emb_client.embeddings.create(
                model=model,
                input=text[:8192],  # most models cap at 8k tokens
            )
            return resp.data[0].embedding
        except Exception:
            return None  # degrade to FTS5-only on any error

    @staticmethod
    def _pack_vec(vec: list[float]) -> bytes:
        """Pack float list to compact binary (4 bytes per float32)."""
        return struct.pack(f"{len(vec)}f", *vec)

    @staticmethod
    def _unpack_vec(data: bytes) -> list[float]:
        """Unpack binary blob back to float list."""
        n = len(data) // 4
        return list(struct.unpack(f"{n}f", data))

    @staticmethod
    def _cosine(a: list[float], b: list[float]) -> float:
        """Cosine similarity in pure Python (numpy used when available for speed)."""
        try:
            import numpy as _np
            av = _np.array(a, dtype=_np.float32)
            bv = _np.array(b, dtype=_np.float32)
            na, nb = float(_np.linalg.norm(av)), float(_np.linalg.norm(bv))
            return float(_np.dot(av, bv) / (na * nb)) if (na and nb) else 0.0
        except ImportError:
            dot = sum(x * y for x, y in zip(a, b))
            na = math.sqrt(sum(x * x for x in a))
            nb = math.sqrt(sum(x * x for x in b))
            return (dot / (na * nb)) if (na and nb) else 0.0

    # ── write ──────────────────────────────────────────────────────────────

    def write(self, path: str, content: str, layer: str = "knowledge",
              tags: list[str] | None = None, summary: str = "", source: str = "agent") -> str:
        """Write a new memory or update an existing one."""
        if not path.startswith("/"):
            path = "/" + path
            
        import uuid
        mem_id = f"mem_{uuid.uuid4().hex[:12]}"
        now = datetime.now(timezone.utc).isoformat()
        tags_json = json.dumps(tags or [])

        c = self.conn.cursor()
        
        # Check if exists
        c.execute('SELECT id FROM memories WHERE path = ?', (path,))
        row = c.fetchone()
        _was_update = row is not None

        # Generate embedding (None when BYOE_EMBEDDING_MODEL is not set)
        emb_blob = None
        vec = self._embed(content if not summary else f"{content}\n{summary}")
        if vec is not None:
            emb_blob = self._pack_vec(vec)

        if _was_update:
            mem_id = row['id']
            c.execute('''
                UPDATE memories
                SET content=?, layer=?, summary=?, tags=?, updated_at=?, source=?,
                    embedding=COALESCE(?, embedding)
                WHERE id=?
            ''', (content, layer, summary, tags_json, now, source, emb_blob, mem_id))
        else:
            c.execute('''
                INSERT INTO memories (id, path, content, layer, summary, tags, created_at, updated_at, source, embedding)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (mem_id, path, content, layer, summary, tags_json, now, now, source, emb_blob))

        self.conn.commit()
        self._writes_since_gc += 1
        if self._writes_since_gc >= self.gc_every_writes:
            self.gc(vacuum=False)
            self._writes_since_gc = 0
        try:
            from byoe.engine.hooks import emit as _emit
            _emit("memory.write", path=path, layer=layer, was_update=_was_update)
        except Exception:
            pass
        return mem_id, _was_update

    def search(self, query: str, limit: int = 5) -> list[dict]:
        """Multi-strategy FTS5 search with recency boost.

        Runs up to three passes against FTS5 with decreasing specificity:
          1. Phrase match  — highest relevance bonus (+2.0)
          2. AND  match    — all tokens present (+1.0)
          3. OR   match    — any token present  (+0.0)

        Each hit receives a recency bonus (up to +0.3) so recently-updated
        memories surface higher when BM25 scores are otherwise equal.
        Results are deduplicated by memory id and ranked by composite score.
        Falls back to LIKE scan on FTS5 parse errors (e.g. special chars).
        """
        c = self.conn.cursor()
        limit = max(1, min(int(limit), 50))
        seen: dict[str, dict] = {}

        # Strip FTS5 special chars to avoid parse errors, then tokenize
        clean = query.replace('"', '').replace("'", "").strip()
        tokens = [t for t in clean.split() if len(t) > 1]

        def _parse_recency(updated_at: str) -> float:
            """Return a 0.0–0.3 recency bonus; decays 0.01 per day."""
            try:
                from datetime import timezone as _tz
                updated = datetime.fromisoformat(updated_at.replace("Z", "+00:00"))
                age_days = (datetime.now(_tz.utc) - updated).days
                return max(0.0, 0.3 - age_days * 0.01)
            except Exception:
                return 0.0

        def _run_fts(fts_query: str, base_bonus: float) -> None:
            try:
                c.execute(
                    """
                    SELECT memories.*, bm25(memories_fts) AS bm25_score
                    FROM memories
                    JOIN memories_fts ON memories.rowid = memories_fts.rowid
                    WHERE memories_fts MATCH ?
                    ORDER BY bm25_score ASC
                    LIMIT ?
                    """,
                    (fts_query, limit * 3),
                )
                for row in c.fetchall():
                    r = dict(row)
                    mem_id = r["id"]
                    score = base_bonus + abs(r["bm25_score"]) + _parse_recency(r.get("updated_at", ""))
                    if mem_id not in seen or seen[mem_id]["score"] < score:
                        try:
                            r["tags"] = json.loads(r["tags"])
                        except Exception:
                            r["tags"] = []
                        r["score"] = score
                        seen[mem_id] = r
            except sqlite3.OperationalError:
                pass  # handled by final LIKE fallback

        if tokens:
            # Pass 1: phrase
            if len(tokens) > 1:
                _run_fts(f'"{clean}"', 2.0)
            # Pass 2: AND (all tokens)
            _run_fts(" ".join(tokens), 1.0)
            # Pass 3: OR (any token) for broader recall
            if len(tokens) > 1:
                _run_fts(" OR ".join(tokens), 0.0)

        if not seen:
            # Final fallback: LIKE scan (handles special chars that break FTS5)
            c.execute(
                """
                SELECT * FROM memories
                WHERE content LIKE ? OR summary LIKE ? OR tags LIKE ?
                ORDER BY updated_at DESC
                LIMIT ?
                """,
                (f"%{query}%", f"%{query}%", f"%{query}%", limit),
            )
            for row in c.fetchall():
                r = dict(row)
                try:
                    r["tags"] = json.loads(r["tags"])
                except Exception:
                    r["tags"] = []
                r["score"] = 0.5
                seen[r["id"]] = r

        # Semantic blending: fuse FTS5 results with cosine similarity when enabled
        if self._embedding_model:
            sem_results = self.search_semantic(query, limit=limit)
            # Cosine similarity is in [-1, 1]; scale to [0, 3] to match FTS5 bonus range
            for r in sem_results:
                mem_id = r["id"]
                sem_score = (r["score"] + 1.0) * 1.5  # 0 → 3
                if mem_id in seen:
                    seen[mem_id]["score"] += sem_score
                else:
                    r["score"] = sem_score
                    seen[mem_id] = r

        results = sorted(seen.values(), key=lambda x: x["score"], reverse=True)
        return results[:limit]

    def search_semantic(self, query: str, limit: int = 5) -> list[dict]:
        """Return memories ranked by cosine similarity to *query* embedding.

        Requires ``BYOE_EMBEDDING_MODEL`` to be set; returns ``[]`` otherwise.
        Memories without stored embeddings are skipped (they still appear via FTS5).
        """
        query_vec = self._embed(query)
        if query_vec is None:
            return []

        c = self.conn.cursor()
        c.execute("SELECT * FROM memories WHERE embedding IS NOT NULL")
        rows = c.fetchall()
        if not rows:
            return []

        scored: list[tuple[float, dict]] = []
        for row in rows:
            blob = row["embedding"]
            if not blob:
                continue
            try:
                vec = self._unpack_vec(bytes(blob))
                sim = self._cosine(query_vec, vec)
                r = dict(row)
                r.pop("embedding", None)
                try:
                    r["tags"] = json.loads(r["tags"])
                except Exception:
                    r["tags"] = []
                r["score"] = sim
                scored.append((sim, r))
            except Exception:
                continue

        scored.sort(key=lambda x: -x[0])
        return [r for _, r in scored[:limit]]

    def _embed_batch(self, texts: list[str]) -> list[list[float] | None]:
        """Generate embeddings for multiple texts in a single API call.

        Returns a list of the same length as ``texts``.  Each element is either
        the embedding vector or ``None`` if the API call failed.
        """
        model = self._embedding_model
        if not model or not texts:
            return [None] * len(texts)
        try:
            from openai import OpenAI
            api_key = (
                os.environ.get("BYOE_EMBEDDING_API_KEY")
                or os.environ.get("BYOE_API_KEY")
                or os.environ.get("OPENAI_API_KEY")
                or ""
            )
            base_url = (
                os.environ.get("BYOE_EMBEDDING_BASE_URL")
                or os.environ.get("OPENAI_BASE_URL")
                or None
            )
            if self._emb_client is None or self._emb_model_cache != (model, api_key, base_url):
                self._emb_client = OpenAI(api_key=api_key, base_url=base_url)
                self._emb_model_cache = (model, api_key, base_url)
            truncated = [t[:8192] for t in texts]
            resp = self._emb_client.embeddings.create(model=model, input=truncated)
            # API returns embeddings in the same order as input
            ordered = sorted(resp.data, key=lambda e: e.index)
            return [e.embedding for e in ordered]
        except Exception:
            # Graceful fallback: try per-item embedding path.
            # Keeps reindex() functional when batch embedding is unavailable
            # and preserves monkeypatch-based tests that replace _embed().
            return [self._embed(t) for t in texts]

    def reindex(self, batch_size: int = 100, on_progress=None) -> int:
        """Generate embeddings for all memories that have none.

        Useful after enabling ``BYOE_EMBEDDING_MODEL`` on an existing database.

        Args:
            batch_size:   Number of texts to embed per API call (default 100).
                          Larger values are faster but use more memory.
            on_progress:  Optional callback ``fn(done: int, total: int)`` called
                          after each batch.

        Returns:
            The number of memories that were (re)embedded.
        """
        if not self._embedding_model:
            return 0
        c = self.conn.cursor()
        c.execute("SELECT id, content, summary FROM memories WHERE embedding IS NULL")
        rows = c.fetchall()
        if not rows:
            return 0
        total = len(rows)
        count = 0
        for start in range(0, total, batch_size):
            batch = rows[start: start + batch_size]
            texts = [
                (r["content"] + ("\n" + r["summary"] if r["summary"] else ""))
                for r in batch
            ]
            vectors = self._embed_batch(texts)
            for row, vec in zip(batch, vectors):
                if vec is None:
                    continue
                blob = self._pack_vec(vec)
                c.execute("UPDATE memories SET embedding=? WHERE id=?", (blob, row["id"]))
                count += 1
            self.conn.commit()
            if on_progress:
                on_progress(min(start + batch_size, total), total)
        return count

    def read(self, path: str) -> dict | None:
        """Read a specific memory by path."""
        if not path.startswith("/"):
            path = "/" + path
            
        c = self.conn.cursor()
        c.execute('SELECT * FROM memories WHERE path = ?', (path,))
        row = c.fetchone()
        
        if row:
            r = dict(row)
            try:
                r['tags'] = json.loads(r['tags'])
            except:
                r['tags'] = []
            return r
        return None

    def forget(self, path: str) -> bool:
        """Delete a memory by path."""
        if not path.startswith("/"):
            path = "/" + path
            
        c = self.conn.cursor()
        c.execute('DELETE FROM memories WHERE path = ?', (path,))
        self.conn.commit()
        return c.rowcount > 0

    def gc(
        self,
        session_ttl_days: int | None = None,
        short_term_ttl_days: int | None = None,
        max_rows: int | None = None,
        vacuum: bool = False,
    ) -> dict:
        """Cleanup expired volatile memories and cap total row count.

        Returns a small stats dict for observability.
        """
        session_ttl = self.session_ttl_days if session_ttl_days is None else max(1, int(session_ttl_days))
        short_ttl = self.short_term_ttl_days if short_term_ttl_days is None else max(1, int(short_term_ttl_days))
        row_cap = self.max_rows if max_rows is None else max(1, int(max_rows))

        c = self.conn.cursor()
        stats = {
            "deleted_expired": 0,
            "deleted_overflow": 0,
            "remaining": 0,
        }

        now = datetime.now(timezone.utc)
        session_cutoff = (now - timedelta(days=session_ttl)).isoformat()
        short_cutoff = (now - timedelta(days=short_ttl)).isoformat()

        # Expire volatile layers first; keep knowledge memories by default.
        c.execute(
            """
            DELETE FROM memories
            WHERE layer = 'session' AND updated_at < ?
            """,
            (session_cutoff,),
        )
        stats["deleted_expired"] += c.rowcount if c.rowcount > 0 else 0

        c.execute(
            """
            DELETE FROM memories
            WHERE layer IN ('short_term', 'ephemeral') AND updated_at < ?
            """,
            (short_cutoff,),
        )
        stats["deleted_expired"] += c.rowcount if c.rowcount > 0 else 0

        c.execute("SELECT COUNT(*) AS n FROM memories")
        total = int(c.fetchone()["n"])

        overflow = total - row_cap
        if overflow > 0:
            # Prefer dropping old volatile memories before touching knowledge.
            c.execute(
                """
                DELETE FROM memories
                WHERE id IN (
                    SELECT id FROM memories
                    WHERE layer IN ('session', 'short_term', 'ephemeral')
                    ORDER BY updated_at ASC
                    LIMIT ?
                )
                """,
                (overflow,),
            )
            removed = c.rowcount if c.rowcount > 0 else 0
            stats["deleted_overflow"] += removed
            overflow -= removed

            if overflow > 0:
                c.execute(
                    """
                    DELETE FROM memories
                    WHERE id IN (
                        SELECT id FROM memories
                        ORDER BY updated_at ASC
                        LIMIT ?
                    )
                    """,
                    (overflow,),
                )
                stats["deleted_overflow"] += c.rowcount if c.rowcount > 0 else 0

        self.conn.commit()
        c.execute("PRAGMA optimize")
        if vacuum and (stats["deleted_expired"] + stats["deleted_overflow"]) > 0:
            c.execute("VACUUM")

        c.execute("SELECT COUNT(*) AS n FROM memories")
        stats["remaining"] = int(c.fetchone()["n"])
        return stats

    def close(self):
        self.conn.close()

# Singleton instance
_memory_instance = None

def get_memory() -> LightMemory:
    global _memory_instance
    if _memory_instance is None:
        _memory_instance = LightMemory()
    return _memory_instance
