"""Configuration - env vars and defaults."""

import os
from dataclasses import dataclass
from pathlib import Path


def _load_dotenv():
    """Load .env from cwd, walking up to home dir. No-op if python-dotenv missing."""
    try:
        from dotenv import load_dotenv
        env_path = Path(".env")
        if not env_path.exists():
            cur = Path.cwd()
            home = Path.home()
            while cur != home and cur != cur.parent:
                candidate = cur / ".env"
                if candidate.exists():
                    env_path = candidate
                    break
                cur = cur.parent
        load_dotenv(env_path, override=False)
    except ImportError:
        # Fallback: try to read a simple .env file ourselves so users who
        # haven't installed python-dotenv still get basic .env support.
        # This is intentionally minimal: lines like KEY=VALUE, ignore comments.
        env_path = Path(".env")
        if not env_path.exists():
            cur = Path.cwd()
            home = Path.home()
            while cur != home and cur != cur.parent:
                candidate = cur / ".env"
                if candidate.exists():
                    env_path = candidate
                    break
                cur = cur.parent

        if env_path.exists():
            try:
                with env_path.open("r", encoding="utf-8") as fh:
                    for line in fh:
                        line = line.strip()
                        if not line or line.startswith("#"):
                            continue
                        if "=" not in line:
                            continue
                        key, val = line.split("=", 1)
                        key = key.strip()
                        val = val.strip().strip('"').strip("'")
                        # Don't override existing env vars
                        if os.getenv(key) is None:
                            os.environ[key] = val
            except Exception:
                # If anything goes wrong here, silently continue but
                # also give a hint to the user via stderr that python-dotenv
                # is recommended for full .env support.
                try:
                    import sys

                    sys.stderr.write(
                        "WARNING: failed to parse .env fallback; consider installing python-dotenv for robust behavior.\n"
                    )
                except Exception:
                    pass


@dataclass
class Config:
    model: str = "deepseek-v4-flash"
    api_key: str = ""
    base_url: str | None = None
    max_tokens: int = 16384
    temperature: float = 0.0
    max_context_tokens: int = 128_000
    mcp_servers: list = None  # type: ignore[assignment]  — list[dict], default via field

    def __post_init__(self):
        if self.mcp_servers is None:
            self.mcp_servers = []

    @classmethod
    def from_env(cls) -> "Config":
        _load_dotenv()
        import json as _json
        api_key = (
            os.getenv("BYOE_API_KEY")
            or os.getenv("OPENAI_API_KEY")
            or os.getenv("DEEPSEEK_API_KEY")
            or os.getenv("ANTHROPIC_API_KEY")
            or ""
        )
        return cls(
            model=os.getenv("BYOE_MODEL", "deepseek-v4-flash"),
            api_key=api_key,
            base_url=(
                os.getenv("BYOE_BASE_URL")
                or os.getenv("OPENAI_BASE_URL")
            ),
            max_tokens=int(os.getenv("BYOE_MAX_TOKENS", "16384")),
            temperature=float(os.getenv("BYOE_TEMPERATURE", "0")),
            max_context_tokens=int(os.getenv("BYOE_MAX_CONTEXT", "128000")),
            mcp_servers=_json.loads(os.getenv("BYOE_MCP_SERVERS", "[]")),
        )
