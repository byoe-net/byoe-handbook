"""Core agent loop.

Pattern:  user message -> LLM (with tools) -> tool calls? -> execute -> loop
                                            -> text reply? -> return to user
"""

import base64
import concurrent.futures
import json
import threading
import time
from pathlib import Path
from .llm import LLM
from .tools import ALL_TOOLS
from .tools.base import Tool
from .tools.agent import AgentTool
from .tools.swarm_tool import SwarmTool
from .tools.bash import BashTool
from .tools.edit import EditFileTool
from .tools.write import WriteFileTool
from .tools.todo_tool import TodoTool
from .prompt import system_prompt
from .context import ContextManager
from .hooks import emit as _emit_hook
from . import logger as _log


def _image_to_data_url(path: str) -> str:
    """Convert an image file path to a ``data:image/TYPE;base64,DATA`` URL."""
    _SIGS = [
        (b"\xff\xd8\xff", "image/jpeg"),
        (b"\x89PNG\r\n\x1a\n", "image/png"),
        (b"GIF87a", "image/gif"),
        (b"GIF89a", "image/gif"),
        (b"RIFF", "image/webp"),
    ]
    raw = Path(path).expanduser().resolve().read_bytes()
    header = raw[:16]
    mime = "image/png"
    for sig, m in _SIGS:
        if header[: len(sig)] == sig:
            if m == "image/webp" and header[8:12] != b"WEBP":
                continue
            mime = m
            break
    return f"data:{mime};base64,{base64.b64encode(raw).decode('ascii')}"


class Agent:
    def __init__(
        self,
        llm: LLM,
        tools: list[Tool] | None = None,
        max_context_tokens: int = 128_000,
        max_rounds: int = 50,
        system: str | None = None,
        cwd: str | None = None,
    ):
        self.llm = llm
        self.tools = tools if tools is not None else ALL_TOOLS
        self.messages: list[dict] = []
        self.context = ContextManager(max_tokens=max_context_tokens)
        self.max_rounds = max_rounds
        self._cwd = cwd  # project directory — used for Crew context injection
        self._system = system if system is not None else system_prompt(self.tools, cwd=cwd)

        # Session-scoped change tracker shared by EditFileTool & WriteFileTool.
        self.changed_files: set[str] = set()
        self._wire_tools()

        # Per-tool locks: serialise concurrent calls on the same stateful instance
        # (e.g. two parallel BashTool calls both updating self._cwd).
        self._tool_locks: dict[str, threading.Lock] = {
            t.name: threading.Lock() for t in self.tools
        }
        # O(1) name to wired-instance map (built after _wire_tools).
        self._tool_map: dict[str, Tool] = {t.name: t for t in self.tools}

        # Abort flag: set by abort() to request early termination of chat().
        self._abort_flag = threading.Event()
        # Tool schema cache — invalidated by _wire_tools / add_runtime_tool.
        self._schemas_cache: list[dict] | None = None

    # ── wiring & lifecycle ────────────────────────────────────────────────────

    def _wire_tools(self) -> None:
        """Inject per-session state into tools that need it."""
        self._schemas_cache = None  # invalidate on any wiring change
        for t in self.tools:
            if isinstance(t, (AgentTool, SwarmTool)):
                t._parent_agent = self
            if isinstance(t, (EditFileTool, WriteFileTool)):
                t._set_changed_files(self.changed_files)
            if isinstance(t, BashTool) and self._cwd:
                t.set_sandbox_root(self._cwd)
            if hasattr(t, "_set_parent_agent"):
                t._set_parent_agent(self)

    def add_runtime_tool(self, tool: Tool) -> None:
        """Attach a tool at runtime for current session and refresh prompt schemas."""
        # replace same-name tool if exists
        self.tools[:] = [t for t in self.tools if t.name != tool.name]
        self.tools.append(tool)
        self._tool_map[tool.name] = tool
        self._tool_locks[tool.name] = threading.Lock()
        self._schemas_cache = None  # invalidate cache
        if hasattr(tool, "_set_parent_agent"):
            tool._set_parent_agent(self)
        if isinstance(tool, (EditFileTool, WriteFileTool)):
            tool._set_changed_files(self.changed_files)
        self._system = system_prompt(self.tools, cwd=self._cwd)

    def reset(self) -> None:
        self.messages.clear()
        self.changed_files.clear()
        self._abort_flag.clear()
        # Reset per-session token counters so the UI shows usage for the new
        # conversation, not accumulated across all previous resets.
        self.llm.total_prompt_tokens = 0
        self.llm.total_completion_tokens = 0
        for t in self.tools:
            if isinstance(t, BashTool):
                t.reset_cwd()
                if self._cwd:
                    t.set_sandbox_root(self._cwd)
            if isinstance(t, TodoTool):
                t._reset()
        # Re-build system prompt (picks up any file changes on disk).
        self._system = system_prompt(self.tools, cwd=self._cwd)

    # ── abort ─────────────────────────────────────────────────────────────────

    def refresh_crew_context(self) -> bool:
        """Rebuild system prompt if crew files changed since last build.

        Returns True if the prompt was updated, False if already current.
        Cheap when files haven't changed (mtime cache in prompt module).
        """
        if not self._cwd:
            return False
        new_prompt = system_prompt(self.tools, cwd=self._cwd)
        if new_prompt != self._system:
            self._system = new_prompt
            return True
        return False

    def abort(self) -> None:
        """Signal the currently-running chat() loop to stop after the current step."""
        self._abort_flag.set()

    # ── message helpers ───────────────────────────────────────────────────────

    def _full_messages(self) -> list[dict]:
        return [{"role": "system", "content": self._system}] + self.messages

    def _tool_schemas(self) -> list[dict]:
        if self._schemas_cache is None:
            self._schemas_cache = [t.schema() for t in self.tools]
        return self._schemas_cache

    # ── main chat loop ────────────────────────────────────────────────────────

    def chat(self, user_input: str, images=None, on_token=None, on_tool=None, on_tool_result=None, on_compress=None, response_model=None) -> str:
        """Run one user turn through the agent loop.

        Args:
            user_input:     The user message.
            images:         Optional list of image paths or ``data:image/...`` URLs to
                            attach as vision content parts alongside the text message.
                            Requires a multimodal-capable model (e.g. gpt-4o, claude-3).
            on_token:       Callback(str) for streaming tokens.
            on_tool:        Callback(name, kwargs) called *before* each tool execution.
            on_tool_result: Callback(name, kwargs, result) called *after* each tool execution.
            on_compress:    Callback(layer, before_tokens, after_tokens) on context compression.
            response_model: Optional pydantic model class. When provided the final LLM
                            response is parsed as JSON and validated against the model.
                            Returns the model instance (or a plain dict if pydantic is
                            unavailable/validation fails).  Ignored on abort/max-rounds.
        """
        if images:
            content: list[dict] = [{"type": "text", "text": user_input}]
            for img in images:
                url = img if img.startswith("data:image/") else _image_to_data_url(img)
                content.append({"type": "image_url", "image_url": {"url": url}})
            self.messages.append({"role": "user", "content": content})
        else:
            self.messages.append({"role": "user", "content": user_input})

        # Auto-refresh crew context if any project file changed since last turn
        self.refresh_crew_context()

        # Inject instructions for any skill whose trigger matches user input
        _skill_extra = self._match_skill_triggers(user_input)
        _orig_system = self._system
        if _skill_extra:
            self._system = self._system + "\n\n---\n# Auto-triggered Skill\n" + _skill_extra

        # Inject JSON schema instruction when structured output is requested
        if response_model is not None:
            try:
                import json as _jschema
                _schema = response_model.model_json_schema()
                _schema_txt = (
                    "\n\n[Structured Output Required] "
                    "Your FINAL message must be valid JSON with NO markdown fences, "
                    "matching this JSON Schema exactly:\n"
                    + _jschema.dumps(_schema, indent=2)
                )
            except Exception:
                _schema_txt = (
                    "\n\n[Structured Output Required] "
                    "Your FINAL message must be valid JSON with no markdown fences."
                )
            self._system = self._system + _schema_txt

        def _compress_cb(layer: str, before: int, after: int) -> None:
            _log.log_context_compress(layer, before, after)
            if on_compress:
                on_compress(layer, before, after)

        self.context.maybe_compress(self.messages, self.llm, on_compress=_compress_cb)
        self._abort_flag.clear()   # reset from any previous abort

        turn_start = time.monotonic()
        rounds_used = 0
        for _ in range(self.max_rounds):
            if self._abort_flag.is_set():
                self._system = _orig_system
                return "(aborted by user)"

            resp = self.llm.chat(
                messages=self._full_messages(),
                tools=self._tool_schemas(),
                on_token=on_token,
            )
            _log.log_llm_request(
                self.llm.model,
                resp.prompt_tokens,
                resp.completion_tokens,
            )

            if not resp.tool_calls:
                self.messages.append(resp.message)
                _log.log_agent_turn(
                    user_input,
                    rounds_used,
                    self.llm.total_prompt_tokens + self.llm.total_completion_tokens,
                )
                self._system = _orig_system  # restore after skill/schema injection
                _emit_hook(
                    "agent.turn",
                    user_input=user_input,
                    response=resp.content,
                    prompt_tokens=resp.prompt_tokens,
                    completion_tokens=resp.completion_tokens,
                    rounds=rounds_used,
                    duration_ms=(time.monotonic() - turn_start) * 1000,
                )
                if response_model is not None:
                    return _parse_structured(resp.content, response_model)
                return resp.content

            self.messages.append(resp.message)
            rounds_used += 1

            if len(resp.tool_calls) == 1:
                tc = resp.tool_calls[0]
                if on_tool:
                    on_tool(tc.name, tc.arguments)
                _t_tool = time.monotonic()
                _tool_err: Exception | None = None
                try:
                    result = self._exec_tool(tc)
                except Exception as _e:
                    _tool_err = _e
                    result = f"Error: {_e}"
                _emit_hook("tool.call", name=tc.name, kwargs=tc.arguments,
                           result=result, duration_ms=(time.monotonic()-_t_tool)*1000,
                           error=_tool_err)
                if on_tool_result:
                    on_tool_result(tc.name, tc.arguments, result)
                # If the tool returned an image data URL, inject it as a
                # multimodal user message so the LLM can visually process it.
                if result.startswith("data:image/"):
                    self.messages.append({
                        "role": "tool",
                        "tool_call_id": tc.id,
                        "content": "(image attached below)",
                    })
                    self.messages.append({
                        "role": "user",
                        "content": [{"type": "image_url", "image_url": {"url": result}}],
                    })
                else:
                    self.messages.append({
                        "role": "tool",
                        "tool_call_id": tc.id,
                        "content": result,
                    })
            else:
                results = self._exec_tools_parallel(
                    resp.tool_calls, on_tool=on_tool, on_tool_result=on_tool_result
                )
                _pending_images: list[str] = []
                for tc, result in zip(resp.tool_calls, results):
                    if result.startswith("data:image/"):
                        _pending_images.append(result)
                        self.messages.append({
                            "role": "tool",
                            "tool_call_id": tc.id,
                            "content": "(image attached below)",
                        })
                    else:
                        self.messages.append({
                            "role": "tool",
                            "tool_call_id": tc.id,
                            "content": result,
                        })
                if _pending_images:
                    img_parts = [
                        {"type": "image_url", "image_url": {"url": u}}
                        for u in _pending_images
                    ]
                    self.messages.append({"role": "user", "content": img_parts})

            self.context.maybe_compress(self.messages, self.llm, on_compress=_compress_cb)

        self._system = _orig_system  # restore after skill/schema injection (max_rounds path)
        return "(reached maximum tool-call rounds)"

    # ── skill trigger matching ────────────────────────────────────────────────

    def _match_skill_triggers(self, user_input: str) -> str:
        """Return combined instructions for any skills whose trigger appears in user_input."""
        try:
            from byoe.engine.skills import list_skills
            lower = user_input.lower()
            matched: list[str] = []
            for skill in list_skills():
                trigger = (skill.get("trigger") or "").strip().lower()
                if trigger and trigger in lower:
                    instructions = (skill.get("instructions") or "").strip()
                    if instructions:
                        matched.append(f"[Skill: {skill['name']}]\n{instructions}")
            return "\n\n".join(matched)
        except Exception:
            return ""

    # ── streaming & async convenience ─────────────────────────────────────────

    def stream(self, user_input: str, images=None, on_tool=None, on_tool_result=None,
               on_compress=None, response_model=None) -> "StreamResponse":
        """Return a :class:`StreamResponse` that yields tokens and exposes the final result.

        Runs ``chat()`` in a background thread; tokens arrive via a queue.

        Example::

            stream = agent.stream("Explain quicksort")
            for chunk in stream:
                print(chunk, end="", flush=True)
            print()
            full_response = stream.result   # full text after iteration
        """
        return StreamResponse(
            self, user_input,
            images=images,
            on_tool=on_tool,
            on_tool_result=on_tool_result,
            on_compress=on_compress,
            response_model=response_model,
        )

    async def achat(self, user_input: str, **kwargs) -> str:
        """Async wrapper around ``chat()`` — runs in a thread-pool executor.

        Suitable for FastAPI, asyncio, or any async framework.  Passes all
        keyword arguments through to ``chat()``, including ``response_model``.

        Example::

            import asyncio, byoe

            agent = byoe.create_agent()
            result = asyncio.run(agent.achat("Write a limerick about Python"))
        """
        import asyncio
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(
            None, lambda: self.chat(user_input, **kwargs)
        )

    def save(self, path: "str | Path | None" = None) -> str:
        """Serialize conversation history to a JSON file.

        Args:
            path: File path to save to.  Defaults to
                  ``~/.byoe/conversations/conv_<timestamp>.json``.

        Returns:
            The absolute path of the saved file.

        Example::

            path = agent.save()
            print(f"Saved to {path}")
        """
        from datetime import datetime, timezone
        if path is None:
            _dir = Path.home() / ".byoe" / "conversations"
            _dir.mkdir(parents=True, exist_ok=True)
            _ts = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
            path = _dir / f"conv_{_ts}.json"
        data = {
            "version": 1,
            "saved_at": datetime.now(timezone.utc).isoformat(),
            "model": self.llm.model,
            "messages": self.messages,
            "changed_files": sorted(self.changed_files),
            "total_prompt_tokens": self.llm.total_prompt_tokens,
            "total_completion_tokens": self.llm.total_completion_tokens,
        }
        _p = Path(path)
        _p.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
        return str(_p.resolve())

    def load(self, path: "str | Path") -> None:
        """Restore conversation history from a JSON file saved by :meth:`save`.

        Replaces the current message history in-place.  Model and token counters
        are also restored so cost estimates remain accurate.

        Example::

            agent.load("~/.byoe/conversations/conv_20260630_120000.json")
            print(agent.chat("Continue where we left off"))
        """
        _p = Path(path).expanduser()
        data = json.loads(_p.read_text(encoding="utf-8"))
        self.messages = data.get("messages", [])
        self.changed_files = set(data.get("changed_files", []))
        self.llm.total_prompt_tokens = data.get("total_prompt_tokens", 0)
        self.llm.total_completion_tokens = data.get("total_completion_tokens", 0)

    # ── tool execution ────────────────────────────────────────────────────────

    def _exec_tool(self, tc) -> str:
        """Execute a single tool call using the Agent's wired instance map."""
        tool = self._tool_map.get(tc.name)
        if tool is None:
            _log.warn("unknown_tool", tool=tc.name)
            return f"Error: unknown tool '{tc.name}'"
        _log.log_tool_call(tc.name, tc.arguments)
        t0 = time.monotonic()
        try:
            result = tool.execute(**tc.arguments)
        except TypeError as e:
            result = f"Error calling {tc.name}: {e}"
        except Exception as e:
            result = f"Tool error ({tc.name}): {e}"
        elapsed = int((time.monotonic() - t0) * 1000)
        _log.log_tool_result(tc.name, result, elapsed_ms=elapsed)
        return result

    def _exec_tools_parallel(self, tool_calls, on_tool=None, on_tool_result=None) -> list[str]:
        """Execute multiple tool calls in parallel, serialising per-tool to
        prevent concurrent mutation of stateful instances (e.g. BashTool._cwd)."""
        results: list[str] = [""] * len(tool_calls)
        with concurrent.futures.ThreadPoolExecutor() as executor:
            futures = {}
            for i, tc in enumerate(tool_calls):
                if on_tool:
                    on_tool(tc.name, tc.arguments)
                lock = self._tool_locks.get(tc.name)

                def _run(tc=tc, lock=lock):
                    if lock:
                        with lock:
                            return self._exec_tool(tc)
                    return self._exec_tool(tc)

                futures[executor.submit(_run)] = (i, tc)
            for future in concurrent.futures.as_completed(futures):
                idx, tc = futures[future]
                try:
                    r = future.result()
                    results[idx] = r
                    if on_tool_result:
                        on_tool_result(tc.name, tc.arguments, r)
                except Exception as e:
                    results[idx] = f"Error: {e}"
        return results


# ── structured-output helper ──────────────────────────────────────────────────

def _parse_structured(content: str, response_model):
    """Parse *content* as JSON and validate against *response_model*.

    Strips markdown code fences if the model added them.
    Falls back to returning a plain dict on validation error, or the raw string
    on JSON parse error.
    """
    import json as _j
    import re as _re

    text = content.strip()
    # Strip ```json … ``` or ``` … ``` fences
    text = _re.sub(r"^```[a-zA-Z]*\n?", "", text)
    text = _re.sub(r"\n?```$", "", text.strip())
    text = text.strip()

    try:
        data = _j.loads(text)
    except Exception:
        return content  # JSON parse failed — return raw string

    try:
        return response_model.model_validate(data)
    except Exception:
        return data  # pydantic validation failed — return plain dict


# ── stream response container ─────────────────────────────────────────────────

class StreamResponse:
    """Iterable token stream that also exposes the complete final response.

    Returned by :meth:`Agent.stream`.  Iterating yields tokens as they arrive;
    after the iterator is exhausted, :attr:`result` holds the full response.

    Example::

        stream = agent.stream("Explain BFS")
        for tok in stream:
            print(tok, end="", flush=True)
        print()
        print("Full:", stream.result)

        # Works with response_model too:
        from pydantic import BaseModel
        class Point(BaseModel):
            x: int; y: int

        stream = agent.stream("give coords", response_model=Point)
        for tok in stream: print(tok, end="")
        point: Point = stream.result
    """

    def __init__(self, agent: "Agent", user_input: str, **kwargs):
        self._agent = agent
        self._user_input = user_input
        self._kwargs = kwargs
        self._result = None
        self._iterated = False

    def __iter__(self):
        import queue as _q
        if self._iterated:
            return  # can only iterate once
        self._iterated = True

        _sentinel = object()
        _tok_queue: _q.Queue = _q.Queue()
        _orig_on_token = self._kwargs.pop("on_token", None)

        def _on_token(tok: str) -> None:
            _tok_queue.put(tok)
            if _orig_on_token:
                _orig_on_token(tok)

        def _run() -> None:
            try:
                self._result = self._agent.chat(
                    self._user_input,
                    on_token=_on_token,
                    **self._kwargs,
                )
            finally:
                _tok_queue.put(_sentinel)

        _t = threading.Thread(target=_run, daemon=True)
        _t.start()

        while True:
            item = _tok_queue.get()
            if item is _sentinel:
                break
            yield item

    @property
    def result(self):
        """Full response after iteration completes (None before).

        When ``response_model`` was passed to :meth:`Agent.stream`,
        this is the parsed model instance rather than a plain string.
        """
        return self._result
