"""System prompt — turns an LLM into a coding agent aware of BYOE project context.

Deep integration: if the current directory contains Crew project files
(INSTRUCTIONS.md, crew.yaml, crew/resume.md), they are automatically
appended to the system prompt so the agent understands the project's workflow,
active changes, and architectural constraints without the user having to paste
anything manually.
"""

import os
import platform
from datetime import datetime
from pathlib import Path
from byoe.orchestrator.utils import pkg_agents_dir

# ── Crew context mtime cache ─────────────────────────────────────────────────
# Maps cwd_str -> {"mtime_key": str, "context": str}
# Invalidated whenever the relevant files' mtimes change.
_crew_cache: dict[str, dict] = {}


def _crew_mtime_key(cwd: Path) -> str:
    """Return a string that changes whenever any crew file is modified."""
    files = [
        cwd / "INSTRUCTIONS.md",
        cwd / "crew.yaml",
        cwd / "crew" / "resume.md",
        cwd / "crew" / "blockers.md",
    ]
    parts = []
    for f in files:
        if f.exists():
            try:
                parts.append(f"{f.name}:{int(f.stat().st_mtime)}")
            except OSError:
                pass
    return "|".join(parts) or "none"


def system_prompt(tools, cwd: str | None = None) -> str:
    effective_cwd = cwd or os.getcwd()
    tool_list = "\n".join(f"- **{t.name}**: {t.description}" for t in tools)
    uname = platform.uname()
    now = datetime.now().strftime("%Y-%m-%d %H:%M (%A)")

    base = f"""\
You are 卜一智航 (BYOE Executive), an AI coding assistant by byoe.net.
You help with software engineering: writing code, fixing bugs, refactoring,
explaining code, running commands, and more.

# Environment
- Working directory: {effective_cwd}
- OS: {uname.system} {uname.release} ({uname.machine})
- Python: {platform.python_version()}
- Current date/time: {now}

# Tools
{tool_list}

# Rules
1. **Explore before guessing.** For large codebases, use `get_repo_map` first to understand the project structure and symbol definitions.
2. **Read before edit.** Always read a file before modifying it.
3. **edit_file for small changes.** Use edit_file for targeted edits; write_file only for new files or complete rewrites.
4. **Verify your work.** After making changes, run relevant tests or commands to confirm correctness.
5. **Be concise.** Show code over prose. Explain only what's necessary.
6. **One step at a time.** For multi-step tasks, execute them sequentially.
7. **edit_file uniqueness.** When using edit_file, include enough surrounding context in old_string to guarantee a unique match.
8. **Long-Term Memory.** Use search_memory for tricky bugs to recall past fixes. Use record_memory to persist newly learned skills or hard-won bugfixes.
9. **Skill evolution.** If you discover a reusable multi-step solution, use create_skill to persist it and load_skill to attach it as a callable runtime tool.
10. **Respect existing style.** Match the project's coding conventions.
11. **Ask when unsure.** If the request is ambiguous, ask for clarification.
"""

    # ── Deep integration: inject Crew project context if present ───────────
    crew_context = _load_crew_context(Path(effective_cwd))
    if crew_context:
        base += crew_context

    return base


def _load_crew_context(cwd: Path) -> str:
    """Load crew context with mtime-based caching.

    Re-reads files only when their mtimes have changed since the last call,
    so repeated system prompt rebuilds (e.g. on every reset()) are cheap.
    """
    global _crew_cache
    key = str(cwd)
    mtime_key = _crew_mtime_key(cwd)
    cached = _crew_cache.get(key)
    if cached and cached["mtime_key"] == mtime_key:
        return cached["context"]
    context = _load_crew_context_fresh(cwd)
    _crew_cache[key] = {"mtime_key": mtime_key, "context": context}
    return context


def _load_crew_context_fresh(cwd: Path) -> str:
    """Unconditionally read crew files from disk and build context string."""
    instructions = cwd / "INSTRUCTIONS.md"
    crew_yaml     = cwd / "crew.yaml"
    resume        = cwd / "crew" / "resume.md"
    blockers      = cwd / "crew" / "blockers.md"

    # Only inject if at least INSTRUCTIONS.md or crew.yaml exists
    if not instructions.exists() and not crew_yaml.exists():
        return ""

    parts: list[str] = ["\n\n---\n# BYOE Project Context (Crew)\n"]
    parts.append(
        "_The following context is auto-loaded from the Crew workspace. "
        "Follow the workflow and constraints described below._\n"
    )

    if instructions.exists():
        parts.append(f"\n## Project Instructions\n\n{_read_truncated(instructions, 6000)}")

    if crew_yaml.exists():
        parts.append(
            f"\n## Project Configuration ({crew_yaml.name})\n\n"
            f"```yaml\n{_read_truncated(crew_yaml, 2000)}```"
        )

    if resume.exists():
        parts.append(f"\n## Current Sprint Status\n\n{_read_truncated(resume, 3000)}")

    if blockers.exists():
        content = blockers.read_text(encoding="utf-8").strip()
        if content and "（无待解决问题）" not in content:
            parts.append(f"\n## Open Blockers\n\n{_read_truncated(blockers, 1500)}")

    # ── Auto-load activated specialists ───────────────────────────────────────
    specialists_context = _load_specialists(cwd)
    if specialists_context:
        parts.append(specialists_context)

    return "\n".join(parts)


def _load_specialists(cwd: Path) -> str:
    """Read activated specialists from crew.yaml and inject their .md content.

    Returns a formatted string to append to the system prompt, or "" if no
    specialists are configured or their files cannot be found.
    """
    import re
    crew_yaml = cwd / "crew.yaml"
    if not crew_yaml.exists():
        return ""

    # Parse the specialists list from YAML (simple regex, no dep on PyYAML)
    text = crew_yaml.read_text(encoding="utf-8")
    # Match: specialists:\n  - name\n  - name2
    block_match = re.search(r"^specialists:\s*\n((?:[ \t]+-[ \t]+\S.*\n?)*)", text, re.MULTILINE)
    if not block_match:
        return ""
    specialist_ids: list[str] = []
    for line in block_match.group(1).splitlines():
        m = re.match(r"[ \t]+-[ \t]+(\S+)", line)
        if m:
            specialist_ids.append(m.group(1).strip().strip('"\''))

    if not specialist_ids:
        return ""

    agents_dir = pkg_agents_dir()

    parts: list[str] = ["\n## Activated Specialists\n"]
    parts.append(
        "_These domain expert personas are auto-loaded from your crew.yaml specialists list. "
        "Draw on their expertise at the appropriate PDEVI phases._\n"
    )

    loaded = 0
    for sid in specialist_ids:
        md_path = agents_dir / f"{sid}.md"
        if not md_path.exists():
            continue
        content = _read_truncated(md_path, 3000)
        parts.append(f"\n### Specialist: `{sid}`\n\n{content}")
        loaded += 1

    if loaded == 0:
        return ""

    return "\n".join(parts)


def _read_truncated(path: Path, max_chars: int) -> str:
    """Read a file and truncate if it exceeds max_chars to protect context window."""
    text = path.read_text(encoding="utf-8")
    if len(text) <= max_chars:
        return text
    half = max_chars // 2
    return (
        text[:half]
        + f"\n\n... [{len(text) - max_chars} chars omitted to fit context window] ...\n\n"
        + text[-(max_chars - half):]
    )
