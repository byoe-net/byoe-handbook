"""Repository Map Tool.

Generates a lightweight abstract syntax tree (AST) or structural outline
of a project to give the Agent a "bird's-eye view" of the codebase without
having to read every file.

For Python, uses the built-in `ast` module.
For JS/TS, uses simple regex heuristics.
"""

import ast
import os
import re
from pathlib import Path

from .base import Tool


class RepoMapTool(Tool):
    name = "get_repo_map"
    description = (
        "Generate a structural map of the repository (classes, functions, "
        "and file paths). Use this to explore a large codebase quickly."
    )
    parameters = {
        "type": "object",
        "properties": {
            "directory": {
                "type": "string",
                "description": "The root directory to map (default: current directory).",
            },
            "include_patterns": {
                "type": "string",
                "description": "Comma-separated extensions to include (e.g. '.py,.ts,.js'). Default: '.py,.ts,.js'.",
            },
        },
        "required": [],
    }

    def execute(self, directory: str = ".", include_patterns: str = ".py,.ts,.js,.java,.cs") -> str:
        root = Path(directory).resolve()
        if not root.is_dir():
            return f"Error: directory '{directory}' does not exist."

        exts = [e.strip() for e in include_patterns.split(",") if e.strip()]
        if not exts:
            exts = [".py", ".ts", ".js", ".java", ".cs"]

        skip_dirs = {".git", "node_modules", "venv", "__pycache__", "build", "dist", ".byoe", "target", "bin", "obj"}

        map_lines = [f"Repository Map for {root.name}/"]
        found_files = 0
        
        for dirpath, dirnames, filenames in os.walk(root):
            # Prune ignored dirs
            dirnames[:] = [d for d in dirnames if d not in skip_dirs and not d.startswith(".")]

            for fname in sorted(filenames):
                p = Path(dirpath) / fname
                if p.suffix in exts:
                    rel_path = p.relative_to(root).as_posix()
                    found_files += 1
                    map_lines.append(f"\n📄 {rel_path}")
                    try:
                        content = p.read_text(encoding="utf-8")
                        if p.suffix == ".py":
                            map_lines.extend(self._parse_python(content))
                        elif p.suffix in (".js", ".ts", ".jsx", ".tsx"):
                            map_lines.extend(self._parse_js_ts(content))
                        elif p.suffix in (".java", ".cs"):
                            map_lines.extend(self._parse_java_cs(content))
                    except Exception as e:
                        map_lines.append(f"  [Error reading map: {e}]")

        if found_files == 0:
            return f"No code files found matching {exts} in {root}."

        res = "\n".join(map_lines)
        if len(res) > 30_000:
            return res[:15000] + "\n\n... (Map truncated due to size) ...\n\n" + res[-15000:]
        return res

    def _parse_python(self, content: str) -> list[str]:
        out = []
        try:
            tree = ast.parse(content)
            for node in tree.body:
                if isinstance(node, ast.ClassDef):
                    out.append(f"  class {node.name}:")
                    for sub in node.body:
                        if isinstance(sub, ast.FunctionDef):
                            out.append(f"    def {sub.name}(...)")
                elif isinstance(node, ast.FunctionDef):
                    out.append(f"  def {node.name}(...)")
        except SyntaxError:
            out.append("  [Syntax error in file]")
        return out

    def _parse_js_ts(self, content: str) -> list[str]:
        # Simple heuristic regex for common JS/TS constructs
        out = []
        lines = content.splitlines()
        
        class_pattern = re.compile(r"^(?:export\s+)?class\s+(\w+)")
        func_pattern = re.compile(r"^(?:export\s+)?(?:async\s+)?function\s+(\w+)")
        arrow_pattern = re.compile(r"^(?:export\s+)?const\s+(\w+)\s*=\s*(?:async\s+)?(?:\([^)]*\)|[^=]+)=>\s*\{")

        for line in lines:
            line_str = line.strip()
            
            mc = class_pattern.search(line_str)
            if mc:
                out.append(f"  class {mc.group(1)} {{...}}")
                continue
                
            mf = func_pattern.search(line_str)
            if mf:
                out.append(f"  function {mf.group(1)}(...)")
                continue

            ma = arrow_pattern.search(line_str)
            if ma:
                out.append(f"  const {ma.group(1)} = (...) => {{...}}")

        return out

    def _parse_java_cs(self, content: str) -> list[str]:
        # Simple heuristic regex for basic Java and C# constructs
        out = []
        lines = content.splitlines()

        class_pattern = re.compile(r"(?:public|protected|private|internal|internal\s+protected|protected\s+internal|static|abstract|sealed|partial)?\s*(?:class|interface|struct|enum|record)\s+(\w+)")
        method_pattern = re.compile(r"(?:public|protected|private|internal|static|virtual|override|abstract|sealed|final|async|synchronized)?\s*(?:[\w<>\[\]\?]+)\s+(\w+)\s*\([^)]*\)\s*(?:throws\s+[\w\s,]+)?\s*\{?")

        for line in lines:
            line_str = line.strip()
            
            # Skip pure comments or attributes/annotations
            if line_str.startswith("//") or line_str.startswith("/*") or line_str.startswith("*") or line_str.startswith("@") or line_str.startswith("["):
                continue

            mc = class_pattern.search(line_str)
            if mc and not line_str.endswith(";"):
                out.append(f"  class/interface {mc.group(1)} {{...}}")
                continue

            mm = method_pattern.search(line_str)
            if mm and not line_str.endswith(";") and not "=" in line_str and not "return " in line_str:
                out.append(f"  method {mm.group(1)}(...)")
                continue

        return out
