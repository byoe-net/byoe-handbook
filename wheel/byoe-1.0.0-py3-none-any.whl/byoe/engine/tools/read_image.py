"""Image reading tool.

Loads an image file and returns it as a ``data:image/TYPE;base64,DATA`` URL.
The Agent framework detects this prefix and injects the image as a vision
content part in the next LLM call, enabling multimodal analysis.

Supported formats: JPEG, PNG, GIF, WebP (all accepted by OpenAI vision API).
Maximum size: 20 MB (OpenAI limit).
"""
from __future__ import annotations

import base64
from pathlib import Path

from .base import Tool

# Magic-byte signatures for common image formats
_SIGNATURES: list[tuple[bytes, str]] = [
    (b"\xff\xd8\xff", "image/jpeg"),
    (b"\x89PNG\r\n\x1a\n", "image/png"),
    (b"GIF87a", "image/gif"),
    (b"GIF89a", "image/gif"),
    (b"RIFF", "image/webp"),  # RIFF....WEBP checked below
]
_MAX_BYTES = 20 * 1024 * 1024  # 20 MB


def _detect_mime(header: bytes) -> str:
    for sig, mime in _SIGNATURES:
        if header[: len(sig)] == sig:
            if mime == "image/webp" and header[8:12] != b"WEBP":
                continue
            return mime
    return "image/png"  # safe fallback


class ReadImageTool(Tool):
    name = "read_image"
    description = (
        "Read an image file (JPEG, PNG, GIF, WebP) so you can describe or "
        "analyze its visual contents. The image is attached to the conversation "
        "as a multimodal vision input. Use this before asking questions about "
        "screenshots, diagrams, charts, or any visual content."
    )
    parameters = {
        "type": "object",
        "properties": {
            "file_path": {
                "type": "string",
                "description": "Path to the image file (JPEG, PNG, GIF, or WebP).",
            },
        },
        "required": ["file_path"],
    }

    def execute(self, file_path: str) -> str:
        try:
            p = Path(file_path).expanduser().resolve()
            if not p.exists():
                return f"Error: {file_path} not found"
            if not p.is_file():
                return f"Error: {file_path} is not a file"

            size = p.stat().st_size
            if size > _MAX_BYTES:
                return f"Error: image too large ({size // (1024*1024)} MB > 20 MB limit)"

            raw = p.read_bytes()
            mime = _detect_mime(raw[:16])
            b64 = base64.b64encode(raw).decode("ascii")
            # This data URL is recognized by Agent._exec_tool and converted to
            # a multimodal vision content part before the next LLM call.
            return f"data:{mime};base64,{b64}"
        except Exception as e:
            return f"Error reading image: {e}"
