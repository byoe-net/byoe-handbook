from .base import Tool

class RecordMemoryTool(Tool):
    name = "record_memory"
    description = "Record a piece of important information, experience, or skill to the long-term memory."
    parameters = {
        "type": "object",
        "properties": {
            "path": {
                "type": "string",
                "description": "A unique virtual file path representing this memory (e.g., '/skills/parse_logs' or '/bugs/jwt_skew')."
            },
            "content": {
                "type": "string",
                "description": "The actual detailed context, code, or explanation to remember."
            },
            "tags": {
                "type": "string",
                "description": "Comma-separated list of keywords."
            },
            "summary": {
                "type": "string",
                "description": "A short one-sentence summary."
            },
            "layer": {
                "type": "string",
                "description": "Memory layer: knowledge | session | short_term | ephemeral"
            }
        },
        "required": ["path", "content"]
    }

    def execute(self, path: str, content: str, tags: str = "", summary: str = "", layer: str = "knowledge") -> str:
        from ..light_memory import get_memory
        
        tag_list = [t.strip() for t in tags.split(",") if t.strip()] if tags else []
        layer_value = (layer or "knowledge").strip().lower()
        if layer_value not in {"knowledge", "session", "short_term", "ephemeral"}:
            layer_value = "knowledge"
        
        mem = get_memory()
        mem_id, was_update = mem.write(
            path=path,
            content=content,
            tags=tag_list,
            summary=summary,
            layer=layer_value
        )
        gc_stats = mem.gc(vacuum=False)
        action = "updated" if was_update else "created"
        return (
            f"Memory {action} at {path} (ID: {mem_id}, layer: {layer_value}). "
            f"Memory rows: {gc_stats['remaining']}"
        )

class SearchMemoryTool(Tool):
    name = "search_memory"
    description = "Search the long-term memory database for past experiences, skills, bugs, or knowledge."
    parameters = {
        "type": "object",
        "properties": {
            "query": {
                "type": "string",
                "description": "The keywords to search for."
            },
            "limit": {
                "type": "integer",
                "description": "Max number of results. default: 5"
            },
            "max_chars": {
                "type": "integer",
                "description": "Max characters to include per result content (default: 1200)."
            }
        },
        "required": ["query"]
    }

    def execute(self, query: str, limit: int = 5, max_chars: int = 1200) -> str:
        from ..light_memory import get_memory
        
        mem = get_memory()
        safe_limit = max(1, min(int(limit), 20))
        safe_max_chars = max(200, min(int(max_chars), 4000))
        results = mem.search(query, limit=safe_limit)
        
        if not results:
            return f"No memories found for query: '{query}'"
            
        out = [f"Found {len(results)} matching memories:\n"]
        for i, r in enumerate(results, 1):
            tags_str = ", ".join(r['tags'])
            out.append(f"--- Result {i} (Path: {r['path']} | Score: {r['score']:.2f}) ---")
            if r['summary']:
                out.append(f"Summary: {r['summary']}")
            if tags_str:
                out.append(f"Tags: {tags_str}")
            content = r.get("content", "")
            if len(content) > safe_max_chars:
                head = safe_max_chars // 2
                tail = safe_max_chars - head
                content = (
                    content[:head]
                    + f"\n... ({len(r.get('content', '')) - safe_max_chars} chars omitted) ...\n"
                    + content[-tail:]
                )
            out.append(f"Content:\n{content}\n")
            
        return "\n".join(out)

