"""File reading with line numbers and session-level content cache.

The cache stores (mtime, size, content) per resolved path.  If mtime and
size are unchanged the cached text is returned immediately — no I/O and no
new tokens consumed for repeated reads of the same unchanged file.
"""

import os
from pathlib import Path
from .base import Tool

# Module-level cache: resolved_path → (mtime_ns, size, numbered_text)
_FILE_CACHE: dict[str, tuple[int, int, str]] = {}


def _cache_key(p: Path) -> tuple[int, int]:
    """Return (mtime_ns, size) for cache validation."""
    st = p.stat()
    # On some Windows filesystems, rapid same-size rewrites can keep mtime_ns.
    # Fold in ctime_ns to improve change detection without altering cache shape.
    ctime_ns = getattr(st, "st_ctime_ns", int(st.st_ctime * 1_000_000_000))
    version_ns = st.st_mtime_ns if st.st_mtime_ns >= ctime_ns else ctime_ns
    return version_ns, st.st_size


class ReadFileTool(Tool):
    name = "read_file"
    description = (
        "Read a file's contents with line numbers. "
        "Repeated reads of an unchanged file are served from cache (no extra tokens). "
        "Always read a file before editing it."
    )
    parameters = {
        "type": "object",
        "properties": {
            "file_path": {"type": "string", "description": "Path to the file"},
            "offset": {"type": "integer", "description": "Start line (1-based). Default 1."},
            "limit": {"type": "integer", "description": "Max lines to read. Default 2000."},
        },
        "required": ["file_path"],
    }

    def execute(self, file_path: str, offset: int = 1, limit: int = 2000) -> str:
        try:
            p = Path(file_path).expanduser().resolve()
            if not p.exists():
                return f"Error: {file_path} not found"
            if not p.is_file():
                return f"Error: {file_path} is a directory, not a file"

            key = str(p)
            mtime_ns, size = _cache_key(p)

            # Cache hit: same mtime + size means content is unchanged
            cached = _FILE_CACHE.get(key)
            if cached and cached[0] == mtime_ns and cached[1] == size:
                text_lines = cached[2]
            else:
                raw = p.read_text(errors="replace")
                _FILE_CACHE[key] = (mtime_ns, size, raw)
                text_lines = raw

            lines = text_lines.splitlines()
            total = len(lines)

            start = max(0, offset - 1)
            chunk = lines[start: start + limit]
            numbered = [f"{start + i + 1}\t{ln}" for i, ln in enumerate(chunk)]
            result = "\n".join(numbered)

            if total > start + limit:
                result += f"\n... ({total} lines total, showing {start+1}-{start+len(chunk)})"
            return result or "(empty file)"
        except Exception as e:
            return f"Error: {e}"
