"""Tool registry.

ALL_TOOLS is the canonical *instance* list used by Agent (one instance per
session, wired by Agent._wire_tools).  The registry dict maps name → instance
for O(1) look-up and supports runtime registration of custom tools.

Plugin tools
============
Third-party packages can register additional tools by declaring an entry point
in their ``pyproject.toml``::

    [project.entry-points."byoe.tools"]
    my_sql_tool = "my_package.sql_tools:SqlQueryTool"

The class must subclass :class:`byoe.engine.tools.base.Tool`.  It will be
instantiated once at import time and appended to ``ALL_TOOLS`` / ``_REGISTRY``.
"""

from .bash import BashTool
from .read import ReadFileTool
from .write import WriteFileTool
from .edit import EditFileTool
from .glob_tool import GlobTool
from .grep import GrepTool
from .agent import AgentTool
from .fetch_url import FetchUrlTool
from .list_dir import ListDirTool
from .python_repl import PythonReplTool
from .web_search import WebSearchTool
from .git_tool import GitTool
from .todo_tool import TodoTool
from .run_tests import RunTestsTool
from .diff_file import DiffFileTool
from .memory import RecordMemoryTool, SearchMemoryTool
from .skills_runtime import CreateSkillTool, LoadSkillTool
from .repo_map import RepoMapTool
from .sober import SoberTool
from .swarm_tool import SwarmTool
from .read_image import ReadImageTool

ALL_TOOLS = [
    BashTool(),
    ReadFileTool(),
    WriteFileTool(),
    EditFileTool(),
    GlobTool(),
    GrepTool(),
    AgentTool(),
    FetchUrlTool(),
    ListDirTool(),
    PythonReplTool(),
    WebSearchTool(),
    GitTool(),
    TodoTool(),
    RunTestsTool(),
    DiffFileTool(),
    RecordMemoryTool(),
    SearchMemoryTool(),
    CreateSkillTool(),
    LoadSkillTool(),
    RepoMapTool(),
    SoberTool(),
    SwarmTool(),
    ReadImageTool(),
]

# O(1) name → instance map (kept in sync with ALL_TOOLS)
_REGISTRY: dict[str, object] = {t.name: t for t in ALL_TOOLS}


def get_tool(name: str):
    """Return the tool instance for *name*, or None if not found."""
    return _REGISTRY.get(name)


# ── plugin discovery ──────────────────────────────────────────────────────────

def _load_plugin_tools() -> list:
    """Discover tools registered via the ``byoe.tools`` entry-point group.

    Returns a list of instantiated tool objects.  Any plugin that fails to
    load is silently skipped so a broken plugin never prevents startup.
    """
    import importlib.metadata as _imeta

    discovered: list = []
    try:
        for ep in _imeta.entry_points(group="byoe.tools"):
            try:
                tool_cls = ep.load()
                discovered.append(tool_cls())
            except Exception:
                pass  # broken plugin — silently skip
    except Exception:
        pass
    return discovered


_plugin_tools = _load_plugin_tools()
if _plugin_tools:
    ALL_TOOLS.extend(_plugin_tools)
    _REGISTRY.update({t.name: t for t in _plugin_tools})


def register_tool(tool) -> None:
    """Register a custom tool at runtime.  Replaces any existing tool with the same name."""
    _REGISTRY[tool.name] = tool
    # Keep ALL_TOOLS in sync so Agent picks it up on next instantiation
    ALL_TOOLS[:] = [t for t in ALL_TOOLS if t.name != tool.name]
    ALL_TOOLS.append(tool)
