"""Swarm Collaboration Tool.

Enables the agent to orchestrate a relay pipeline where the output of 
one specialist agent is automatically passed as the input to the next.

Two execution modes:
- Sequential relay (``roles``): agents run one-after-one, each receives the previous output.
- Parallel groups (``parallel_groups``): each group of agents runs concurrently on the same
  input; their outputs are merged before being passed to the next group (scatter-gather).
"""

import concurrent.futures

from .base import Tool

class SwarmTool(Tool):
    name = "swarm_collaboration"
    description = (
        "Initiate a multi-agent swarm pipeline. "
        "Two modes:\n"
        "1. Sequential relay (roles): specialists run one-after-one; each receives the previous output. "
        "E.g. roles=['backend-architect','api-tester','security-engineer'].\n"
        "2. Parallel groups (parallel_groups): each group runs concurrently on the same input; "
        "outputs are merged and passed to the next group. "
        "E.g. parallel_groups=[['security-engineer','performance-reviewer'],['tech-lead']] "
        "— the first two run in parallel, then the tech-lead reviews their combined output. "
        "Available roles: backend-architect, frontend-specialist, security-engineer, "
        "api-tester, ui-designer, devops-engineer, performance-reviewer, tech-lead, etc. "
        "(Dynamic roles are supported.)"
    )
    parameters = {
        "type": "object",
        "properties": {
            "initial_task": {
                "type": "string", 
                "description": "The foundational task or requirement to kick off the swarm."
            },
            "roles": {
                "type": "array",
                "items": {"type": "string"},
                "description": "Sequential relay: ordered list of roles. Each receives the previous agent's output. E.g. ['backend-architect', 'api-tester', 'tech-lead']."
            },
            "parallel_groups": {
                "type": "array",
                "items": {
                    "type": "array",
                    "items": {"type": "string"}
                },
                "description": "Parallel-group mode (alternative to roles). List of role batches. Roles within a batch run concurrently; batches run sequentially with merged output. E.g. [['security-engineer','performance-reviewer'],['tech-lead']]."
            },
            "inherit_crew_context": {
                "type": "boolean", 
                "description": "If true, inject the project's Crew context. Default: true"
            },
            "step_timeout_seconds": {
                "type": "integer",
                "description": "Per-step timeout in seconds (default 300, max 3600). The step agent is aborted if it exceeds this limit."
            },
        },
        "required": ["initial_task"],
    }

    _parent_agent = None  # set by Agent.__init__

    def execute(
        self,
        initial_task: str,
        roles: list[str] | None = None,
        parallel_groups: list[list[str]] | None = None,
        inherit_crew_context: bool = True,
        step_timeout_seconds: int = 300,
    ) -> str:
        if self._parent_agent is None:
            return "Error: swarm tool not initialized (no parent agent)"

        if not roles and not parallel_groups:
            return "Error: provide either 'roles' (sequential relay) or 'parallel_groups'."

        step_timeout = max(30, min(int(step_timeout_seconds), 3600))

        from ..agent import Agent as _Agent  # noqa: F401 – imported in _build_sub_agent
        from pathlib import Path

        parent = self._parent_agent
        
        # Load local agent roles if possible
        agents_dir = Path(__file__).parent.parent.parent / "agents"

        # Route to the appropriate execution mode
        if parallel_groups is not None:
            return self._run_parallel_groups(
                initial_task, parallel_groups, inherit_crew_context,
                step_timeout, agents_dir, parent,
            )
        return self._run_sequential(
            initial_task, roles or [], inherit_crew_context,
            step_timeout, agents_dir, parent,
        )

    # ── shared helpers ────────────────────────────────────────────────────────

    def _build_sub_agent(self, role, agents_dir, parent, inherit_crew_context):
        """Instantiate a sub-Agent configured for *role*."""
        from ..agent import Agent
        from ..prompt import system_prompt as build_system_prompt
        from ..llm import LLM
        from pathlib import Path as _Path

        normalized_role = role.lower().replace(" ", "-")
        role_prompt = role
        role_file = _Path(agents_dir) / f"{normalized_role}.md"
        if role_file.exists():
            try:
                role_prompt = role_file.read_text(encoding="utf-8")
            except Exception:
                pass

        if inherit_crew_context:
            base_tools = [t for t in parent.tools if t.name not in ("agent", "swarm_collaboration")]
            sub_system_base = build_system_prompt(base_tools)
        else:
            sub_system_base = "You are a helpful AI assistant."

        sub_system = f"{role_prompt}\n\n[Previous Pipeline Output/Context]:\n{sub_system_base}"
        sub_llm = LLM(
            model=parent.llm.model,
            api_key=parent.llm._api_key,
            base_url=parent.llm._base_url,
            **parent.llm.extra,
        )
        return Agent(
            llm=sub_llm,
            tools=[t for t in parent.tools if t.name not in ("agent", "swarm_collaboration")],
            max_context_tokens=parent.context.max_tokens,
            max_rounds=15,
            system=sub_system,
        )

    def _run_one_step(self, sub, task, step_timeout):
        """Run *sub*.chat(*task*) with timeout. Returns (result, error, timed_out)."""
        executor = concurrent.futures.ThreadPoolExecutor(max_workers=1)
        future = executor.submit(sub.chat, task)
        result = error = None
        timed_out = False
        try:
            result = future.result(timeout=step_timeout)
        except concurrent.futures.TimeoutError:
            sub.abort()
            timed_out = True
        except Exception as e:
            error = e
        finally:
            executor.shutdown(wait=False)
        return result, error, timed_out

    def _maybe_compress(self, text, parent):
        if len(text) > 6000:
            from .agent import _summarize_sub_output
            return _summarize_sub_output(text, parent.llm)
        return text

    # ── sequential relay ──────────────────────────────────────────────────────

    def _run_sequential(self, initial_task, roles, inherit_crew_context,
                        step_timeout, agents_dir, parent):
        transcript = [f"=== Swarm Sequential Relay: {initial_task[:80]}... ==="]
        current_input = initial_task
        error_count = 0

        for i, role in enumerate(roles):
            transcript.append(f"\n[{i+1}/{len(roles)}] → {role.upper()}")
            sub = self._build_sub_agent(role, agents_dir, parent, inherit_crew_context)

            if i == 0:
                node_task = f"Swarm Step 1. Your role: {role}.\n\nTask:\n{current_input}"
            else:
                node_task = (
                    f"Swarm Step {i+1}. Your role: {role}. "
                    f"Continue or review the previous step's output.\n\n"
                    f"--- Previous Step Output ---\n{current_input}\n"
                    f"----------------------------\n\nOriginal Goal: {initial_task}"
                )

            result, error, timed_out = self._run_one_step(sub, node_task, step_timeout)

            if timed_out or error:
                label = "TIMEOUT" if timed_out else "ERROR"
                detail = f"exceeded {step_timeout}s" if timed_out else str(error)
                msg = f"[SWARM {label}] Step {i+1} ({role}): {detail}"
                transcript.append(msg)
                current_input = f"{msg}\n\nPrevious input:\n{current_input[:2000]}"
                error_count += 1
                if error_count > len(roles) // 2:
                    transcript.append(f"[SWARM ABORTED] Too many failures ({error_count}/{len(roles)}).")
                    break
                continue

            compressed = self._maybe_compress(result, parent)
            current_input = compressed
            transcript.append(f"Result from {role}:\n{compressed[:1000]}...\n(len={len(result)})")

        transcript.append("\n=== Swarm Sequential Relay Completed ===")
        final_log = "\n".join(transcript)
        if len(final_log) > 15000:
            from .agent import _summarize_sub_output
            return _summarize_sub_output(final_log, parent.llm)
        return final_log

    # ── parallel groups (scatter-gather) ──────────────────────────────────────

    def _run_parallel_groups(self, initial_task, parallel_groups, inherit_crew_context,
                             step_timeout, agents_dir, parent):
        """Execute parallel_groups in sequence; within each group, agents run concurrently.

        All agents in a group receive the *same* input.  Their outputs are merged
        and become the input for the next group.
        """
        transcript = [f"=== Swarm Parallel Groups: {initial_task[:80]}... ==="]
        current_input = initial_task

        for g_idx, group in enumerate(parallel_groups):
            if not group:
                continue
            transcript.append(f"\n[Group {g_idx+1}/{len(parallel_groups)}] "
                               f"Running {len(group)} agent(s) in parallel: {group}")

            node_task = (
                f"Swarm Group {g_idx+1}. Your role: {{role}}.\n\n"
                f"{'Task' if g_idx == 0 else 'Previous groups output'}:\n{current_input}\n\n"
                f"Original Goal: {initial_task}"
            )

            # Submit all agents in this group concurrently
            group_futures: dict = {}
            with concurrent.futures.ThreadPoolExecutor(max_workers=len(group)) as pool:
                for role in group:
                    sub = self._build_sub_agent(role, agents_dir, parent, inherit_crew_context)
                    task = node_task.replace("{role}", role)
                    group_futures[pool.submit(sub.chat, task)] = (role, sub)

                group_results: list[str] = []
                for future in concurrent.futures.as_completed(
                    group_futures, timeout=step_timeout + 5
                ):
                    role, sub = group_futures[future]
                    try:
                        res = future.result(timeout=1)
                        compressed = self._maybe_compress(res, parent)
                        group_results.append(f"[{role}]\n{compressed}")
                        transcript.append(f"  ✓ {role}: {compressed[:400]}...")
                    except concurrent.futures.TimeoutError:
                        sub.abort()
                        msg = f"[TIMEOUT] {role} exceeded {step_timeout}s"
                        group_results.append(msg)
                        transcript.append(f"  ✗ {msg}")
                    except Exception as e:
                        msg = f"[ERROR] {role}: {e}"
                        group_results.append(msg)
                        transcript.append(f"  ✗ {msg}")

            # Merge group outputs for the next stage
            merged = "\n\n".join(group_results)
            current_input = self._maybe_compress(merged, parent)

        transcript.append("\n=== Swarm Parallel Groups Completed ===")
        transcript.append(f"\nFinal output:\n{current_input}")
        final_log = "\n".join(transcript)
        if len(final_log) > 15000:
            from .agent import _summarize_sub_output
            return _summarize_sub_output(final_log, parent.llm)
        return final_log