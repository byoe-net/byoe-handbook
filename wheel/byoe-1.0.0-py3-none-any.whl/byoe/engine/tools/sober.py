# -*- coding: utf-8 -*-
"""Sober-coding (Vibe coding hangover cure) implementation in Python.
Ported from typescript into a native BYOE tool.
"""
from typing import Dict, List, Set, Any
import os
import re

class Issue:
    def __init__(self, id: str, title: str, severity: str, file: str, line: int = None, detail: str = ""):
        self.id = id
        self.title = title
        self.severity = severity
        self.file = file
        self.line = line
        self.detail = detail

class FileEntry:
    def __init__(self, path: str, content: str):
        self.path = path
        self.content = content
        self.lines = content.splitlines()

class ScanResult:
    def __init__(self, path: str, files: int, lines: int, issues: List[Issue], score: int, level: str):
        self.path = path
        self.files = files
        self.lines = lines
        self.issues = issues
        self.score = score
        self.level = level

def check_security(files: List[FileEntry]) -> List[Issue]:
    issues = []
    # SEC-001 Hardcoded secrets
    # Matches pseudo-secrets: tokens, AWS keys, pk, etc.
    secret_patterns = [
        re.compile(r"(api_key|apikey|secret|password|passwd|token)[^\w]*(=|:)\s*['\"]((?!env|process|os\.).{5,})['\"]", re.IGNORECASE),
        re.compile(r"(AKIA[0-9A-Z]{16})")
    ]
    # SEC-002 SQL injection risk
    sql_inj_pattern = re.compile(r"SELECT.*FROM.*WHERE.*\s*\+\s*[a-zA-Z_]", re.IGNORECASE)

    for file in files:
        for i, line in enumerate(file.lines):
            for pat in secret_patterns:
                if pat.search(line):
                    issues.append(Issue("SEC-001", "Hardcoded secrets", "critical", file.path, i + 1, "Hardcoded secret detected."))
                    break
            
            if sql_inj_pattern.search(line):
                issues.append(Issue("SEC-002", "SQL injection risk", "critical", file.path, i + 1, "String concatenation in SQL queries."))
                
    return issues

def check_architecture(files: List[FileEntry]) -> List[Issue]:
    issues = []
    db_patterns = [re.compile(r"\bSELECT\b", re.I), re.compile(r"\bINSERT\b", re.I), re.compile(r"\bUPDATE\b", re.I), re.compile(r"\bDELETE\b", re.I), re.compile(r"\.query\s*\(")]
    http_patterns = [re.compile(r"\breq\s*,\s*res\b"), re.compile(r"\bapp\.(get|post|put|delete|patch)\s*\("), re.compile(r"\brouter\.(get|post|put|delete|patch)\s*\(")]
    
    for file in files:
        # ARC-001 God files
        if len(file.lines) > 500:
            issues.append(Issue("ARC-001", "God file", "medium", file.path, detail=f"File has {len(file.lines)} lines (>500). Consider splitting into smaller modules."))

        # ARC-003 Mixed concerns
        has_db = any(pat.search(file.content) for pat in db_patterns)
        has_http = any(pat.search(file.content) for pat in http_patterns)
        if has_db and has_http:
            issues.append(Issue("ARC-003", "Mixed concerns", "medium", file.path, detail="File mixes database operations and HTTP handlers. Separate into distinct layers."))

        # ARC-005 Spaghetti imports
        import_count = 0
        for line in file.lines:
            trimmed = line.lstrip()
            if re.match(r"^import\s", trimmed) or re.match(r"^from\s+\S+\s+import", trimmed):
                import_count += 1
        
        if import_count > 15:
            issues.append(Issue("ARC-005", "Spaghetti imports", "low", file.path, detail=f"File has {import_count} imports (>15)."))
            
    return issues

def check_dead_code(files: List[FileEntry]) -> List[Issue]:
    # Simplified dead code checker
    issues = []
    terminal_stmt = re.compile(r"^\s*(return\b|throw\b|break\s*;|continue\s*;)")
    
    for file in files:
        is_dead = False
        for i, line in enumerate(file.lines):
            trimmed = line.lstrip()
            if not trimmed or trimmed.startswith("//") or trimmed.startswith("#"):
                continue
                
            if is_dead and trimmed and not trimmed.startswith("}"):
                issues.append(Issue("DEAD-003", "Unreachable code", "medium", file.path, i + 1, "Code after return/throw/break/continue."))
                is_dead = False # only report once per block
                
            if terminal_stmt.match(line):
                is_dead = True
            elif is_dead and trimmed.startswith("}"):
                is_dead = False
                
    return issues

def scan_sober(target_dir: str) -> ScanResult:
    import glob
    
    ignore_dirs = {".git", "node_modules", "dist", "build", "vendor", "__pycache__", ".byoe"}
    code_exts = {".js", ".ts", ".jsx", ".tsx", ".py", ".go", ".rs", ".java", ".php", ".c", ".cpp", ".cs", ".vue", ".svelte", ".mjs", ".cjs"}
    
    files = []
    total_lines = 0
    
    for root, dirs, filenames in os.walk(target_dir):
        dirs[:] = [d for d in dirs if d not in ignore_dirs and not d.startswith(".")]
        for fname in filenames:
            ext = os.path.splitext(fname)[1].lower()
            if ext in code_exts:
                fpath = os.path.join(root, fname)
                try:
                    with open(fpath, "r", encoding="utf-8") as f:
                        content = f.read()
                        files.append(FileEntry(fpath, content))
                        total_lines += len(content.splitlines())
                except Exception:
                    pass
                    
    issues = []
    issues.extend(check_security(files))
    issues.extend(check_architecture(files))
    issues.extend(check_dead_code(files))
    
    # Calculate score
    penalty = {"critical": 15, "high": 8, "medium": 4, "low": 1}
    total_penalty = sum(penalty.get(issue.severity, 0) for issue in issues)
    score_val = max(0, min(100, 100 - total_penalty))
    
    level = "SOBER"
    if score_val < 40:
        level = "BLACKOUT"
    elif score_val < 60:
        level = "HUNGOVER"
    elif score_val < 80:
        level = "TIPSY"
        
    return ScanResult(target_dir, len(files), total_lines, issues, score_val, level)


from .base import Tool  # noqa: E402 — placed after scan_sober to keep dataclass defs together


class SoberTool(Tool):
    """Tool wrapper — exposes scan_sober as an agent-callable tool."""

    name = "sober_scan"
    description = (
        "Scan the codebase for vibe-coding technical debt/AI code smells "
        "(such as dead code, god files, hardcoded secrets). "
        "Returns a detailed markdown report."
    )
    parameters = {
        "type": "object",
        "properties": {
            "directory": {
                "type": "string",
                "description": "The directory to scan (default: current directory).",
            },
        },
        "required": [],
    }

    def execute(self, directory: str = ".") -> str:
        try:
            result = scan_sober(directory)
            lines = [f"# Sober Scan Report - {result.path}"]
            lines.append(f"**Score**: {result.score}/100 ({result.level})")
            lines.append(f"**Files scanned**: {result.files}  **Lines**: {result.lines}")
            lines.append("\n## Issues Detected\n")
            if not result.issues:
                lines.append("No technical debt found. Excellent!")
            else:
                for issue in result.issues:
                    loc = f"{issue.file}:{issue.line}" if issue.line else issue.file
                    lines.append(f"- **[{issue.severity.upper()}]** {issue.id}: {issue.title}")
                    lines.append(f"  - Location: `{loc}`")
                    lines.append(f"  - Detail: {issue.detail}\n")
            out = "\n".join(lines)
            if len(out) > 10000:
                out = out[:10000] + "\n\n... [Report truncated]"
            return out
        except Exception as e:
            return f"Error running sober scan: {e}"
