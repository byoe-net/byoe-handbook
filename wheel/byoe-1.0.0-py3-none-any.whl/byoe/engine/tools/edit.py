"""Search-and-replace file editing."""

import difflib
import os
import tempfile
from pathlib import Path
from .base import Tool

# Module-level set kept only as a fallback for callers that instantiate
# EditFileTool without going through Agent (e.g. tests).  The Agent wires
# each tool to the shared session-scoped set via _set_changed_files().
_changed_files: set[str] = set()


class EditFileTool(Tool):
    name = "edit_file"
    description = (
        "Edit a file by replacing an exact string match. "
        "old_string must appear exactly once in the file for safety. "
        "Include enough surrounding context to ensure uniqueness."
    )
    parameters = {
        "type": "object",
        "properties": {
            "file_path": {"type": "string", "description": "Path to the file to edit"},
            "old_string": {"type": "string", "description": "Exact text to find (must be unique in file)"},
            "new_string": {"type": "string", "description": "Replacement text"},
        },
        "required": ["file_path", "old_string", "new_string"],
    }

    def __init__(self):
        # Per-instance change tracker; Agent will inject its own shared set.
        self._changed_files: set[str] = _changed_files

    def _set_changed_files(self, shared: set[str]) -> None:
        """Wire this tool to a session-scoped set owned by the Agent."""
        self._changed_files = shared

    def execute(self, file_path: str, old_string: str, new_string: str) -> str:
        try:
            p = Path(file_path).expanduser().resolve()
            if not p.exists():
                return f"Error: {file_path} not found"

            content = p.read_text(encoding="utf-8", errors="replace")
            occurrences = content.count(old_string)

            if occurrences == 0:
                preview = content[:500] + ("..." if len(content) > 500 else "")
                return (
                    f"Error: old_string not found in {file_path}.\n"
                    f"File starts with:\n{preview}"
                )
            if occurrences > 1:
                return (
                    f"Error: old_string appears {occurrences} times in {file_path}. "
                    f"Include more surrounding lines to make it unique."
                )

            new_content = content.replace(old_string, new_string, 1)
            # Atomic write: write to sibling temp file then rename,
            # so a crash mid-write never leaves a half-written file.
            # os.replace() is atomic on POSIX and near-atomic on Windows.
            tmp_fd, tmp_path = tempfile.mkstemp(dir=p.parent, prefix=".byoe_edit_")
            try:
                with os.fdopen(tmp_fd, "w", encoding="utf-8") as fh:
                    fh.write(new_content)
                os.replace(tmp_path, p)
            except Exception:
                try:
                    os.unlink(tmp_path)
                except OSError:
                    pass
                raise
            self._changed_files.add(str(p))
            # Invalidate read cache so the next read_file sees fresh content
            from byoe.engine.tools.read import _FILE_CACHE as _rc
            _rc.pop(str(p), None)

            diff = _unified_diff(content, new_content, str(p))
            return f"Edited {file_path}\n{diff}"
        except Exception as e:
            return f"Error: {e}"


def _unified_diff(old: str, new: str, filename: str, context: int = 3) -> str:
    old_lines = old.splitlines(keepends=True)
    new_lines = new.splitlines(keepends=True)
    diff = difflib.unified_diff(
        old_lines, new_lines,
        fromfile=f"a/{filename}", tofile=f"b/{filename}",
        n=context,
    )
    result = "".join(diff)
    if len(result) > 3000:
        result = result[:2500] + "\n... (diff truncated)\n"
    return result
