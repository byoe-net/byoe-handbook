"""Shell command execution with safety checks.

Cross-platform: uses cmd.exe on Windows, /bin/sh on Unix.
Dangerous-command detection covers both platforms.
"""

import os
import re
import subprocess
import sys
import tempfile
import threading
import time
import uuid
from pathlib import Path
from .base import Tool

# ── Unix dangerous patterns ───────────────────────────────────────────────────
_DANGEROUS_PATTERNS_UNIX = [
    (r"\brm\s+(-\w*)?-r\w*\s+(/|~|\$HOME)", "recursive delete on home/root"),
    (r"\brm\s+(-\w*)?-rf\s", "force recursive delete"),
    (r"\bmkfs\b", "format filesystem"),
    (r"\bdd\s+.*of=/dev/", "raw disk write"),
    (r">\s*/dev/sd[a-z]", "overwrite block device"),
    (r"\bchmod\s+(-R\s+)?777\s+/", "chmod 777 on root"),
    (r":\(\)\s*\{.*:\|:.*\}", "fork bomb"),
    (r"\bcurl\b.*\|\s*(sudo\s+)?bash", "pipe curl to bash"),
    (r"\bwget\b.*\|\s*(sudo\s+)?bash", "pipe wget to bash"),
]

# ── Windows dangerous patterns ────────────────────────────────────────────────
_DANGEROUS_PATTERNS_WIN = [
    (r"\brd\s+/s\s+/q\s+[a-zA-Z]:\\\\", "recursive delete of drive root"),
    (r"\brmdir\s+/s\s+/q\s+[a-zA-Z]:\\\\", "recursive delete of drive root"),
    (r"\bformat\s+[a-zA-Z]:", "format drive"),
    (r"\bdiskpart\b", "disk partition tool"),
    (r"\bdel\s+/[fsq]*\s+[a-zA-Z]:\\\\", "bulk delete from drive root"),
    (r"\bpowershell\b.*\|\s*iex\b", "pipe to Invoke-Expression"),
    (r"\bpowershell\b.*\bDownloadString\b.*\|\s*iex\b", "download and execute"),
]

_DANGEROUS_PATTERNS = (
    _DANGEROUS_PATTERNS_WIN if sys.platform == "win32" else _DANGEROUS_PATTERNS_UNIX
)


def _max_timeout() -> int:
    """Max bash timeout in seconds. Override via BYOE_BASH_TIMEOUT env var (default 600)."""
    try:
        return max(30, int(os.environ.get("BYOE_BASH_TIMEOUT", "600")))
    except ValueError:
        return 600


class BashTool(Tool):
    name = "bash"
    description = (
        "Execute a shell command. Returns stdout, stderr, and exit code. "
        "Use this for running tests, installing packages, git operations, etc."
    )
    parameters = {
        "type": "object",
        "properties": {
            "command": {"type": "string", "description": "The shell command to run"},
            "timeout": {"type": "integer", "description": "Timeout in seconds (default 120)"},
            "background": {"type": "boolean", "description": "Run command in background and return immediately"},
            "action": {"type": "string", "description": "run | status | read | stop (default run)"},
            "job_id": {"type": "string", "description": "Background job id used by status/read/stop"},
        },
        "required": [],
    }

    def __init__(self):
        # Per-instance working directory — eliminates the global mutable state
        # race condition when multiple tools/agents run concurrently.
        self._cwd: str | None = None
        # Optional sandbox root — if set, commands cannot cd outside this tree
        self._sandbox_root: str | None = None
        self._jobs: dict[str, dict] = {}
        self._jobs_lock = threading.Lock()

    def set_sandbox_root(self, path: str) -> None:
        """Restrict all execution to a subtree. Agent.reset should call this."""
        self._sandbox_root = os.path.realpath(path) if path else None

    def reset_cwd(self) -> None:
        """Reset tracked working directory (called by Agent.reset)."""
        self._cwd = None

    def set_cwd(self, path: str) -> None:
        """Explicitly set the working directory (e.g. for multi-tenant use)."""
        self._cwd = path

    def execute(
        self,
        command: str = "",
        timeout: int = 120,
        background: bool = False,
        action: str = "run",
        job_id: str = "",
    ) -> str:
        action = (action or "run").strip().lower()
        if action == "status":
            return self._job_status(job_id)
        if action == "read":
            return self._job_read(job_id)
        if action == "stop":
            return self._job_stop(job_id)

        if not command.strip():
            return "Error: command is required when action='run'"

        warning = _check_dangerous(command)
        if warning:
            return (
                f"⚠ Blocked: {warning}\nCommand: {command}\n"
                "If intentional, modify the command to be more specific."
            )

        timeout = max(1, min(int(timeout), _max_timeout()))
        cwd = self._safe_cwd()

        if background:
            return self._run_background(command, cwd)
        return self._run_foreground(command, timeout, cwd)

    def _safe_cwd(self) -> str:
        cwd = self._cwd or os.getcwd()
        if self._sandbox_root:
            real_cwd = os.path.realpath(cwd)
            if not real_cwd.startswith(self._sandbox_root):
                cwd = self._sandbox_root
        return cwd

    def _run_foreground(self, command: str, timeout: int, cwd: str) -> str:
        try:
            proc = self._spawn(command, cwd)
            stdout, stderr = proc.communicate(timeout=timeout)

            new_cwd = _resolve_cwd(command, cwd)
            if self._sandbox_root and not os.path.realpath(new_cwd).startswith(self._sandbox_root):
                new_cwd = self._sandbox_root
            self._cwd = new_cwd

            out = stdout or ""
            if stderr:
                out += f"\n[stderr]\n{stderr}"
            if proc.returncode != 0:
                out += f"\n[exit code: {proc.returncode}]"
            if len(out) > 15_000:
                out = out[:6000] + f"\n\n... truncated ({len(out)} chars total) ...\n\n" + out[-3000:]
            return out.strip() or "(no output)"
        except subprocess.TimeoutExpired:
            return f"Error: timed out after {timeout}s"
        except Exception as e:
            return f"Error running command: {e}"

    def _run_background(self, command: str, cwd: str) -> str:
        try:
            proc = self._spawn(command, cwd)
            job_id = f"job_{uuid.uuid4().hex[:8]}"
            log_path = Path(tempfile.gettempdir()) / f"byoe_{job_id}.log"

            with self._jobs_lock:
                self._jobs[job_id] = {
                    "proc": proc,
                    "cwd": cwd,
                    "command": command,
                    "started_at": time.time(),
                    "log_path": str(log_path),
                }

            t = threading.Thread(target=self._capture_output, args=(job_id,), daemon=True)
            t.start()
            return (
                f"Started background job: {job_id}\n"
                f"Use bash(action='status', job_id='{job_id}') to check status.\n"
                f"Use bash(action='read', job_id='{job_id}') to read logs.\n"
                f"Use bash(action='stop', job_id='{job_id}') to stop it."
            )
        except Exception as e:
            return f"Error starting background command: {e}"

    def _spawn(self, command: str, cwd: str) -> subprocess.Popen:
        if sys.platform == "win32":
            shell_args = ["cmd", "/c", command]
            return subprocess.Popen(
                shell_args,
                cwd=cwd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                encoding="utf-8",
                errors="replace",
            )
        return subprocess.Popen(
            command,
            shell=True,
            cwd=cwd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            encoding="utf-8",
            errors="replace",
        )

    def _capture_output(self, job_id: str) -> None:
        with self._jobs_lock:
            job = self._jobs.get(job_id)
        if not job:
            return

        proc = job["proc"]
        log_path = job["log_path"]
        try:
            stdout, stderr = proc.communicate()
            with open(log_path, "w", encoding="utf-8", errors="replace") as f:
                if stdout:
                    f.write(stdout)
                if stderr:
                    f.write("\n[stderr]\n")
                    f.write(stderr)
                f.write(f"\n[exit code: {proc.returncode}]\n")
        except Exception as e:
            with open(log_path, "w", encoding="utf-8", errors="replace") as f:
                f.write(f"capture error: {e}")

    def _job_status(self, job_id: str) -> str:
        with self._jobs_lock:
            job = self._jobs.get(job_id)
        if not job:
            return f"Error: job '{job_id}' not found"

        proc = job["proc"]
        code = proc.poll()
        state = "running" if code is None else f"finished (exit={code})"
        return (
            f"Job: {job_id}\n"
            f"State: {state}\n"
            f"Command: {job['command']}\n"
            f"Started: {int(time.time() - job['started_at'])}s ago"
        )

    def _job_read(self, job_id: str) -> str:
        with self._jobs_lock:
            job = self._jobs.get(job_id)
        if not job:
            return f"Error: job '{job_id}' not found"
        log_path = job["log_path"]
        if not os.path.isfile(log_path):
            return "(no output yet)"
        try:
            content = Path(log_path).read_text(encoding="utf-8", errors="replace")
            return content[-12000:] if content else "(no output yet)"
        except Exception as e:
            return f"Error reading log: {e}"

    def _job_stop(self, job_id: str) -> str:
        with self._jobs_lock:
            job = self._jobs.get(job_id)
        if not job:
            return f"Error: job '{job_id}' not found"
        proc = job["proc"]
        if proc.poll() is not None:
            return f"Job {job_id} already finished"
        try:
            proc.terminate()
            return f"Job {job_id} termination requested"
        except Exception as e:
            return f"Error stopping job {job_id}: {e}"


def _check_dangerous(cmd: str) -> str | None:
    for pattern, reason in _DANGEROUS_PATTERNS:
        if re.search(pattern, cmd):
            return reason
    return None


def _resolve_cwd(command: str, current_cwd: str) -> str:
    """Return updated working directory after any cd/Set-Location in command.
    Pure function — no global side effects.
    """
    separators = re.split(r"&&|;", command)
    result = current_cwd
    for part in separators:
        part = part.strip()
        m = re.match(r"(?:cd|Set-Location|sl)\s+(.+)", part, re.IGNORECASE)
        if m:
            target = m.group(1).strip().strip("'\"")
            if target:
                new_dir = os.path.normpath(
                    os.path.join(result, os.path.expanduser(target))
                )
                if os.path.isdir(new_dir):
                    result = new_dir
    return result
