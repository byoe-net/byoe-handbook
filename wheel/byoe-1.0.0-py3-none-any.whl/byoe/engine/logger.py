"""Lightweight structured logger for the BYOE agent engine.

Writes newline-delimited JSON to ~/.byoe/logs/agent.jsonl (rotating at 5 MB).
Enabled by setting the env var BYOE_LOG=1 (or BYOE_LOG=debug for verbose output).
Zero overhead when disabled — all calls are no-ops in that case.

Log entry schema:
    {
        "ts":      "2026-06-29T12:00:00.123Z",   # ISO-8601 UTC
        "level":   "info" | "debug" | "warn" | "error",
        "event":   "tool_call" | "tool_result" | "llm_request" | ...,
        "session": "<session_id or empty>",
        "data":    { ...event-specific fields... }
    }
"""
from __future__ import annotations

import json
import os
import sys
import threading
from datetime import datetime, timezone
from pathlib import Path

# ── Configuration ─────────────────────────────────────────────────────────────

_LOG_ENV = os.environ.get("BYOE_LOG", "").lower()
_ENABLED = _LOG_ENV in ("1", "true", "debug")
_VERBOSE = _LOG_ENV == "debug"

_LOG_DIR = Path.home() / ".byoe" / "logs"
_LOG_FILE = _LOG_DIR / "agent.jsonl"
_MAX_BYTES = 5 * 1024 * 1024  # 5 MB rotation threshold

_lock = threading.Lock()
_session_id: str = ""


def set_session(sid: str) -> None:
    """Bind a session id to all subsequent log entries."""
    global _session_id
    _session_id = sid


def _now_iso() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"


def _write(level: str, event: str, data: dict) -> None:
    if not _ENABLED:
        return
    entry = {
        "ts": _now_iso(),
        "level": level,
        "event": event,
        "session": _session_id,
        "data": data,
    }
    line = json.dumps(entry, ensure_ascii=False)

    # Also echo to stderr in verbose mode
    if _VERBOSE:
        sys.stderr.write(f"[byoe] {line}\n")

    try:
        with _lock:
            _LOG_DIR.mkdir(parents=True, exist_ok=True)
            # Rotate when file exceeds limit
            if _LOG_FILE.exists() and _LOG_FILE.stat().st_size > _MAX_BYTES:
                rotated = _LOG_FILE.with_suffix(f".{_now_iso()[:10]}.jsonl")
                _LOG_FILE.rename(rotated)
            with _LOG_FILE.open("a", encoding="utf-8") as fh:
                fh.write(line + "\n")
    except Exception:
        pass  # logging must never crash the agent


# ── Public helpers ────────────────────────────────────────────────────────────

def info(event: str, **data) -> None:
    _write("info", event, data)


def debug(event: str, **data) -> None:
    if _VERBOSE:
        _write("debug", event, data)


def warn(event: str, **data) -> None:
    _write("warn", event, data)


def error(event: str, **data) -> None:
    _write("error", event, data)


# ── Convenience event emitters ────────────────────────────────────────────────

def log_tool_call(name: str, arguments: dict) -> None:
    debug("tool_call", tool=name, args=_truncate_dict(arguments))


def log_tool_result(name: str, result: str, elapsed_ms: int | None = None) -> None:
    is_error = result.lower().startswith("error") if result else False
    entry: dict = {"tool": name, "result_len": len(result), "is_error": is_error}
    if elapsed_ms is not None:
        entry["elapsed_ms"] = elapsed_ms
    level = "warn" if is_error else "debug"
    _write(level, "tool_result", entry)


def log_llm_request(model: str, prompt_tokens: int, completion_tokens: int) -> None:
    info(
        "llm_request",
        model=model,
        prompt_tokens=prompt_tokens,
        completion_tokens=completion_tokens,
    )


def log_context_compress(layer: str, before: int, after: int) -> None:
    info(
        "context_compress",
        layer=layer,
        before_tokens=before,
        after_tokens=after,
        saved=before - after,
    )


def log_agent_turn(user_input: str, rounds_used: int, total_tokens: int) -> None:
    info(
        "agent_turn",
        input_preview=user_input[:120],
        rounds=rounds_used,
        total_tokens=total_tokens,
    )


# ── Internal helpers ──────────────────────────────────────────────────────────

def _truncate_dict(d: dict, max_val_len: int = 200) -> dict:
    """Return a copy of d with long string values truncated."""
    out = {}
    for k, v in d.items():
        if isinstance(v, str) and len(v) > max_val_len:
            out[k] = v[:max_val_len] + "…"
        else:
            out[k] = v
    return out
