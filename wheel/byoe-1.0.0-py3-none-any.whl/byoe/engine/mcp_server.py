"""MCP server — exposes BYOE's tools to any MCP client.

Implements the Model Context Protocol 2024-11-05 over stdio (default) or HTTP.

Stdio mode — VS Code, Claude Desktop, Cursor, Windsurf, Cline::

    byoe mcp-server

HTTP mode — Docker / remote access::

    byoe mcp-server --http --port 3000

VS Code (.vscode/mcp.json)::

    {
      "servers": {
        "byoe": {
          "type": "stdio",
          "command": "python",
          "args": ["-m", "byoe", "mcp-server"]
        }
      }
    }

Claude Desktop (~/.claude/claude_desktop_config.json)::

    {
      "mcpServers": {
        "byoe": {
          "command": "python",
          "args": ["-m", "byoe", "mcp-server"]
        }
      }
    }
"""
from __future__ import annotations

import json
import os
import sys
from typing import Any

from byoe.engine.tools import ALL_TOOLS
from byoe.engine.tools.base import Tool
from byoe.engine.tools.bash import BashTool
from byoe.engine.tools.edit import EditFileTool
from byoe.engine.tools.write import WriteFileTool

MCP_PROTOCOL_VERSION = "2024-11-05"


# ─────────────────────────── helpers ─────────────────────────────────────────

def _wire_tools(tools: list[Tool], cwd: str | None = None) -> dict[str, Tool]:
    """Inject per-session state and return name→tool map."""
    _cwd = cwd or os.getcwd()
    _changed: set[str] = set()
    for t in tools:
        if isinstance(t, (EditFileTool, WriteFileTool)):
            t._set_changed_files(_changed)
        if isinstance(t, BashTool):
            t.set_sandbox_root(_cwd)
    return {t.name: t for t in tools}


def _tool_to_mcp(tool: Tool) -> dict:
    """Convert a BYOE Tool to MCP tool descriptor (parameters → inputSchema)."""
    return {
        "name": tool.name,
        "description": tool.description,
        "inputSchema": tool.parameters,
    }


def _ok(msg_id: Any, result: Any) -> dict:
    return {"jsonrpc": "2.0", "id": msg_id, "result": result}


def _err(msg_id: Any, code: int, message: str) -> dict:
    return {"jsonrpc": "2.0", "id": msg_id, "error": {"code": code, "message": message}}


def _text(content: str) -> dict:
    return {"content": [{"type": "text", "text": content}]}


# ─────────────────────────── server ──────────────────────────────────────────

class MCPServer:
    """One MCP server session (one client connection).

    Handles JSON-RPC 2.0 messages for the MCP protocol:
    ``initialize``, ``tools/list``, ``tools/call``, ``ping``.
    """

    def __init__(self, cwd: str | None = None) -> None:
        # Fresh tool instances per server process; same instances for whole session.
        # Note: ALL_TOOLS is module-level; each `byoe mcp-server` is a separate
        # process so there is no cross-session contamination.
        self._tools: list[Tool] = list(ALL_TOOLS)
        self._tool_map: dict[str, Tool] = _wire_tools(self._tools, cwd)

    def handle(self, message: dict) -> dict | None:
        """Process one JSON-RPC message; return response or None for notifications."""
        method: str = message.get("method", "")
        msg_id = message.get("id")  # absent on notifications
        params: dict = message.get("params") or {}

        try:
            if method == "initialize":
                return _ok(msg_id, self._initialize(params))

            if method == "notifications/initialized":
                return None  # notification — no response expected

            if method == "tools/list":
                return _ok(msg_id, {"tools": [_tool_to_mcp(t) for t in self._tools]})

            if method == "tools/call":
                return _ok(msg_id, self._tools_call(params))

            if method == "ping":
                return _ok(msg_id, {})

            # Unknown method
            if msg_id is None:
                return None  # notification we don't understand — ignore
            return _err(msg_id, -32601, f"Method not found: {method}")

        except Exception as e:
            if msg_id is None:
                return None
            return _err(msg_id, -32603, f"Internal error: {e}")

    # ── protocol handlers ─────────────────────────────────────────────────────

    def _initialize(self, params: dict) -> dict:
        from byoe import __version__
        return {
            "protocolVersion": MCP_PROTOCOL_VERSION,
            "capabilities": {"tools": {"listChanged": False}},
            "serverInfo": {"name": "byoe", "version": __version__},
        }

    def _tools_call(self, params: dict) -> dict:
        name: str = params.get("name", "")
        arguments: dict = params.get("arguments") or {}
        tool = self._tool_map.get(name)
        if tool is None:
            raise ValueError(f"Unknown tool: '{name}'")
        try:
            result = tool.execute(**arguments)
        except TypeError as e:
            result = f"Error calling {name}: {e}"
        except Exception as e:
            result = f"Tool error ({name}): {e}"
        return _text(str(result))


# ─────────────────────────── stdio transport ─────────────────────────────────

def run_stdio(cwd: str | None = None) -> None:
    """Run MCP server over stdio (newline-delimited JSON-RPC 2.0).

    stdout carries the JSON-RPC stream; all logging goes to stderr so
    the protocol is never corrupted.
    """
    server = MCPServer(cwd=cwd)

    # Redirect accidental print() calls to stderr to keep stdout clean
    _real_stdout = sys.stdout
    sys.stdout = sys.stderr

    try:
        for raw in sys.stdin:
            raw = raw.strip()
            if not raw:
                continue
            try:
                msg = json.loads(raw)
            except json.JSONDecodeError:
                continue  # skip malformed lines (e.g. shebang, startup noise)

            resp = server.handle(msg)
            if resp is not None:
                _real_stdout.write(json.dumps(resp, ensure_ascii=False) + "\n")
                _real_stdout.flush()

    except (KeyboardInterrupt, BrokenPipeError):
        pass
    finally:
        sys.stdout = _real_stdout


# ─────────────────────────── HTTP transport ──────────────────────────────────

def run_http(
    host: str = "127.0.0.1",
    port: int = 3000,
    cwd: str | None = None,
) -> None:
    """Run MCP server over HTTP (POST /messages).

    Accepts ``/messages`` and ``/mcp/v1/messages``.
    ``GET /health`` returns ``200 ok`` for readiness probes.

    Binds to localhost by default; use ``host="0.0.0.0"`` for LAN/Docker access.
    """
    import http.server
    import threading

    server = MCPServer(cwd=cwd)
    _lock = threading.Lock()  # serialise concurrent tool executions

    class _Handler(http.server.BaseHTTPRequestHandler):
        def log_message(self, fmt, *args):
            pass  # suppress default request logs

        def _json_response(self, status: int, body: bytes) -> None:
            self.send_response(status)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            # Allow MCP clients from any local origin
            origin = self.headers.get("Origin", "")
            if origin:
                self.send_header("Access-Control-Allow-Origin", origin)
            self.end_headers()
            self.wfile.write(body)

        def do_OPTIONS(self):
            self.send_response(204)
            self.send_header("Access-Control-Allow-Origin", self.headers.get("Origin", "*"))
            self.send_header("Access-Control-Allow-Methods", "POST, GET, OPTIONS")
            self.send_header("Access-Control-Allow-Headers", "Content-Type")
            self.end_headers()

        def do_POST(self):
            if self.path not in ("/messages", "/mcp/v1/messages"):
                self.send_error(404, "Not found")
                return
            length = int(self.headers.get("Content-Length", 0))
            body = self.rfile.read(length)
            try:
                msg = json.loads(body)
            except json.JSONDecodeError:
                self.send_error(400, "Invalid JSON")
                return

            with _lock:
                resp = server.handle(msg)

            if resp is None:
                # Notification — 204 No Content
                self.send_response(204)
                self.end_headers()
                return

            payload = json.dumps(resp, ensure_ascii=False).encode("utf-8")
            self._json_response(200, payload)

        def do_GET(self):
            if self.path == "/health":
                body = b'{"status":"ok"}'
                self._json_response(200, body)
            elif self.path in ("/tools", "/mcp/v1/tools"):
                # Convenience: GET /tools returns the tool list for debugging
                from byoe import __version__
                tools = [_tool_to_mcp(t) for t in server._tools]
                body = json.dumps({"count": len(tools), "tools": tools},
                                  ensure_ascii=False).encode("utf-8")
                self._json_response(200, body)
            else:
                self.send_error(404, "Not found")

    httpd = http.server.HTTPServer((host, port), _Handler)
    tool_names = ", ".join(t.name for t in server._tools)
    print(f"[byoe] MCP HTTP server → http://{host}:{port}/messages", file=sys.stderr)
    print(f"[byoe] {len(server._tools)} tools: {tool_names}", file=sys.stderr)
    print("[byoe] Press Ctrl+C to stop.", file=sys.stderr)
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        httpd.server_close()
