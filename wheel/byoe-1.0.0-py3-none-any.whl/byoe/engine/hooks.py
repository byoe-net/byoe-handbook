"""BYOE Global Event Hook System.

Provides a lightweight publish-subscribe bus so that cross-cutting concerns
(cost tracking, audit logging, security monitoring, observability) can be
wired in once without modifying every call site.

Usage::

    import byoe

    # Register a hook — fires for every LLM call across ALL agents
    @byoe.on("llm.response")
    def track_cost(model, prompt_tokens, completion_tokens, cost_usd, **_):
        print(f"[cost] {model}: ${cost_usd:.4f}")

    # Register a hook via plain function
    def audit_tool(name, kwargs, result, duration_ms, **_):
        log.info("tool=%s args=%s ms=%d", name, kwargs, duration_ms)

    byoe.on("tool.call", audit_tool)

    # Remove a hook
    byoe.off("tool.call", audit_tool)

Available events
----------------
``llm.response``
    Fired after every LLM API call completes.
    kwargs: model(str), prompt_tokens(int), completion_tokens(int),
            cost_usd(float), duration_ms(float)

``tool.call``
    Fired after each tool execution (success or error).
    kwargs: name(str), kwargs(dict), result(str), duration_ms(float),
            error(Exception|None)

``agent.turn``
    Fired after a complete user→assistant turn (all tool calls resolved).
    kwargs: user_input(str), response(str), prompt_tokens(int),
            completion_tokens(int), rounds(int), duration_ms(float)

``memory.write``
    Fired after a memory is written.
    kwargs: path(str), layer(str), was_update(bool)

Extending via package entry-points
-----------------------------------
Third-party packages can auto-register hooks at import time using the
``byoe.hooks`` entry-point group:

    # pyproject.toml
    [project.entry-points."byoe.hooks"]
    my_monitor = "mypackage.monitoring:setup"

The ``setup`` callable receives no arguments and should call :func:`on` to
register its hooks.
"""

from __future__ import annotations

import logging
import time
from typing import Callable

_log = logging.getLogger(__name__)

# event name → list of registered callables
_registry: dict[str, list[Callable]] = {}


def on(event: str, fn: Callable | None = None):
    """Register a hook for *event*.

    Can be used as a decorator or a plain function call::

        @byoe.on("llm.response")
        def my_hook(**kwargs): ...

        byoe.on("llm.response", my_hook)
    """
    if fn is None:
        # decorator form: @byoe.on("event")
        def _decorator(func: Callable) -> Callable:
            _registry.setdefault(event, []).append(func)
            return func
        return _decorator
    _registry.setdefault(event, []).append(fn)
    return fn


def off(event: str, fn: Callable) -> None:
    """Remove a previously registered hook."""
    try:
        _registry.get(event, []).remove(fn)
    except ValueError:
        pass


def emit(event: str, **kwargs) -> None:
    """Fire all hooks registered for *event*.

    Exceptions inside hooks are caught and logged so one broken hook cannot
    interrupt agent execution.
    """
    for fn in list(_registry.get(event, [])):
        try:
            fn(**kwargs)
        except Exception as exc:  # noqa: BLE001
            _log.warning("Hook %s raised %s: %s", fn, type(exc).__name__, exc)


def clear(event: str | None = None) -> None:
    """Remove all hooks, optionally scoped to a single *event* (useful in tests)."""
    if event is None:
        _registry.clear()
    else:
        _registry.pop(event, None)


def _load_hook_plugins() -> None:
    """Discover and invoke setup() callables from ``byoe.hooks`` entry-points."""
    try:
        from importlib.metadata import entry_points
        for ep in entry_points(group="byoe.hooks"):
            try:
                setup_fn = ep.load()
                setup_fn()
            except Exception as exc:  # noqa: BLE001
                _log.warning("Failed to load hook plugin %r: %s", ep.name, exc)
    except Exception:  # noqa: BLE001
        pass


# ── convenience timer context manager ────────────────────────────────────────

class _Timer:
    """Internal helper to measure elapsed milliseconds."""
    def __enter__(self):
        self._t = time.monotonic()
        return self

    def __exit__(self, *_):
        self.ms = (time.monotonic() - self._t) * 1000

    @property
    def elapsed_ms(self) -> float:
        return (time.monotonic() - self._t) * 1000
