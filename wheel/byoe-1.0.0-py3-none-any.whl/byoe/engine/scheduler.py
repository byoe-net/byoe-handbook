"""Lightweight persistent scheduler for BYOE.

Provides interval/once/cron-like triggers and an optional heartbeat channel.
Designed for web/session automation (loop engineering) with minimal dependencies.
"""

from __future__ import annotations

import json
import threading
import time
import uuid
from dataclasses import asdict, dataclass
from datetime import datetime
from pathlib import Path
from typing import Callable


@dataclass
class ScheduledTask:
    id: str
    name: str
    prompt: str
    trigger: dict
    status: str
    created_at: float
    last_run_at: float | None
    next_run_at: float | None
    run_count: int
    max_runs: int | None
    error_count: int
    retry_base_ms: int = 60000
    retry_multiplier: float = 2.0
    retry_max_ms: int = 3600000
    max_errors: int | None = None


class AgentScheduler:
    """Background task scheduler with JSON persistence."""

    def __init__(
        self,
        on_inject: Callable[[str, str], None],
        *,
        persist_path: Path | None = None,
        tick_seconds: float = 5.0,
        audit_path: Path | None = None,
    ) -> None:
        self._on_inject = on_inject
        self._persist_path = persist_path or (Path.home() / ".byoe" / "scheduler_tasks.json")
        self._audit_path = audit_path or (Path.home() / ".byoe" / "logs" / "scheduler.jsonl")
        self._tick_seconds = max(1.0, float(tick_seconds))

        self._lock = threading.RLock()
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None
        self._tasks: dict[str, ScheduledTask] = {}

        self._heartbeat_enabled = False
        self._heartbeat_interval = 300.0
        self._heartbeat_prompt = "Heartbeat check-in: review pending work and act if needed."
        self._next_heartbeat_at: float | None = None
        self._retry_policy = {
            "base_ms": 60000,
            "multiplier": 2.0,
            "max_ms": 3600000,
            "max_errors": None,
        }

        self._load()

    # ------------------------------------------------------------------
    # lifecycle
    # ------------------------------------------------------------------

    def start(self) -> None:
        if self._thread and self._thread.is_alive():
            return
        self._stop.clear()
        self._thread = threading.Thread(target=self._run, daemon=True, name="byoe-scheduler")
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()
        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=2.0)

    # ------------------------------------------------------------------
    # heartbeat
    # ------------------------------------------------------------------

    def set_heartbeat(self, enabled: bool, interval_ms: int = 300000, prompt: str | None = None) -> None:
        with self._lock:
            self._heartbeat_enabled = bool(enabled)
            self._heartbeat_interval = max(5.0, float(interval_ms) / 1000.0)
            if prompt:
                self._heartbeat_prompt = prompt
            self._next_heartbeat_at = time.time() + self._heartbeat_interval if self._heartbeat_enabled else None
            self._save()

    def heartbeat_status(self) -> dict:
        with self._lock:
            return {
                "enabled": self._heartbeat_enabled,
                "interval_ms": int(self._heartbeat_interval * 1000),
                "next_run_at": self._next_heartbeat_at,
                "prompt": self._heartbeat_prompt,
            }

    def retry_policy(self) -> dict:
        with self._lock:
            return dict(self._retry_policy)

    def set_retry_policy(
        self,
        *,
        base_ms: int | None = None,
        multiplier: float | None = None,
        max_ms: int | None = None,
        max_errors: int | None = None,
    ) -> dict:
        with self._lock:
            if base_ms is not None:
                self._retry_policy["base_ms"] = max(1000, int(base_ms))
            if multiplier is not None:
                self._retry_policy["multiplier"] = max(1.0, float(multiplier))
            if max_ms is not None:
                self._retry_policy["max_ms"] = max(1000, int(max_ms))
            self._retry_policy["max_errors"] = (max_errors if isinstance(max_errors, int) and max_errors > 0 else None)
            self._save()
            return dict(self._retry_policy)

    # ------------------------------------------------------------------
    # task CRUD
    # ------------------------------------------------------------------

    def list_tasks(self) -> list[dict]:
        with self._lock:
            tasks = sorted(self._tasks.values(), key=lambda t: t.created_at)
            return [asdict(t) for t in tasks]

    def add_task(self, name: str, prompt: str, trigger: str, max_runs: int | None = None) -> str:
        trig = self._parse_trigger(trigger)
        now = time.time()
        task_id = uuid.uuid4().hex
        task = ScheduledTask(
            id=task_id,
            name=name,
            prompt=prompt,
            trigger=trig,
            status="active",
            created_at=now,
            last_run_at=None,
            next_run_at=self._compute_next_run(trig, now),
            run_count=0,
            max_runs=(max_runs if max_runs and max_runs > 0 else None),
            error_count=0,
            retry_base_ms=int(self._retry_policy["base_ms"]),
            retry_multiplier=float(self._retry_policy["multiplier"]),
            retry_max_ms=int(self._retry_policy["max_ms"]),
            max_errors=(self._retry_policy["max_errors"] if isinstance(self._retry_policy["max_errors"], int) else None),
        )
        with self._lock:
            self._tasks[task_id] = task
            self._save()
        return task_id

    def remove_task(self, task_id: str) -> bool:
        with self._lock:
            existed = task_id in self._tasks
            self._tasks.pop(task_id, None)
            if existed:
                self._save()
            return existed

    def pause_task(self, task_id: str) -> bool:
        with self._lock:
            t = self._tasks.get(task_id)
            if not t or t.status != "active":
                return False
            t.status = "paused"
            self._save()
            return True

    def resume_task(self, task_id: str) -> bool:
        with self._lock:
            t = self._tasks.get(task_id)
            if not t or t.status != "paused":
                return False
            t.status = "active"
            t.next_run_at = self._compute_next_run(t.trigger, time.time())
            self._save()
            return True

    # ------------------------------------------------------------------
    # internals
    # ------------------------------------------------------------------

    def _run(self) -> None:
        while not self._stop.is_set():
            try:
                self._tick()
            except Exception:
                pass
            self._stop.wait(self._tick_seconds)

    def _tick(self) -> None:
        now = time.time()

        # heartbeat
        with self._lock:
            hb_enabled = self._heartbeat_enabled
            hb_due = hb_enabled and self._next_heartbeat_at is not None and self._next_heartbeat_at <= now
            hb_prompt = self._heartbeat_prompt
            hb_interval = self._heartbeat_interval

        if hb_due:
            try:
                self._on_inject(hb_prompt, "__heartbeat__")
            finally:
                with self._lock:
                    self._next_heartbeat_at = time.time() + hb_interval
                    self._save()

        # tasks
        due_ids: list[str] = []
        with self._lock:
            for task in self._tasks.values():
                if task.status != "active":
                    continue
                if task.next_run_at is not None and task.next_run_at <= now:
                    due_ids.append(task.id)

        for task_id in due_ids:
            with self._lock:
                task = self._tasks.get(task_id)
                if not task or task.status != "active":
                    continue
            self._execute_task(task)

    def _execute_task(self, task: ScheduledTask) -> None:
        now = time.time()
        try:
            self._on_inject(task.prompt, task.id)
            with self._lock:
                t = self._tasks.get(task.id)
                if not t:
                    return
                t.run_count += 1
                t.last_run_at = now

                if t.trigger.get("type") == "once":
                    t.status = "completed"
                    t.next_run_at = None
                elif t.max_runs and t.run_count >= t.max_runs:
                    t.status = "completed"
                    t.next_run_at = None
                else:
                    t.next_run_at = self._compute_next_run(t.trigger, now)
                self._save()
                self._audit("task_success", {
                    "id": t.id,
                    "name": t.name,
                    "run_count": t.run_count,
                    "next_run_at": t.next_run_at,
                })
        except Exception:
            with self._lock:
                t = self._tasks.get(task.id)
                if not t:
                    return
                t.error_count += 1
                t.last_run_at = now
                if t.max_errors and t.error_count >= t.max_errors:
                    t.status = "failed"
                    t.next_run_at = None
                    self._save()
                    self._audit("task_failed", {
                        "id": t.id,
                        "name": t.name,
                        "error_count": t.error_count,
                        "max_errors": t.max_errors,
                    })
                    return
                # Exponential backoff on failures (max 1 hour)
                base_s = max(1.0, float(t.retry_base_ms) / 1000.0)
                max_s = max(base_s, float(t.retry_max_ms) / 1000.0)
                mult = max(1.0, float(t.retry_multiplier))
                backoff = min(max_s, base_s * (mult ** max(0, t.error_count - 1)))
                base_next = self._compute_next_run(t.trigger, now) or (now + backoff)
                t.next_run_at = max(base_next, now + backoff)
                self._save()
                self._audit("task_error", {
                    "id": t.id,
                    "name": t.name,
                    "error_count": t.error_count,
                    "backoff_seconds": backoff,
                    "next_run_at": t.next_run_at,
                })

    def _compute_next_run(self, trigger: dict, now: float) -> float | None:
        t = trigger.get("type")
        if t == "interval":
            return now + float(trigger.get("ms", 60000)) / 1000.0
        if t == "once":
            at = float(trigger.get("at", 0.0))
            return at if at > now else None
        if t == "cron":
            # Lightweight approximation: use minute field only.
            expr = str(trigger.get("expression", "")).strip()
            return now + self._cron_to_seconds(expr)
        return now + 60.0

    def _cron_to_seconds(self, expression: str) -> float:
        parts = expression.split()
        if not parts:
            return 3600.0
        minute = parts[0]
        if minute.startswith("*/"):
            try:
                n = int(minute[2:])
                return max(1, n) * 60.0
            except Exception:
                return 3600.0
        if minute.isdigit():
            # At fixed minute of each hour -> approx every hour
            return 3600.0
        return 3600.0

    def _parse_trigger(self, raw: str) -> dict:
        s = (raw or "").strip()
        if s.lower().startswith("interval:"):
            val = s.split(":", 1)[1].strip().lower()
            if val.endswith("s"):
                return {"type": "interval", "ms": int(float(val[:-1]) * 1000)}
            if val.endswith("m"):
                return {"type": "interval", "ms": int(float(val[:-1]) * 60000)}
            if val.endswith("h"):
                return {"type": "interval", "ms": int(float(val[:-1]) * 3600000)}
            return {"type": "interval", "ms": int(float(val) * 1000)}

        if s.lower().startswith("once:"):
            ts = s.split(":", 1)[1].strip()
            # ISO datetime expected
            at = datetime.fromisoformat(ts).timestamp()
            return {"type": "once", "at": at}

        return {"type": "cron", "expression": s or "*/60 * * * *"}

    def _load(self) -> None:
        p = self._persist_path
        try:
            if not p.parent.exists():
                p.parent.mkdir(parents=True, exist_ok=True)
            if not p.exists():
                self._save()
                return
            data = json.loads(p.read_text(encoding="utf-8"))
            tasks = data.get("tasks", [])
            self._tasks = {}
            for item in tasks:
                t = ScheduledTask(**item)
                self._tasks[t.id] = t

            hb = data.get("heartbeat", {})
            self._heartbeat_enabled = bool(hb.get("enabled", False))
            self._heartbeat_interval = max(5.0, float(hb.get("interval_ms", 300000)) / 1000.0)
            self._heartbeat_prompt = str(hb.get("prompt", self._heartbeat_prompt))
            self._next_heartbeat_at = hb.get("next_run_at")

            rp = data.get("retry_policy", {})
            self._retry_policy = {
                "base_ms": max(1000, int(rp.get("base_ms", 60000))),
                "multiplier": max(1.0, float(rp.get("multiplier", 2.0))),
                "max_ms": max(1000, int(rp.get("max_ms", 3600000))),
                "max_errors": (int(rp.get("max_errors")) if isinstance(rp.get("max_errors"), int) and int(rp.get("max_errors")) > 0 else None),
            }

            # Backfill per-task retry fields for old persisted tasks.
            for task in self._tasks.values():
                if not getattr(task, "retry_base_ms", None):
                    task.retry_base_ms = int(self._retry_policy["base_ms"])
                if not getattr(task, "retry_multiplier", None):
                    task.retry_multiplier = float(self._retry_policy["multiplier"])
                if not getattr(task, "retry_max_ms", None):
                    task.retry_max_ms = int(self._retry_policy["max_ms"])
        except Exception:
            self._tasks = {}

    def _save(self) -> None:
        p = self._persist_path
        payload = {
            "tasks": [asdict(t) for t in self._tasks.values()],
            "heartbeat": {
                "enabled": self._heartbeat_enabled,
                "interval_ms": int(self._heartbeat_interval * 1000),
                "prompt": self._heartbeat_prompt,
                "next_run_at": self._next_heartbeat_at,
            },
            "retry_policy": dict(self._retry_policy),
        }
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")

    def _audit(self, event: str, data: dict) -> None:
        try:
            path = self._audit_path
            path.parent.mkdir(parents=True, exist_ok=True)
            row = {
                "ts": time.time(),
                "event": event,
                **data,
            }
            with path.open("a", encoding="utf-8") as f:
                f.write(json.dumps(row, ensure_ascii=False) + "\n")
        except Exception:
            pass

    def read_audit(self, limit: int = 100, task_id: str | None = None) -> list[dict]:
        path = self._audit_path
        if not path.exists():
            return []
        rows: list[dict] = []
        try:
            for line in path.read_text(encoding="utf-8").splitlines():
                if not line.strip():
                    continue
                try:
                    rec = json.loads(line)
                except Exception:
                    continue
                if task_id and rec.get("id") != task_id:
                    continue
                rows.append(rec)
        except Exception:
            return []
        if limit > 0:
            return rows[-limit:]
        return rows
