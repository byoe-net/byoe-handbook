"""Session persistence — save and resume conversations."""

import json
import os
import time
from datetime import datetime, timezone
from pathlib import Path

SESSIONS_DIR = Path.home() / ".byoe" / "sessions"
MAX_SESSIONS = 200  # prune oldest when exceeded


def _prune_sessions() -> None:
    """Delete oldest sessions when the directory exceeds MAX_SESSIONS files."""
    files = sorted(SESSIONS_DIR.glob("*.json"))  # ascending = oldest first
    excess = len(files) - MAX_SESSIONS
    for f in files[:excess]:
        try:
            f.unlink()
        except OSError:
            pass


def _make_title(messages: list[dict]) -> str:
    """Extract a short title from the first user message."""
    for m in messages:
        if m.get("role") == "user" and m.get("content"):
            raw = str(m["content"]).strip().replace("\n", " ")
            return raw[:60] + ("…" if len(raw) > 60 else "")
    return "Untitled"


def save_session(
    messages: list[dict],
    model: str,
    session_id: str | None = None,
    changed_files: set[str] | None = None,
    prompt_tokens: int = 0,
    completion_tokens: int = 0,
    estimated_cost: float | None = None,
) -> str:
    SESSIONS_DIR.mkdir(parents=True, exist_ok=True)
    if not session_id:
        session_id = f"sess_{time.strftime('%Y%m%d_%H%M%S')}"
        import random, string
        session_id += "_" + "".join(random.choices(string.ascii_lowercase, k=4))

    data = {
        "id": session_id,
        "title": _make_title(messages),
        "model": model,
        "saved_at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "messages": messages,
        "changed_files": sorted(changed_files) if changed_files else [],
        "prompt_tokens": prompt_tokens,
        "completion_tokens": completion_tokens,
        "total_tokens": prompt_tokens + completion_tokens,
        "estimated_cost": round(estimated_cost, 6) if estimated_cost is not None else None,
    }
    path = SESSIONS_DIR / f"{session_id}.json"
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2))
    _prune_sessions()
    return session_id


def load_session(session_id: str) -> tuple[list[dict], str, set[str]] | None:
    path = SESSIONS_DIR / f"{session_id}.json"
    if not path.exists():
        return None
    data = json.loads(path.read_text())
    changed = set(data.get("changed_files", []))
    return data["messages"], data["model"], changed


def list_sessions() -> list[dict]:
    if not SESSIONS_DIR.exists():
        return []

    sessions = []
    for f in sorted(SESSIONS_DIR.glob("*.json"), reverse=True):
        try:
            data = json.loads(f.read_text())
            preview = ""
            for m in data.get("messages", []):
                if m.get("role") == "user" and m.get("content"):
                    preview = m["content"][:80]
                    break
            sessions.append({
                "id": data.get("id", f.stem),
                "title": data.get("title") or preview or "Untitled",
                "model": data.get("model", "?"),
                "saved_at": data.get("saved_at", "?"),
                "preview": preview,
                "changed_files": data.get("changed_files", []),
                "total_tokens": data.get("total_tokens", 0),
                "estimated_cost": data.get("estimated_cost"),
            })
        except (json.JSONDecodeError, KeyError):
            continue

    return sessions


def delete_session(session_id: str) -> bool:
    """Delete a saved session. Returns True if deleted, False if not found."""
    path = SESSIONS_DIR / f"{session_id}.json"
    if not path.exists():
        return False
    path.unlink()
    return True
