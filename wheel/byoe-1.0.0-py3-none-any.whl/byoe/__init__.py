# -*- coding: utf-8 -*-
"""卜一智航 — 携智而来，决策随行。
BYOE (Bring Your Own Executive AI) — byoe.net

AI 开发团队编排（Crew 工作流）+ 内置多模型编程 Agent 一体化工具。

官网: https://www.byoe.net

Quick start::

    import byoe

    agent = byoe.create_agent()               # reads BYOE_API_KEY + BYOE_MODEL from env
    print(agent.chat("Hello!"))               # synchronous
    for tok in agent.stream("Explain BFS"):   # streaming
        print(tok, end="", flush=True)

    import asyncio
    result = asyncio.run(agent.achat("Write a haiku"))  # async
"""

__version__ = "1.0.0"
__author__ = "byoe.net"
__email__ = "hi@byoe.net"
__url__ = "https://byoe.net"
__tagline__ = "携智而来，决策随行。"

from byoe.engine.agent import Agent, StreamResponse
from byoe.engine.llm import LLM
from byoe.engine.tools.base import Tool
from byoe.engine.light_memory import LightMemory, get_memory
from byoe.engine.scheduler import AgentScheduler
from byoe.engine.hooks import on, off, emit, clear as clear_hooks, _load_hook_plugins

__all__ = [
    "Agent",
    "StreamResponse",
    "LLM",
    "Tool",
    "LightMemory",
    "get_memory",
    "AgentScheduler",
    "create_agent",
    "on",
    "off",
    "emit",
    "clear_hooks",
    "__version__",
    "__author__",
    "__email__",
    "__url__",
    "__tagline__",
]

# Discover and load byoe.hooks entry-point plugins
_load_hook_plugins()


def create_agent(
    model: str | None = None,
    api_key: str | None = None,
    base_url: str | None = None,
    tools: "list[Tool] | None" = None,
    system: str | None = None,
    cwd: str | None = None,
    max_context_tokens: int | None = None,
    fallback_models: "list[str] | None" = None,
    fallbacks: "list[dict] | None" = None,
    mcp_servers: "list[dict] | None" = None,
) -> Agent:
    """Create a ready-to-use Agent with sensible defaults from env vars.

    Args:
        model:              LLM model name. Falls back to BYOE_MODEL / OPENAI_MODEL_NAME / "deepseek-v4-flash".
        api_key:            API key. Falls back to BYOE_API_KEY / OPENAI_API_KEY.
        base_url:           API base URL. Falls back to OPENAI_BASE_URL.
        tools:              Tool instances. Defaults to all built-in tools.
        system:             System prompt override.
        cwd:                Working directory for file/bash tools.
        max_context_tokens: Context window size (default 128 000).
        fallback_models:    Model names (same provider/key) to try on failure.
        fallbacks:          Cross-provider fallbacks as list of
                            ``{"model": ..., "api_key": ..., "base_url": ...}`` dicts.
        mcp_servers:        MCP server configs. Each entry is a dict with ``name`` plus
                            either ``command`` (stdio) or ``url`` (HTTP).
                            Falls back to BYOE_MCP_SERVERS env var (JSON array).

    Returns:
        A configured :class:`Agent` ready for ``.chat()`` / ``.stream()`` / ``.achat()``.

    Example::

        import byoe

        # Simple — reads all config from env
        agent = byoe.create_agent()

        # Explicit model + same-provider fallback chain
        agent = byoe.create_agent(
            model="deepseek-v4-flash",
            api_key="sk-...",
            fallback_models=["deepseek-chat"],
        )

        # Cross-provider fallbacks
        agent = byoe.create_agent(
            model="gpt-4o",
            api_key="sk-openai-...",
            fallbacks=[
                {"model": "deepseek-chat", "api_key": "sk-ds-...",
                 "base_url": "https://api.deepseek.com"},
            ],
        )
    """
    from byoe.engine.config import Config

    cfg = Config.from_env()
    _model = model or cfg.model
    _api_key = api_key or cfg.api_key
    _base_url = base_url or cfg.base_url
    _max_ctx = max_context_tokens or cfg.max_context_tokens

    _fallback_providers = list(fallbacks or [])
    if fallback_models:
        for fm in fallback_models:
            _fallback_providers.append(
                {"model": fm, "api_key": _api_key, "base_url": _base_url}
            )

    llm = LLM(
        model=_model,
        api_key=_api_key,
        base_url=_base_url,
        fallback_providers=_fallback_providers or None,
    )
    agent = Agent(
        llm=llm,
        tools=tools,
        system=system,
        cwd=cwd,
        max_context_tokens=_max_ctx,
    )
    # Connect MCP servers and register their tools
    _mcp_configs = mcp_servers if mcp_servers is not None else cfg.mcp_servers
    if _mcp_configs:
        from byoe.engine.mcp import connect_servers as _mcp_connect
        for _mcp_tool in _mcp_connect(_mcp_configs):
            agent.add_runtime_tool(_mcp_tool)
    return agent
